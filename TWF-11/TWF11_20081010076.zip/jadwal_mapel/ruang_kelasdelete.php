<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$ruang_kelas_delete = new ruang_kelas_delete();

// Run the page
$ruang_kelas_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$ruang_kelas_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fruang_kelasdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fruang_kelasdelete = currentForm = new ew.Form("fruang_kelasdelete", "delete");
	loadjs.done("fruang_kelasdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $ruang_kelas_delete->showPageHeader(); ?>
<?php
$ruang_kelas_delete->showMessage();
?>
<form name="fruang_kelasdelete" id="fruang_kelasdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="ruang_kelas">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($ruang_kelas_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($ruang_kelas_delete->IDRUANG->Visible) { // IDRUANG ?>
		<th class="<?php echo $ruang_kelas_delete->IDRUANG->headerCellClass() ?>"><span id="elh_ruang_kelas_IDRUANG" class="ruang_kelas_IDRUANG"><?php echo $ruang_kelas_delete->IDRUANG->caption() ?></span></th>
<?php } ?>
<?php if ($ruang_kelas_delete->NAMA_RUANG->Visible) { // NAMA_RUANG ?>
		<th class="<?php echo $ruang_kelas_delete->NAMA_RUANG->headerCellClass() ?>"><span id="elh_ruang_kelas_NAMA_RUANG" class="ruang_kelas_NAMA_RUANG"><?php echo $ruang_kelas_delete->NAMA_RUANG->caption() ?></span></th>
<?php } ?>
<?php if ($ruang_kelas_delete->TIPE_RUANG->Visible) { // TIPE_RUANG ?>
		<th class="<?php echo $ruang_kelas_delete->TIPE_RUANG->headerCellClass() ?>"><span id="elh_ruang_kelas_TIPE_RUANG" class="ruang_kelas_TIPE_RUANG"><?php echo $ruang_kelas_delete->TIPE_RUANG->caption() ?></span></th>
<?php } ?>
<?php if ($ruang_kelas_delete->UKURAN_RUANG->Visible) { // UKURAN_RUANG ?>
		<th class="<?php echo $ruang_kelas_delete->UKURAN_RUANG->headerCellClass() ?>"><span id="elh_ruang_kelas_UKURAN_RUANG" class="ruang_kelas_UKURAN_RUANG"><?php echo $ruang_kelas_delete->UKURAN_RUANG->caption() ?></span></th>
<?php } ?>
<?php if ($ruang_kelas_delete->KAPASITAS_RUANG->Visible) { // KAPASITAS_RUANG ?>
		<th class="<?php echo $ruang_kelas_delete->KAPASITAS_RUANG->headerCellClass() ?>"><span id="elh_ruang_kelas_KAPASITAS_RUANG" class="ruang_kelas_KAPASITAS_RUANG"><?php echo $ruang_kelas_delete->KAPASITAS_RUANG->caption() ?></span></th>
<?php } ?>
<?php if ($ruang_kelas_delete->JUMLAH_MEJA->Visible) { // JUMLAH_MEJA ?>
		<th class="<?php echo $ruang_kelas_delete->JUMLAH_MEJA->headerCellClass() ?>"><span id="elh_ruang_kelas_JUMLAH_MEJA" class="ruang_kelas_JUMLAH_MEJA"><?php echo $ruang_kelas_delete->JUMLAH_MEJA->caption() ?></span></th>
<?php } ?>
<?php if ($ruang_kelas_delete->JUMLAH_KURSI->Visible) { // JUMLAH_KURSI ?>
		<th class="<?php echo $ruang_kelas_delete->JUMLAH_KURSI->headerCellClass() ?>"><span id="elh_ruang_kelas_JUMLAH_KURSI" class="ruang_kelas_JUMLAH_KURSI"><?php echo $ruang_kelas_delete->JUMLAH_KURSI->caption() ?></span></th>
<?php } ?>
<?php if ($ruang_kelas_delete->KETERANGAN_RUANG->Visible) { // KETERANGAN_RUANG ?>
		<th class="<?php echo $ruang_kelas_delete->KETERANGAN_RUANG->headerCellClass() ?>"><span id="elh_ruang_kelas_KETERANGAN_RUANG" class="ruang_kelas_KETERANGAN_RUANG"><?php echo $ruang_kelas_delete->KETERANGAN_RUANG->caption() ?></span></th>
<?php } ?>
<?php if ($ruang_kelas_delete->KELENGKAPAN_ALAT->Visible) { // KELENGKAPAN_ALAT ?>
		<th class="<?php echo $ruang_kelas_delete->KELENGKAPAN_ALAT->headerCellClass() ?>"><span id="elh_ruang_kelas_KELENGKAPAN_ALAT" class="ruang_kelas_KELENGKAPAN_ALAT"><?php echo $ruang_kelas_delete->KELENGKAPAN_ALAT->caption() ?></span></th>
<?php } ?>
<?php if ($ruang_kelas_delete->RENOVASI_TERAKHIR->Visible) { // RENOVASI_TERAKHIR ?>
		<th class="<?php echo $ruang_kelas_delete->RENOVASI_TERAKHIR->headerCellClass() ?>"><span id="elh_ruang_kelas_RENOVASI_TERAKHIR" class="ruang_kelas_RENOVASI_TERAKHIR"><?php echo $ruang_kelas_delete->RENOVASI_TERAKHIR->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$ruang_kelas_delete->RecordCount = 0;
$i = 0;
while (!$ruang_kelas_delete->Recordset->EOF) {
	$ruang_kelas_delete->RecordCount++;
	$ruang_kelas_delete->RowCount++;

	// Set row properties
	$ruang_kelas->resetAttributes();
	$ruang_kelas->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$ruang_kelas_delete->loadRowValues($ruang_kelas_delete->Recordset);

	// Render row
	$ruang_kelas_delete->renderRow();
?>
	<tr <?php echo $ruang_kelas->rowAttributes() ?>>
<?php if ($ruang_kelas_delete->IDRUANG->Visible) { // IDRUANG ?>
		<td <?php echo $ruang_kelas_delete->IDRUANG->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_delete->RowCount ?>_ruang_kelas_IDRUANG" class="ruang_kelas_IDRUANG">
<span<?php echo $ruang_kelas_delete->IDRUANG->viewAttributes() ?>><?php echo $ruang_kelas_delete->IDRUANG->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($ruang_kelas_delete->NAMA_RUANG->Visible) { // NAMA_RUANG ?>
		<td <?php echo $ruang_kelas_delete->NAMA_RUANG->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_delete->RowCount ?>_ruang_kelas_NAMA_RUANG" class="ruang_kelas_NAMA_RUANG">
<span<?php echo $ruang_kelas_delete->NAMA_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_delete->NAMA_RUANG->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($ruang_kelas_delete->TIPE_RUANG->Visible) { // TIPE_RUANG ?>
		<td <?php echo $ruang_kelas_delete->TIPE_RUANG->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_delete->RowCount ?>_ruang_kelas_TIPE_RUANG" class="ruang_kelas_TIPE_RUANG">
<span<?php echo $ruang_kelas_delete->TIPE_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_delete->TIPE_RUANG->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($ruang_kelas_delete->UKURAN_RUANG->Visible) { // UKURAN_RUANG ?>
		<td <?php echo $ruang_kelas_delete->UKURAN_RUANG->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_delete->RowCount ?>_ruang_kelas_UKURAN_RUANG" class="ruang_kelas_UKURAN_RUANG">
<span<?php echo $ruang_kelas_delete->UKURAN_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_delete->UKURAN_RUANG->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($ruang_kelas_delete->KAPASITAS_RUANG->Visible) { // KAPASITAS_RUANG ?>
		<td <?php echo $ruang_kelas_delete->KAPASITAS_RUANG->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_delete->RowCount ?>_ruang_kelas_KAPASITAS_RUANG" class="ruang_kelas_KAPASITAS_RUANG">
<span<?php echo $ruang_kelas_delete->KAPASITAS_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_delete->KAPASITAS_RUANG->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($ruang_kelas_delete->JUMLAH_MEJA->Visible) { // JUMLAH_MEJA ?>
		<td <?php echo $ruang_kelas_delete->JUMLAH_MEJA->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_delete->RowCount ?>_ruang_kelas_JUMLAH_MEJA" class="ruang_kelas_JUMLAH_MEJA">
<span<?php echo $ruang_kelas_delete->JUMLAH_MEJA->viewAttributes() ?>><?php echo $ruang_kelas_delete->JUMLAH_MEJA->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($ruang_kelas_delete->JUMLAH_KURSI->Visible) { // JUMLAH_KURSI ?>
		<td <?php echo $ruang_kelas_delete->JUMLAH_KURSI->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_delete->RowCount ?>_ruang_kelas_JUMLAH_KURSI" class="ruang_kelas_JUMLAH_KURSI">
<span<?php echo $ruang_kelas_delete->JUMLAH_KURSI->viewAttributes() ?>><?php echo $ruang_kelas_delete->JUMLAH_KURSI->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($ruang_kelas_delete->KETERANGAN_RUANG->Visible) { // KETERANGAN_RUANG ?>
		<td <?php echo $ruang_kelas_delete->KETERANGAN_RUANG->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_delete->RowCount ?>_ruang_kelas_KETERANGAN_RUANG" class="ruang_kelas_KETERANGAN_RUANG">
<span<?php echo $ruang_kelas_delete->KETERANGAN_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_delete->KETERANGAN_RUANG->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($ruang_kelas_delete->KELENGKAPAN_ALAT->Visible) { // KELENGKAPAN_ALAT ?>
		<td <?php echo $ruang_kelas_delete->KELENGKAPAN_ALAT->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_delete->RowCount ?>_ruang_kelas_KELENGKAPAN_ALAT" class="ruang_kelas_KELENGKAPAN_ALAT">
<span<?php echo $ruang_kelas_delete->KELENGKAPAN_ALAT->viewAttributes() ?>><?php echo $ruang_kelas_delete->KELENGKAPAN_ALAT->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($ruang_kelas_delete->RENOVASI_TERAKHIR->Visible) { // RENOVASI_TERAKHIR ?>
		<td <?php echo $ruang_kelas_delete->RENOVASI_TERAKHIR->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_delete->RowCount ?>_ruang_kelas_RENOVASI_TERAKHIR" class="ruang_kelas_RENOVASI_TERAKHIR">
<span<?php echo $ruang_kelas_delete->RENOVASI_TERAKHIR->viewAttributes() ?>><?php echo $ruang_kelas_delete->RENOVASI_TERAKHIR->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$ruang_kelas_delete->Recordset->moveNext();
}
$ruang_kelas_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $ruang_kelas_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$ruang_kelas_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$ruang_kelas_delete->terminate();
?>