<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$murid_edit = new murid_edit();

// Run the page
$murid_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$murid_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmuridedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fmuridedit = currentForm = new ew.Form("fmuridedit", "edit");

	// Validate form
	fmuridedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "F")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($murid_edit->NO_INDUK->Required) { ?>
				elm = this.getElements("x" + infix + "_NO_INDUK");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->NO_INDUK->caption(), $murid_edit->NO_INDUK->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->NAMA_MURID->Required) { ?>
				elm = this.getElements("x" + infix + "_NAMA_MURID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->NAMA_MURID->caption(), $murid_edit->NAMA_MURID->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->JEN_KEL->Required) { ?>
				elm = this.getElements("x" + infix + "_JEN_KEL");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->JEN_KEL->caption(), $murid_edit->JEN_KEL->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->AGAMA_MURID->Required) { ?>
				elm = this.getElements("x" + infix + "_AGAMA_MURID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->AGAMA_MURID->caption(), $murid_edit->AGAMA_MURID->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->ALAMAT_RUMAH->Required) { ?>
				elm = this.getElements("x" + infix + "_ALAMAT_RUMAH");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->ALAMAT_RUMAH->caption(), $murid_edit->ALAMAT_RUMAH->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->TEMPATLAHIR->Required) { ?>
				elm = this.getElements("x" + infix + "_TEMPATLAHIR");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->TEMPATLAHIR->caption(), $murid_edit->TEMPATLAHIR->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->TGL_LAHIR->Required) { ?>
				elm = this.getElements("x" + infix + "_TGL_LAHIR");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->TGL_LAHIR->caption(), $murid_edit->TGL_LAHIR->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_TGL_LAHIR");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($murid_edit->TGL_LAHIR->errorMessage()) ?>");
			<?php if ($murid_edit->NOHP->Required) { ?>
				elm = this.getElements("x" + infix + "_NOHP");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->NOHP->caption(), $murid_edit->NOHP->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->NOWA->Required) { ?>
				elm = this.getElements("x" + infix + "_NOWA");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->NOWA->caption(), $murid_edit->NOWA->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->IDTELEGRAM->Required) { ?>
				elm = this.getElements("x" + infix + "_IDTELEGRAM");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->IDTELEGRAM->caption(), $murid_edit->IDTELEGRAM->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->IDLINE->Required) { ?>
				elm = this.getElements("x" + infix + "_IDLINE");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->IDLINE->caption(), $murid_edit->IDLINE->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->IDFACEBOOK->Required) { ?>
				elm = this.getElements("x" + infix + "_IDFACEBOOK");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->IDFACEBOOK->caption(), $murid_edit->IDFACEBOOK->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->IDINSTAGRAM->Required) { ?>
				elm = this.getElements("x" + infix + "_IDINSTAGRAM");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->IDINSTAGRAM->caption(), $murid_edit->IDINSTAGRAM->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->IDTWITTER->Required) { ?>
				elm = this.getElements("x" + infix + "_IDTWITTER");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->IDTWITTER->caption(), $murid_edit->IDTWITTER->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->IDYOUTUBE->Required) { ?>
				elm = this.getElements("x" + infix + "_IDYOUTUBE");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->IDYOUTUBE->caption(), $murid_edit->IDYOUTUBE->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($murid_edit->_EMAIL->Required) { ?>
				elm = this.getElements("x" + infix + "__EMAIL");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $murid_edit->_EMAIL->caption(), $murid_edit->_EMAIL->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fmuridedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmuridedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fmuridedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $murid_edit->showPageHeader(); ?>
<?php
$murid_edit->showMessage();
?>
<form name="fmuridedit" id="fmuridedit" class="<?php echo $murid_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="murid">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$murid_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($murid_edit->NO_INDUK->Visible) { // NO_INDUK ?>
	<div id="r_NO_INDUK" class="form-group row">
		<label id="elh_murid_NO_INDUK" for="x_NO_INDUK" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->NO_INDUK->caption() ?><?php echo $murid_edit->NO_INDUK->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->NO_INDUK->cellAttributes() ?>>
<input type="text" data-table="murid" data-field="x_NO_INDUK" name="x_NO_INDUK" id="x_NO_INDUK" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($murid_edit->NO_INDUK->getPlaceHolder()) ?>" value="<?php echo $murid_edit->NO_INDUK->EditValue ?>"<?php echo $murid_edit->NO_INDUK->editAttributes() ?>>
<input type="hidden" data-table="murid" data-field="x_NO_INDUK" name="o_NO_INDUK" id="o_NO_INDUK" value="<?php echo HtmlEncode($murid_edit->NO_INDUK->OldValue != null ? $murid_edit->NO_INDUK->OldValue : $murid_edit->NO_INDUK->CurrentValue) ?>">
<?php echo $murid_edit->NO_INDUK->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->NAMA_MURID->Visible) { // NAMA_MURID ?>
	<div id="r_NAMA_MURID" class="form-group row">
		<label id="elh_murid_NAMA_MURID" for="x_NAMA_MURID" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->NAMA_MURID->caption() ?><?php echo $murid_edit->NAMA_MURID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->NAMA_MURID->cellAttributes() ?>>
<span id="el_murid_NAMA_MURID">
<input type="text" data-table="murid" data-field="x_NAMA_MURID" name="x_NAMA_MURID" id="x_NAMA_MURID" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($murid_edit->NAMA_MURID->getPlaceHolder()) ?>" value="<?php echo $murid_edit->NAMA_MURID->EditValue ?>"<?php echo $murid_edit->NAMA_MURID->editAttributes() ?>>
</span>
<?php echo $murid_edit->NAMA_MURID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->JEN_KEL->Visible) { // JEN_KEL ?>
	<div id="r_JEN_KEL" class="form-group row">
		<label id="elh_murid_JEN_KEL" for="x_JEN_KEL" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->JEN_KEL->caption() ?><?php echo $murid_edit->JEN_KEL->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->JEN_KEL->cellAttributes() ?>>
<span id="el_murid_JEN_KEL">
<input type="text" data-table="murid" data-field="x_JEN_KEL" name="x_JEN_KEL" id="x_JEN_KEL" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($murid_edit->JEN_KEL->getPlaceHolder()) ?>" value="<?php echo $murid_edit->JEN_KEL->EditValue ?>"<?php echo $murid_edit->JEN_KEL->editAttributes() ?>>
</span>
<?php echo $murid_edit->JEN_KEL->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->AGAMA_MURID->Visible) { // AGAMA_MURID ?>
	<div id="r_AGAMA_MURID" class="form-group row">
		<label id="elh_murid_AGAMA_MURID" for="x_AGAMA_MURID" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->AGAMA_MURID->caption() ?><?php echo $murid_edit->AGAMA_MURID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->AGAMA_MURID->cellAttributes() ?>>
<span id="el_murid_AGAMA_MURID">
<input type="text" data-table="murid" data-field="x_AGAMA_MURID" name="x_AGAMA_MURID" id="x_AGAMA_MURID" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($murid_edit->AGAMA_MURID->getPlaceHolder()) ?>" value="<?php echo $murid_edit->AGAMA_MURID->EditValue ?>"<?php echo $murid_edit->AGAMA_MURID->editAttributes() ?>>
</span>
<?php echo $murid_edit->AGAMA_MURID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->ALAMAT_RUMAH->Visible) { // ALAMAT_RUMAH ?>
	<div id="r_ALAMAT_RUMAH" class="form-group row">
		<label id="elh_murid_ALAMAT_RUMAH" for="x_ALAMAT_RUMAH" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->ALAMAT_RUMAH->caption() ?><?php echo $murid_edit->ALAMAT_RUMAH->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->ALAMAT_RUMAH->cellAttributes() ?>>
<span id="el_murid_ALAMAT_RUMAH">
<input type="text" data-table="murid" data-field="x_ALAMAT_RUMAH" name="x_ALAMAT_RUMAH" id="x_ALAMAT_RUMAH" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($murid_edit->ALAMAT_RUMAH->getPlaceHolder()) ?>" value="<?php echo $murid_edit->ALAMAT_RUMAH->EditValue ?>"<?php echo $murid_edit->ALAMAT_RUMAH->editAttributes() ?>>
</span>
<?php echo $murid_edit->ALAMAT_RUMAH->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->TEMPATLAHIR->Visible) { // TEMPATLAHIR ?>
	<div id="r_TEMPATLAHIR" class="form-group row">
		<label id="elh_murid_TEMPATLAHIR" for="x_TEMPATLAHIR" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->TEMPATLAHIR->caption() ?><?php echo $murid_edit->TEMPATLAHIR->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->TEMPATLAHIR->cellAttributes() ?>>
<span id="el_murid_TEMPATLAHIR">
<input type="text" data-table="murid" data-field="x_TEMPATLAHIR" name="x_TEMPATLAHIR" id="x_TEMPATLAHIR" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($murid_edit->TEMPATLAHIR->getPlaceHolder()) ?>" value="<?php echo $murid_edit->TEMPATLAHIR->EditValue ?>"<?php echo $murid_edit->TEMPATLAHIR->editAttributes() ?>>
</span>
<?php echo $murid_edit->TEMPATLAHIR->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->TGL_LAHIR->Visible) { // TGL_LAHIR ?>
	<div id="r_TGL_LAHIR" class="form-group row">
		<label id="elh_murid_TGL_LAHIR" for="x_TGL_LAHIR" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->TGL_LAHIR->caption() ?><?php echo $murid_edit->TGL_LAHIR->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->TGL_LAHIR->cellAttributes() ?>>
<span id="el_murid_TGL_LAHIR">
<input type="text" data-table="murid" data-field="x_TGL_LAHIR" name="x_TGL_LAHIR" id="x_TGL_LAHIR" maxlength="10" placeholder="<?php echo HtmlEncode($murid_edit->TGL_LAHIR->getPlaceHolder()) ?>" value="<?php echo $murid_edit->TGL_LAHIR->EditValue ?>"<?php echo $murid_edit->TGL_LAHIR->editAttributes() ?>>
</span>
<?php echo $murid_edit->TGL_LAHIR->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->NOHP->Visible) { // NOHP ?>
	<div id="r_NOHP" class="form-group row">
		<label id="elh_murid_NOHP" for="x_NOHP" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->NOHP->caption() ?><?php echo $murid_edit->NOHP->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->NOHP->cellAttributes() ?>>
<span id="el_murid_NOHP">
<input type="text" data-table="murid" data-field="x_NOHP" name="x_NOHP" id="x_NOHP" size="30" maxlength="14" placeholder="<?php echo HtmlEncode($murid_edit->NOHP->getPlaceHolder()) ?>" value="<?php echo $murid_edit->NOHP->EditValue ?>"<?php echo $murid_edit->NOHP->editAttributes() ?>>
</span>
<?php echo $murid_edit->NOHP->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->NOWA->Visible) { // NOWA ?>
	<div id="r_NOWA" class="form-group row">
		<label id="elh_murid_NOWA" for="x_NOWA" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->NOWA->caption() ?><?php echo $murid_edit->NOWA->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->NOWA->cellAttributes() ?>>
<span id="el_murid_NOWA">
<input type="text" data-table="murid" data-field="x_NOWA" name="x_NOWA" id="x_NOWA" size="30" maxlength="14" placeholder="<?php echo HtmlEncode($murid_edit->NOWA->getPlaceHolder()) ?>" value="<?php echo $murid_edit->NOWA->EditValue ?>"<?php echo $murid_edit->NOWA->editAttributes() ?>>
</span>
<?php echo $murid_edit->NOWA->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->IDTELEGRAM->Visible) { // IDTELEGRAM ?>
	<div id="r_IDTELEGRAM" class="form-group row">
		<label id="elh_murid_IDTELEGRAM" for="x_IDTELEGRAM" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->IDTELEGRAM->caption() ?><?php echo $murid_edit->IDTELEGRAM->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->IDTELEGRAM->cellAttributes() ?>>
<span id="el_murid_IDTELEGRAM">
<input type="text" data-table="murid" data-field="x_IDTELEGRAM" name="x_IDTELEGRAM" id="x_IDTELEGRAM" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($murid_edit->IDTELEGRAM->getPlaceHolder()) ?>" value="<?php echo $murid_edit->IDTELEGRAM->EditValue ?>"<?php echo $murid_edit->IDTELEGRAM->editAttributes() ?>>
</span>
<?php echo $murid_edit->IDTELEGRAM->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->IDLINE->Visible) { // IDLINE ?>
	<div id="r_IDLINE" class="form-group row">
		<label id="elh_murid_IDLINE" for="x_IDLINE" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->IDLINE->caption() ?><?php echo $murid_edit->IDLINE->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->IDLINE->cellAttributes() ?>>
<span id="el_murid_IDLINE">
<input type="text" data-table="murid" data-field="x_IDLINE" name="x_IDLINE" id="x_IDLINE" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($murid_edit->IDLINE->getPlaceHolder()) ?>" value="<?php echo $murid_edit->IDLINE->EditValue ?>"<?php echo $murid_edit->IDLINE->editAttributes() ?>>
</span>
<?php echo $murid_edit->IDLINE->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->IDFACEBOOK->Visible) { // IDFACEBOOK ?>
	<div id="r_IDFACEBOOK" class="form-group row">
		<label id="elh_murid_IDFACEBOOK" for="x_IDFACEBOOK" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->IDFACEBOOK->caption() ?><?php echo $murid_edit->IDFACEBOOK->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->IDFACEBOOK->cellAttributes() ?>>
<span id="el_murid_IDFACEBOOK">
<input type="text" data-table="murid" data-field="x_IDFACEBOOK" name="x_IDFACEBOOK" id="x_IDFACEBOOK" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($murid_edit->IDFACEBOOK->getPlaceHolder()) ?>" value="<?php echo $murid_edit->IDFACEBOOK->EditValue ?>"<?php echo $murid_edit->IDFACEBOOK->editAttributes() ?>>
</span>
<?php echo $murid_edit->IDFACEBOOK->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->IDINSTAGRAM->Visible) { // IDINSTAGRAM ?>
	<div id="r_IDINSTAGRAM" class="form-group row">
		<label id="elh_murid_IDINSTAGRAM" for="x_IDINSTAGRAM" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->IDINSTAGRAM->caption() ?><?php echo $murid_edit->IDINSTAGRAM->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->IDINSTAGRAM->cellAttributes() ?>>
<span id="el_murid_IDINSTAGRAM">
<input type="text" data-table="murid" data-field="x_IDINSTAGRAM" name="x_IDINSTAGRAM" id="x_IDINSTAGRAM" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($murid_edit->IDINSTAGRAM->getPlaceHolder()) ?>" value="<?php echo $murid_edit->IDINSTAGRAM->EditValue ?>"<?php echo $murid_edit->IDINSTAGRAM->editAttributes() ?>>
</span>
<?php echo $murid_edit->IDINSTAGRAM->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->IDTWITTER->Visible) { // IDTWITTER ?>
	<div id="r_IDTWITTER" class="form-group row">
		<label id="elh_murid_IDTWITTER" for="x_IDTWITTER" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->IDTWITTER->caption() ?><?php echo $murid_edit->IDTWITTER->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->IDTWITTER->cellAttributes() ?>>
<span id="el_murid_IDTWITTER">
<input type="text" data-table="murid" data-field="x_IDTWITTER" name="x_IDTWITTER" id="x_IDTWITTER" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($murid_edit->IDTWITTER->getPlaceHolder()) ?>" value="<?php echo $murid_edit->IDTWITTER->EditValue ?>"<?php echo $murid_edit->IDTWITTER->editAttributes() ?>>
</span>
<?php echo $murid_edit->IDTWITTER->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->IDYOUTUBE->Visible) { // IDYOUTUBE ?>
	<div id="r_IDYOUTUBE" class="form-group row">
		<label id="elh_murid_IDYOUTUBE" for="x_IDYOUTUBE" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->IDYOUTUBE->caption() ?><?php echo $murid_edit->IDYOUTUBE->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->IDYOUTUBE->cellAttributes() ?>>
<span id="el_murid_IDYOUTUBE">
<input type="text" data-table="murid" data-field="x_IDYOUTUBE" name="x_IDYOUTUBE" id="x_IDYOUTUBE" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($murid_edit->IDYOUTUBE->getPlaceHolder()) ?>" value="<?php echo $murid_edit->IDYOUTUBE->EditValue ?>"<?php echo $murid_edit->IDYOUTUBE->editAttributes() ?>>
</span>
<?php echo $murid_edit->IDYOUTUBE->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($murid_edit->_EMAIL->Visible) { // EMAIL ?>
	<div id="r__EMAIL" class="form-group row">
		<label id="elh_murid__EMAIL" for="x__EMAIL" class="<?php echo $murid_edit->LeftColumnClass ?>"><?php echo $murid_edit->_EMAIL->caption() ?><?php echo $murid_edit->_EMAIL->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $murid_edit->RightColumnClass ?>"><div <?php echo $murid_edit->_EMAIL->cellAttributes() ?>>
<span id="el_murid__EMAIL">
<input type="text" data-table="murid" data-field="x__EMAIL" name="x__EMAIL" id="x__EMAIL" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($murid_edit->_EMAIL->getPlaceHolder()) ?>" value="<?php echo $murid_edit->_EMAIL->EditValue ?>"<?php echo $murid_edit->_EMAIL->editAttributes() ?>>
</span>
<?php echo $murid_edit->_EMAIL->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$murid_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $murid_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $murid_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$murid_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$murid_edit->terminate();
?>