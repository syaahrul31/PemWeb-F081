<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$guru_pengajar_list = new guru_pengajar_list();

// Run the page
$guru_pengajar_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$guru_pengajar_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$guru_pengajar_list->isExport()) { ?>
<script>
var fguru_pengajarlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fguru_pengajarlist = currentForm = new ew.Form("fguru_pengajarlist", "list");
	fguru_pengajarlist.formKeyCountName = '<?php echo $guru_pengajar_list->FormKeyCountName ?>';
	loadjs.done("fguru_pengajarlist");
});
var fguru_pengajarlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fguru_pengajarlistsrch = currentSearchForm = new ew.Form("fguru_pengajarlistsrch");

	// Dynamic selection lists
	// Filters

	fguru_pengajarlistsrch.filterList = <?php echo $guru_pengajar_list->getFilterList() ?>;
	loadjs.done("fguru_pengajarlistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$guru_pengajar_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($guru_pengajar_list->TotalRecords > 0 && $guru_pengajar_list->ExportOptions->visible()) { ?>
<?php $guru_pengajar_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($guru_pengajar_list->ImportOptions->visible()) { ?>
<?php $guru_pengajar_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($guru_pengajar_list->SearchOptions->visible()) { ?>
<?php $guru_pengajar_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($guru_pengajar_list->FilterOptions->visible()) { ?>
<?php $guru_pengajar_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$guru_pengajar_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$guru_pengajar_list->isExport() && !$guru_pengajar->CurrentAction) { ?>
<form name="fguru_pengajarlistsrch" id="fguru_pengajarlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fguru_pengajarlistsrch-search-panel" class="<?php echo $guru_pengajar_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="guru_pengajar">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $guru_pengajar_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($guru_pengajar_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($guru_pengajar_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $guru_pengajar_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($guru_pengajar_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($guru_pengajar_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($guru_pengajar_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($guru_pengajar_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $guru_pengajar_list->showPageHeader(); ?>
<?php
$guru_pengajar_list->showMessage();
?>
<?php if ($guru_pengajar_list->TotalRecords > 0 || $guru_pengajar->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($guru_pengajar_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> guru_pengajar">
<form name="fguru_pengajarlist" id="fguru_pengajarlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="guru_pengajar">
<div id="gmp_guru_pengajar" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($guru_pengajar_list->TotalRecords > 0 || $guru_pengajar_list->isGridEdit()) { ?>
<table id="tbl_guru_pengajarlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$guru_pengajar->RowType = ROWTYPE_HEADER;

// Render list options
$guru_pengajar_list->renderListOptions();

// Render list options (header, left)
$guru_pengajar_list->ListOptions->render("header", "left");
?>
<?php if ($guru_pengajar_list->ID_GURU->Visible) { // ID_GURU ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->ID_GURU) == "") { ?>
		<th data-name="ID_GURU" class="<?php echo $guru_pengajar_list->ID_GURU->headerCellClass() ?>"><div id="elh_guru_pengajar_ID_GURU" class="guru_pengajar_ID_GURU"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_GURU->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ID_GURU" class="<?php echo $guru_pengajar_list->ID_GURU->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->ID_GURU) ?>', 1);"><div id="elh_guru_pengajar_ID_GURU" class="guru_pengajar_ID_GURU">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_GURU->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->ID_GURU->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->ID_GURU->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->NAMA_GURU->Visible) { // NAMA_GURU ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->NAMA_GURU) == "") { ?>
		<th data-name="NAMA_GURU" class="<?php echo $guru_pengajar_list->NAMA_GURU->headerCellClass() ?>"><div id="elh_guru_pengajar_NAMA_GURU" class="guru_pengajar_NAMA_GURU"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->NAMA_GURU->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="NAMA_GURU" class="<?php echo $guru_pengajar_list->NAMA_GURU->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->NAMA_GURU) ?>', 1);"><div id="elh_guru_pengajar_NAMA_GURU" class="guru_pengajar_NAMA_GURU">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->NAMA_GURU->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->NAMA_GURU->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->NAMA_GURU->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->GELAR_DEPAN->Visible) { // GELAR_DEPAN ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->GELAR_DEPAN) == "") { ?>
		<th data-name="GELAR_DEPAN" class="<?php echo $guru_pengajar_list->GELAR_DEPAN->headerCellClass() ?>"><div id="elh_guru_pengajar_GELAR_DEPAN" class="guru_pengajar_GELAR_DEPAN"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->GELAR_DEPAN->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="GELAR_DEPAN" class="<?php echo $guru_pengajar_list->GELAR_DEPAN->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->GELAR_DEPAN) ?>', 1);"><div id="elh_guru_pengajar_GELAR_DEPAN" class="guru_pengajar_GELAR_DEPAN">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->GELAR_DEPAN->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->GELAR_DEPAN->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->GELAR_DEPAN->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->GELAR_BELAKANG->Visible) { // GELAR_BELAKANG ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->GELAR_BELAKANG) == "") { ?>
		<th data-name="GELAR_BELAKANG" class="<?php echo $guru_pengajar_list->GELAR_BELAKANG->headerCellClass() ?>"><div id="elh_guru_pengajar_GELAR_BELAKANG" class="guru_pengajar_GELAR_BELAKANG"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->GELAR_BELAKANG->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="GELAR_BELAKANG" class="<?php echo $guru_pengajar_list->GELAR_BELAKANG->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->GELAR_BELAKANG) ?>', 1);"><div id="elh_guru_pengajar_GELAR_BELAKANG" class="guru_pengajar_GELAR_BELAKANG">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->GELAR_BELAKANG->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->GELAR_BELAKANG->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->GELAR_BELAKANG->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->JENIS_KELAMIN->Visible) { // JENIS_KELAMIN ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->JENIS_KELAMIN) == "") { ?>
		<th data-name="JENIS_KELAMIN" class="<?php echo $guru_pengajar_list->JENIS_KELAMIN->headerCellClass() ?>"><div id="elh_guru_pengajar_JENIS_KELAMIN" class="guru_pengajar_JENIS_KELAMIN"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->JENIS_KELAMIN->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="JENIS_KELAMIN" class="<?php echo $guru_pengajar_list->JENIS_KELAMIN->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->JENIS_KELAMIN) ?>', 1);"><div id="elh_guru_pengajar_JENIS_KELAMIN" class="guru_pengajar_JENIS_KELAMIN">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->JENIS_KELAMIN->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->JENIS_KELAMIN->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->JENIS_KELAMIN->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->AGAMA->Visible) { // AGAMA ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->AGAMA) == "") { ?>
		<th data-name="AGAMA" class="<?php echo $guru_pengajar_list->AGAMA->headerCellClass() ?>"><div id="elh_guru_pengajar_AGAMA" class="guru_pengajar_AGAMA"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->AGAMA->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="AGAMA" class="<?php echo $guru_pengajar_list->AGAMA->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->AGAMA) ?>', 1);"><div id="elh_guru_pengajar_AGAMA" class="guru_pengajar_AGAMA">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->AGAMA->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->AGAMA->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->AGAMA->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->ALAMAT_TINGGAL->Visible) { // ALAMAT_TINGGAL ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->ALAMAT_TINGGAL) == "") { ?>
		<th data-name="ALAMAT_TINGGAL" class="<?php echo $guru_pengajar_list->ALAMAT_TINGGAL->headerCellClass() ?>"><div id="elh_guru_pengajar_ALAMAT_TINGGAL" class="guru_pengajar_ALAMAT_TINGGAL"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->ALAMAT_TINGGAL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ALAMAT_TINGGAL" class="<?php echo $guru_pengajar_list->ALAMAT_TINGGAL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->ALAMAT_TINGGAL) ?>', 1);"><div id="elh_guru_pengajar_ALAMAT_TINGGAL" class="guru_pengajar_ALAMAT_TINGGAL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->ALAMAT_TINGGAL->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->ALAMAT_TINGGAL->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->ALAMAT_TINGGAL->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->NO_HP->Visible) { // NO_HP ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->NO_HP) == "") { ?>
		<th data-name="NO_HP" class="<?php echo $guru_pengajar_list->NO_HP->headerCellClass() ?>"><div id="elh_guru_pengajar_NO_HP" class="guru_pengajar_NO_HP"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->NO_HP->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="NO_HP" class="<?php echo $guru_pengajar_list->NO_HP->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->NO_HP) ?>', 1);"><div id="elh_guru_pengajar_NO_HP" class="guru_pengajar_NO_HP">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->NO_HP->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->NO_HP->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->NO_HP->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->NO_WA->Visible) { // NO_WA ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->NO_WA) == "") { ?>
		<th data-name="NO_WA" class="<?php echo $guru_pengajar_list->NO_WA->headerCellClass() ?>"><div id="elh_guru_pengajar_NO_WA" class="guru_pengajar_NO_WA"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->NO_WA->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="NO_WA" class="<?php echo $guru_pengajar_list->NO_WA->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->NO_WA) ?>', 1);"><div id="elh_guru_pengajar_NO_WA" class="guru_pengajar_NO_WA">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->NO_WA->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->NO_WA->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->NO_WA->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->ID_TELEGRAM->Visible) { // ID_TELEGRAM ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->ID_TELEGRAM) == "") { ?>
		<th data-name="ID_TELEGRAM" class="<?php echo $guru_pengajar_list->ID_TELEGRAM->headerCellClass() ?>"><div id="elh_guru_pengajar_ID_TELEGRAM" class="guru_pengajar_ID_TELEGRAM"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_TELEGRAM->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ID_TELEGRAM" class="<?php echo $guru_pengajar_list->ID_TELEGRAM->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->ID_TELEGRAM) ?>', 1);"><div id="elh_guru_pengajar_ID_TELEGRAM" class="guru_pengajar_ID_TELEGRAM">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_TELEGRAM->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->ID_TELEGRAM->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->ID_TELEGRAM->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->ID_LINE->Visible) { // ID_LINE ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->ID_LINE) == "") { ?>
		<th data-name="ID_LINE" class="<?php echo $guru_pengajar_list->ID_LINE->headerCellClass() ?>"><div id="elh_guru_pengajar_ID_LINE" class="guru_pengajar_ID_LINE"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_LINE->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ID_LINE" class="<?php echo $guru_pengajar_list->ID_LINE->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->ID_LINE) ?>', 1);"><div id="elh_guru_pengajar_ID_LINE" class="guru_pengajar_ID_LINE">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_LINE->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->ID_LINE->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->ID_LINE->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->ID_FACEBOOK->Visible) { // ID_FACEBOOK ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->ID_FACEBOOK) == "") { ?>
		<th data-name="ID_FACEBOOK" class="<?php echo $guru_pengajar_list->ID_FACEBOOK->headerCellClass() ?>"><div id="elh_guru_pengajar_ID_FACEBOOK" class="guru_pengajar_ID_FACEBOOK"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_FACEBOOK->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ID_FACEBOOK" class="<?php echo $guru_pengajar_list->ID_FACEBOOK->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->ID_FACEBOOK) ?>', 1);"><div id="elh_guru_pengajar_ID_FACEBOOK" class="guru_pengajar_ID_FACEBOOK">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_FACEBOOK->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->ID_FACEBOOK->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->ID_FACEBOOK->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->ID_INSTAGRAM->Visible) { // ID_INSTAGRAM ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->ID_INSTAGRAM) == "") { ?>
		<th data-name="ID_INSTAGRAM" class="<?php echo $guru_pengajar_list->ID_INSTAGRAM->headerCellClass() ?>"><div id="elh_guru_pengajar_ID_INSTAGRAM" class="guru_pengajar_ID_INSTAGRAM"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_INSTAGRAM->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ID_INSTAGRAM" class="<?php echo $guru_pengajar_list->ID_INSTAGRAM->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->ID_INSTAGRAM) ?>', 1);"><div id="elh_guru_pengajar_ID_INSTAGRAM" class="guru_pengajar_ID_INSTAGRAM">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_INSTAGRAM->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->ID_INSTAGRAM->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->ID_INSTAGRAM->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->ID_TWITTER->Visible) { // ID_TWITTER ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->ID_TWITTER) == "") { ?>
		<th data-name="ID_TWITTER" class="<?php echo $guru_pengajar_list->ID_TWITTER->headerCellClass() ?>"><div id="elh_guru_pengajar_ID_TWITTER" class="guru_pengajar_ID_TWITTER"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_TWITTER->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ID_TWITTER" class="<?php echo $guru_pengajar_list->ID_TWITTER->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->ID_TWITTER) ?>', 1);"><div id="elh_guru_pengajar_ID_TWITTER" class="guru_pengajar_ID_TWITTER">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_TWITTER->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->ID_TWITTER->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->ID_TWITTER->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->ID_YOUTUBE->Visible) { // ID_YOUTUBE ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->ID_YOUTUBE) == "") { ?>
		<th data-name="ID_YOUTUBE" class="<?php echo $guru_pengajar_list->ID_YOUTUBE->headerCellClass() ?>"><div id="elh_guru_pengajar_ID_YOUTUBE" class="guru_pengajar_ID_YOUTUBE"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_YOUTUBE->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ID_YOUTUBE" class="<?php echo $guru_pengajar_list->ID_YOUTUBE->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->ID_YOUTUBE) ?>', 1);"><div id="elh_guru_pengajar_ID_YOUTUBE" class="guru_pengajar_ID_YOUTUBE">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->ID_YOUTUBE->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->ID_YOUTUBE->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->ID_YOUTUBE->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->EMAIL_GURU->Visible) { // EMAIL_GURU ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->EMAIL_GURU) == "") { ?>
		<th data-name="EMAIL_GURU" class="<?php echo $guru_pengajar_list->EMAIL_GURU->headerCellClass() ?>"><div id="elh_guru_pengajar_EMAIL_GURU" class="guru_pengajar_EMAIL_GURU"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->EMAIL_GURU->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="EMAIL_GURU" class="<?php echo $guru_pengajar_list->EMAIL_GURU->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->EMAIL_GURU) ?>', 1);"><div id="elh_guru_pengajar_EMAIL_GURU" class="guru_pengajar_EMAIL_GURU">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->EMAIL_GURU->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->EMAIL_GURU->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->EMAIL_GURU->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->TEMPAT_LAHIR->Visible) { // TEMPAT_LAHIR ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->TEMPAT_LAHIR) == "") { ?>
		<th data-name="TEMPAT_LAHIR" class="<?php echo $guru_pengajar_list->TEMPAT_LAHIR->headerCellClass() ?>"><div id="elh_guru_pengajar_TEMPAT_LAHIR" class="guru_pengajar_TEMPAT_LAHIR"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->TEMPAT_LAHIR->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TEMPAT_LAHIR" class="<?php echo $guru_pengajar_list->TEMPAT_LAHIR->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->TEMPAT_LAHIR) ?>', 1);"><div id="elh_guru_pengajar_TEMPAT_LAHIR" class="guru_pengajar_TEMPAT_LAHIR">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->TEMPAT_LAHIR->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->TEMPAT_LAHIR->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->TEMPAT_LAHIR->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($guru_pengajar_list->TANGGAL_LAHIR->Visible) { // TANGGAL_LAHIR ?>
	<?php if ($guru_pengajar_list->SortUrl($guru_pengajar_list->TANGGAL_LAHIR) == "") { ?>
		<th data-name="TANGGAL_LAHIR" class="<?php echo $guru_pengajar_list->TANGGAL_LAHIR->headerCellClass() ?>"><div id="elh_guru_pengajar_TANGGAL_LAHIR" class="guru_pengajar_TANGGAL_LAHIR"><div class="ew-table-header-caption"><?php echo $guru_pengajar_list->TANGGAL_LAHIR->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TANGGAL_LAHIR" class="<?php echo $guru_pengajar_list->TANGGAL_LAHIR->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $guru_pengajar_list->SortUrl($guru_pengajar_list->TANGGAL_LAHIR) ?>', 1);"><div id="elh_guru_pengajar_TANGGAL_LAHIR" class="guru_pengajar_TANGGAL_LAHIR">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $guru_pengajar_list->TANGGAL_LAHIR->caption() ?></span><span class="ew-table-header-sort"><?php if ($guru_pengajar_list->TANGGAL_LAHIR->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($guru_pengajar_list->TANGGAL_LAHIR->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$guru_pengajar_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($guru_pengajar_list->ExportAll && $guru_pengajar_list->isExport()) {
	$guru_pengajar_list->StopRecord = $guru_pengajar_list->TotalRecords;
} else {

	// Set the last record to display
	if ($guru_pengajar_list->TotalRecords > $guru_pengajar_list->StartRecord + $guru_pengajar_list->DisplayRecords - 1)
		$guru_pengajar_list->StopRecord = $guru_pengajar_list->StartRecord + $guru_pengajar_list->DisplayRecords - 1;
	else
		$guru_pengajar_list->StopRecord = $guru_pengajar_list->TotalRecords;
}
$guru_pengajar_list->RecordCount = $guru_pengajar_list->StartRecord - 1;
if ($guru_pengajar_list->Recordset && !$guru_pengajar_list->Recordset->EOF) {
	$guru_pengajar_list->Recordset->moveFirst();
	$selectLimit = $guru_pengajar_list->UseSelectLimit;
	if (!$selectLimit && $guru_pengajar_list->StartRecord > 1)
		$guru_pengajar_list->Recordset->move($guru_pengajar_list->StartRecord - 1);
} elseif (!$guru_pengajar->AllowAddDeleteRow && $guru_pengajar_list->StopRecord == 0) {
	$guru_pengajar_list->StopRecord = $guru_pengajar->GridAddRowCount;
}

// Initialize aggregate
$guru_pengajar->RowType = ROWTYPE_AGGREGATEINIT;
$guru_pengajar->resetAttributes();
$guru_pengajar_list->renderRow();
while ($guru_pengajar_list->RecordCount < $guru_pengajar_list->StopRecord) {
	$guru_pengajar_list->RecordCount++;
	if ($guru_pengajar_list->RecordCount >= $guru_pengajar_list->StartRecord) {
		$guru_pengajar_list->RowCount++;

		// Set up key count
		$guru_pengajar_list->KeyCount = $guru_pengajar_list->RowIndex;

		// Init row class and style
		$guru_pengajar->resetAttributes();
		$guru_pengajar->CssClass = "";
		if ($guru_pengajar_list->isGridAdd()) {
		} else {
			$guru_pengajar_list->loadRowValues($guru_pengajar_list->Recordset); // Load row values
		}
		$guru_pengajar->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$guru_pengajar->RowAttrs->merge(["data-rowindex" => $guru_pengajar_list->RowCount, "id" => "r" . $guru_pengajar_list->RowCount . "_guru_pengajar", "data-rowtype" => $guru_pengajar->RowType]);

		// Render row
		$guru_pengajar_list->renderRow();

		// Render list options
		$guru_pengajar_list->renderListOptions();
?>
	<tr <?php echo $guru_pengajar->rowAttributes() ?>>
<?php

// Render list options (body, left)
$guru_pengajar_list->ListOptions->render("body", "left", $guru_pengajar_list->RowCount);
?>
	<?php if ($guru_pengajar_list->ID_GURU->Visible) { // ID_GURU ?>
		<td data-name="ID_GURU" <?php echo $guru_pengajar_list->ID_GURU->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_ID_GURU">
<span<?php echo $guru_pengajar_list->ID_GURU->viewAttributes() ?>><?php echo $guru_pengajar_list->ID_GURU->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->NAMA_GURU->Visible) { // NAMA_GURU ?>
		<td data-name="NAMA_GURU" <?php echo $guru_pengajar_list->NAMA_GURU->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_NAMA_GURU">
<span<?php echo $guru_pengajar_list->NAMA_GURU->viewAttributes() ?>><?php echo $guru_pengajar_list->NAMA_GURU->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->GELAR_DEPAN->Visible) { // GELAR_DEPAN ?>
		<td data-name="GELAR_DEPAN" <?php echo $guru_pengajar_list->GELAR_DEPAN->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_GELAR_DEPAN">
<span<?php echo $guru_pengajar_list->GELAR_DEPAN->viewAttributes() ?>><?php echo $guru_pengajar_list->GELAR_DEPAN->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->GELAR_BELAKANG->Visible) { // GELAR_BELAKANG ?>
		<td data-name="GELAR_BELAKANG" <?php echo $guru_pengajar_list->GELAR_BELAKANG->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_GELAR_BELAKANG">
<span<?php echo $guru_pengajar_list->GELAR_BELAKANG->viewAttributes() ?>><?php echo $guru_pengajar_list->GELAR_BELAKANG->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->JENIS_KELAMIN->Visible) { // JENIS_KELAMIN ?>
		<td data-name="JENIS_KELAMIN" <?php echo $guru_pengajar_list->JENIS_KELAMIN->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_JENIS_KELAMIN">
<span<?php echo $guru_pengajar_list->JENIS_KELAMIN->viewAttributes() ?>><?php echo $guru_pengajar_list->JENIS_KELAMIN->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->AGAMA->Visible) { // AGAMA ?>
		<td data-name="AGAMA" <?php echo $guru_pengajar_list->AGAMA->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_AGAMA">
<span<?php echo $guru_pengajar_list->AGAMA->viewAttributes() ?>><?php echo $guru_pengajar_list->AGAMA->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->ALAMAT_TINGGAL->Visible) { // ALAMAT_TINGGAL ?>
		<td data-name="ALAMAT_TINGGAL" <?php echo $guru_pengajar_list->ALAMAT_TINGGAL->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_ALAMAT_TINGGAL">
<span<?php echo $guru_pengajar_list->ALAMAT_TINGGAL->viewAttributes() ?>><?php echo $guru_pengajar_list->ALAMAT_TINGGAL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->NO_HP->Visible) { // NO_HP ?>
		<td data-name="NO_HP" <?php echo $guru_pengajar_list->NO_HP->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_NO_HP">
<span<?php echo $guru_pengajar_list->NO_HP->viewAttributes() ?>><?php echo $guru_pengajar_list->NO_HP->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->NO_WA->Visible) { // NO_WA ?>
		<td data-name="NO_WA" <?php echo $guru_pengajar_list->NO_WA->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_NO_WA">
<span<?php echo $guru_pengajar_list->NO_WA->viewAttributes() ?>><?php echo $guru_pengajar_list->NO_WA->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->ID_TELEGRAM->Visible) { // ID_TELEGRAM ?>
		<td data-name="ID_TELEGRAM" <?php echo $guru_pengajar_list->ID_TELEGRAM->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_ID_TELEGRAM">
<span<?php echo $guru_pengajar_list->ID_TELEGRAM->viewAttributes() ?>><?php echo $guru_pengajar_list->ID_TELEGRAM->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->ID_LINE->Visible) { // ID_LINE ?>
		<td data-name="ID_LINE" <?php echo $guru_pengajar_list->ID_LINE->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_ID_LINE">
<span<?php echo $guru_pengajar_list->ID_LINE->viewAttributes() ?>><?php echo $guru_pengajar_list->ID_LINE->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->ID_FACEBOOK->Visible) { // ID_FACEBOOK ?>
		<td data-name="ID_FACEBOOK" <?php echo $guru_pengajar_list->ID_FACEBOOK->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_ID_FACEBOOK">
<span<?php echo $guru_pengajar_list->ID_FACEBOOK->viewAttributes() ?>><?php echo $guru_pengajar_list->ID_FACEBOOK->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->ID_INSTAGRAM->Visible) { // ID_INSTAGRAM ?>
		<td data-name="ID_INSTAGRAM" <?php echo $guru_pengajar_list->ID_INSTAGRAM->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_ID_INSTAGRAM">
<span<?php echo $guru_pengajar_list->ID_INSTAGRAM->viewAttributes() ?>><?php echo $guru_pengajar_list->ID_INSTAGRAM->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->ID_TWITTER->Visible) { // ID_TWITTER ?>
		<td data-name="ID_TWITTER" <?php echo $guru_pengajar_list->ID_TWITTER->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_ID_TWITTER">
<span<?php echo $guru_pengajar_list->ID_TWITTER->viewAttributes() ?>><?php echo $guru_pengajar_list->ID_TWITTER->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->ID_YOUTUBE->Visible) { // ID_YOUTUBE ?>
		<td data-name="ID_YOUTUBE" <?php echo $guru_pengajar_list->ID_YOUTUBE->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_ID_YOUTUBE">
<span<?php echo $guru_pengajar_list->ID_YOUTUBE->viewAttributes() ?>><?php echo $guru_pengajar_list->ID_YOUTUBE->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->EMAIL_GURU->Visible) { // EMAIL_GURU ?>
		<td data-name="EMAIL_GURU" <?php echo $guru_pengajar_list->EMAIL_GURU->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_EMAIL_GURU">
<span<?php echo $guru_pengajar_list->EMAIL_GURU->viewAttributes() ?>><?php echo $guru_pengajar_list->EMAIL_GURU->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->TEMPAT_LAHIR->Visible) { // TEMPAT_LAHIR ?>
		<td data-name="TEMPAT_LAHIR" <?php echo $guru_pengajar_list->TEMPAT_LAHIR->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_TEMPAT_LAHIR">
<span<?php echo $guru_pengajar_list->TEMPAT_LAHIR->viewAttributes() ?>><?php echo $guru_pengajar_list->TEMPAT_LAHIR->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($guru_pengajar_list->TANGGAL_LAHIR->Visible) { // TANGGAL_LAHIR ?>
		<td data-name="TANGGAL_LAHIR" <?php echo $guru_pengajar_list->TANGGAL_LAHIR->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_list->RowCount ?>_guru_pengajar_TANGGAL_LAHIR">
<span<?php echo $guru_pengajar_list->TANGGAL_LAHIR->viewAttributes() ?>><?php echo $guru_pengajar_list->TANGGAL_LAHIR->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$guru_pengajar_list->ListOptions->render("body", "right", $guru_pengajar_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$guru_pengajar_list->isGridAdd())
		$guru_pengajar_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$guru_pengajar->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($guru_pengajar_list->Recordset)
	$guru_pengajar_list->Recordset->Close();
?>
<?php if (!$guru_pengajar_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$guru_pengajar_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $guru_pengajar_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $guru_pengajar_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($guru_pengajar_list->TotalRecords == 0 && !$guru_pengajar->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $guru_pengajar_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$guru_pengajar_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$guru_pengajar_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$guru_pengajar_list->terminate();
?>