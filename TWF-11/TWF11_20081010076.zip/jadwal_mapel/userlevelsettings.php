<?php

/**
 * PHPMaker 2020 user level settings
 */
namespace PHPMaker2020\project1;

// User level info
$USER_LEVELS = [["-2","Anonymous"]];

// User level priv info
$USER_LEVEL_PRIVS = [["{6B4A168D-AFB7-4B2A-A9A9-04A7731AE34A}guru_pengajar","-2","0"],
	["{6B4A168D-AFB7-4B2A-A9A9-04A7731AE34A}jadwal_pelajaran","-2","0"],
	["{6B4A168D-AFB7-4B2A-A9A9-04A7731AE34A}mata_pelajaran","-2","0"],
	["{6B4A168D-AFB7-4B2A-A9A9-04A7731AE34A}murid","-2","0"],
	["{6B4A168D-AFB7-4B2A-A9A9-04A7731AE34A}ruang_kelas","-2","0"]];

// User level table info
$USER_LEVEL_TABLES = [];