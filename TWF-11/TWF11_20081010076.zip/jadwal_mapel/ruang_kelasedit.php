<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$ruang_kelas_edit = new ruang_kelas_edit();

// Run the page
$ruang_kelas_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$ruang_kelas_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fruang_kelasedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fruang_kelasedit = currentForm = new ew.Form("fruang_kelasedit", "edit");

	// Validate form
	fruang_kelasedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "F")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($ruang_kelas_edit->IDRUANG->Required) { ?>
				elm = this.getElements("x" + infix + "_IDRUANG");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $ruang_kelas_edit->IDRUANG->caption(), $ruang_kelas_edit->IDRUANG->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($ruang_kelas_edit->NAMA_RUANG->Required) { ?>
				elm = this.getElements("x" + infix + "_NAMA_RUANG");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $ruang_kelas_edit->NAMA_RUANG->caption(), $ruang_kelas_edit->NAMA_RUANG->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($ruang_kelas_edit->TIPE_RUANG->Required) { ?>
				elm = this.getElements("x" + infix + "_TIPE_RUANG");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $ruang_kelas_edit->TIPE_RUANG->caption(), $ruang_kelas_edit->TIPE_RUANG->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($ruang_kelas_edit->UKURAN_RUANG->Required) { ?>
				elm = this.getElements("x" + infix + "_UKURAN_RUANG");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $ruang_kelas_edit->UKURAN_RUANG->caption(), $ruang_kelas_edit->UKURAN_RUANG->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($ruang_kelas_edit->KAPASITAS_RUANG->Required) { ?>
				elm = this.getElements("x" + infix + "_KAPASITAS_RUANG");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $ruang_kelas_edit->KAPASITAS_RUANG->caption(), $ruang_kelas_edit->KAPASITAS_RUANG->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_KAPASITAS_RUANG");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($ruang_kelas_edit->KAPASITAS_RUANG->errorMessage()) ?>");
			<?php if ($ruang_kelas_edit->JUMLAH_MEJA->Required) { ?>
				elm = this.getElements("x" + infix + "_JUMLAH_MEJA");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $ruang_kelas_edit->JUMLAH_MEJA->caption(), $ruang_kelas_edit->JUMLAH_MEJA->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_JUMLAH_MEJA");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($ruang_kelas_edit->JUMLAH_MEJA->errorMessage()) ?>");
			<?php if ($ruang_kelas_edit->JUMLAH_KURSI->Required) { ?>
				elm = this.getElements("x" + infix + "_JUMLAH_KURSI");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $ruang_kelas_edit->JUMLAH_KURSI->caption(), $ruang_kelas_edit->JUMLAH_KURSI->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_JUMLAH_KURSI");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($ruang_kelas_edit->JUMLAH_KURSI->errorMessage()) ?>");
			<?php if ($ruang_kelas_edit->KETERANGAN_RUANG->Required) { ?>
				elm = this.getElements("x" + infix + "_KETERANGAN_RUANG");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $ruang_kelas_edit->KETERANGAN_RUANG->caption(), $ruang_kelas_edit->KETERANGAN_RUANG->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($ruang_kelas_edit->KELENGKAPAN_ALAT->Required) { ?>
				elm = this.getElements("x" + infix + "_KELENGKAPAN_ALAT");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $ruang_kelas_edit->KELENGKAPAN_ALAT->caption(), $ruang_kelas_edit->KELENGKAPAN_ALAT->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($ruang_kelas_edit->RENOVASI_TERAKHIR->Required) { ?>
				elm = this.getElements("x" + infix + "_RENOVASI_TERAKHIR");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $ruang_kelas_edit->RENOVASI_TERAKHIR->caption(), $ruang_kelas_edit->RENOVASI_TERAKHIR->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_RENOVASI_TERAKHIR");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($ruang_kelas_edit->RENOVASI_TERAKHIR->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fruang_kelasedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fruang_kelasedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fruang_kelasedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $ruang_kelas_edit->showPageHeader(); ?>
<?php
$ruang_kelas_edit->showMessage();
?>
<form name="fruang_kelasedit" id="fruang_kelasedit" class="<?php echo $ruang_kelas_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="ruang_kelas">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$ruang_kelas_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($ruang_kelas_edit->IDRUANG->Visible) { // IDRUANG ?>
	<div id="r_IDRUANG" class="form-group row">
		<label id="elh_ruang_kelas_IDRUANG" for="x_IDRUANG" class="<?php echo $ruang_kelas_edit->LeftColumnClass ?>"><?php echo $ruang_kelas_edit->IDRUANG->caption() ?><?php echo $ruang_kelas_edit->IDRUANG->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $ruang_kelas_edit->RightColumnClass ?>"><div <?php echo $ruang_kelas_edit->IDRUANG->cellAttributes() ?>>
<input type="text" data-table="ruang_kelas" data-field="x_IDRUANG" name="x_IDRUANG" id="x_IDRUANG" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($ruang_kelas_edit->IDRUANG->getPlaceHolder()) ?>" value="<?php echo $ruang_kelas_edit->IDRUANG->EditValue ?>"<?php echo $ruang_kelas_edit->IDRUANG->editAttributes() ?>>
<input type="hidden" data-table="ruang_kelas" data-field="x_IDRUANG" name="o_IDRUANG" id="o_IDRUANG" value="<?php echo HtmlEncode($ruang_kelas_edit->IDRUANG->OldValue != null ? $ruang_kelas_edit->IDRUANG->OldValue : $ruang_kelas_edit->IDRUANG->CurrentValue) ?>">
<?php echo $ruang_kelas_edit->IDRUANG->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($ruang_kelas_edit->NAMA_RUANG->Visible) { // NAMA_RUANG ?>
	<div id="r_NAMA_RUANG" class="form-group row">
		<label id="elh_ruang_kelas_NAMA_RUANG" for="x_NAMA_RUANG" class="<?php echo $ruang_kelas_edit->LeftColumnClass ?>"><?php echo $ruang_kelas_edit->NAMA_RUANG->caption() ?><?php echo $ruang_kelas_edit->NAMA_RUANG->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $ruang_kelas_edit->RightColumnClass ?>"><div <?php echo $ruang_kelas_edit->NAMA_RUANG->cellAttributes() ?>>
<span id="el_ruang_kelas_NAMA_RUANG">
<input type="text" data-table="ruang_kelas" data-field="x_NAMA_RUANG" name="x_NAMA_RUANG" id="x_NAMA_RUANG" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($ruang_kelas_edit->NAMA_RUANG->getPlaceHolder()) ?>" value="<?php echo $ruang_kelas_edit->NAMA_RUANG->EditValue ?>"<?php echo $ruang_kelas_edit->NAMA_RUANG->editAttributes() ?>>
</span>
<?php echo $ruang_kelas_edit->NAMA_RUANG->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($ruang_kelas_edit->TIPE_RUANG->Visible) { // TIPE_RUANG ?>
	<div id="r_TIPE_RUANG" class="form-group row">
		<label id="elh_ruang_kelas_TIPE_RUANG" for="x_TIPE_RUANG" class="<?php echo $ruang_kelas_edit->LeftColumnClass ?>"><?php echo $ruang_kelas_edit->TIPE_RUANG->caption() ?><?php echo $ruang_kelas_edit->TIPE_RUANG->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $ruang_kelas_edit->RightColumnClass ?>"><div <?php echo $ruang_kelas_edit->TIPE_RUANG->cellAttributes() ?>>
<span id="el_ruang_kelas_TIPE_RUANG">
<input type="text" data-table="ruang_kelas" data-field="x_TIPE_RUANG" name="x_TIPE_RUANG" id="x_TIPE_RUANG" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($ruang_kelas_edit->TIPE_RUANG->getPlaceHolder()) ?>" value="<?php echo $ruang_kelas_edit->TIPE_RUANG->EditValue ?>"<?php echo $ruang_kelas_edit->TIPE_RUANG->editAttributes() ?>>
</span>
<?php echo $ruang_kelas_edit->TIPE_RUANG->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($ruang_kelas_edit->UKURAN_RUANG->Visible) { // UKURAN_RUANG ?>
	<div id="r_UKURAN_RUANG" class="form-group row">
		<label id="elh_ruang_kelas_UKURAN_RUANG" for="x_UKURAN_RUANG" class="<?php echo $ruang_kelas_edit->LeftColumnClass ?>"><?php echo $ruang_kelas_edit->UKURAN_RUANG->caption() ?><?php echo $ruang_kelas_edit->UKURAN_RUANG->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $ruang_kelas_edit->RightColumnClass ?>"><div <?php echo $ruang_kelas_edit->UKURAN_RUANG->cellAttributes() ?>>
<span id="el_ruang_kelas_UKURAN_RUANG">
<input type="text" data-table="ruang_kelas" data-field="x_UKURAN_RUANG" name="x_UKURAN_RUANG" id="x_UKURAN_RUANG" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($ruang_kelas_edit->UKURAN_RUANG->getPlaceHolder()) ?>" value="<?php echo $ruang_kelas_edit->UKURAN_RUANG->EditValue ?>"<?php echo $ruang_kelas_edit->UKURAN_RUANG->editAttributes() ?>>
</span>
<?php echo $ruang_kelas_edit->UKURAN_RUANG->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($ruang_kelas_edit->KAPASITAS_RUANG->Visible) { // KAPASITAS_RUANG ?>
	<div id="r_KAPASITAS_RUANG" class="form-group row">
		<label id="elh_ruang_kelas_KAPASITAS_RUANG" for="x_KAPASITAS_RUANG" class="<?php echo $ruang_kelas_edit->LeftColumnClass ?>"><?php echo $ruang_kelas_edit->KAPASITAS_RUANG->caption() ?><?php echo $ruang_kelas_edit->KAPASITAS_RUANG->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $ruang_kelas_edit->RightColumnClass ?>"><div <?php echo $ruang_kelas_edit->KAPASITAS_RUANG->cellAttributes() ?>>
<span id="el_ruang_kelas_KAPASITAS_RUANG">
<input type="text" data-table="ruang_kelas" data-field="x_KAPASITAS_RUANG" name="x_KAPASITAS_RUANG" id="x_KAPASITAS_RUANG" size="30" maxlength="4" placeholder="<?php echo HtmlEncode($ruang_kelas_edit->KAPASITAS_RUANG->getPlaceHolder()) ?>" value="<?php echo $ruang_kelas_edit->KAPASITAS_RUANG->EditValue ?>"<?php echo $ruang_kelas_edit->KAPASITAS_RUANG->editAttributes() ?>>
</span>
<?php echo $ruang_kelas_edit->KAPASITAS_RUANG->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($ruang_kelas_edit->JUMLAH_MEJA->Visible) { // JUMLAH_MEJA ?>
	<div id="r_JUMLAH_MEJA" class="form-group row">
		<label id="elh_ruang_kelas_JUMLAH_MEJA" for="x_JUMLAH_MEJA" class="<?php echo $ruang_kelas_edit->LeftColumnClass ?>"><?php echo $ruang_kelas_edit->JUMLAH_MEJA->caption() ?><?php echo $ruang_kelas_edit->JUMLAH_MEJA->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $ruang_kelas_edit->RightColumnClass ?>"><div <?php echo $ruang_kelas_edit->JUMLAH_MEJA->cellAttributes() ?>>
<span id="el_ruang_kelas_JUMLAH_MEJA">
<input type="text" data-table="ruang_kelas" data-field="x_JUMLAH_MEJA" name="x_JUMLAH_MEJA" id="x_JUMLAH_MEJA" size="30" maxlength="4" placeholder="<?php echo HtmlEncode($ruang_kelas_edit->JUMLAH_MEJA->getPlaceHolder()) ?>" value="<?php echo $ruang_kelas_edit->JUMLAH_MEJA->EditValue ?>"<?php echo $ruang_kelas_edit->JUMLAH_MEJA->editAttributes() ?>>
</span>
<?php echo $ruang_kelas_edit->JUMLAH_MEJA->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($ruang_kelas_edit->JUMLAH_KURSI->Visible) { // JUMLAH_KURSI ?>
	<div id="r_JUMLAH_KURSI" class="form-group row">
		<label id="elh_ruang_kelas_JUMLAH_KURSI" for="x_JUMLAH_KURSI" class="<?php echo $ruang_kelas_edit->LeftColumnClass ?>"><?php echo $ruang_kelas_edit->JUMLAH_KURSI->caption() ?><?php echo $ruang_kelas_edit->JUMLAH_KURSI->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $ruang_kelas_edit->RightColumnClass ?>"><div <?php echo $ruang_kelas_edit->JUMLAH_KURSI->cellAttributes() ?>>
<span id="el_ruang_kelas_JUMLAH_KURSI">
<input type="text" data-table="ruang_kelas" data-field="x_JUMLAH_KURSI" name="x_JUMLAH_KURSI" id="x_JUMLAH_KURSI" size="30" maxlength="4" placeholder="<?php echo HtmlEncode($ruang_kelas_edit->JUMLAH_KURSI->getPlaceHolder()) ?>" value="<?php echo $ruang_kelas_edit->JUMLAH_KURSI->EditValue ?>"<?php echo $ruang_kelas_edit->JUMLAH_KURSI->editAttributes() ?>>
</span>
<?php echo $ruang_kelas_edit->JUMLAH_KURSI->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($ruang_kelas_edit->KETERANGAN_RUANG->Visible) { // KETERANGAN_RUANG ?>
	<div id="r_KETERANGAN_RUANG" class="form-group row">
		<label id="elh_ruang_kelas_KETERANGAN_RUANG" for="x_KETERANGAN_RUANG" class="<?php echo $ruang_kelas_edit->LeftColumnClass ?>"><?php echo $ruang_kelas_edit->KETERANGAN_RUANG->caption() ?><?php echo $ruang_kelas_edit->KETERANGAN_RUANG->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $ruang_kelas_edit->RightColumnClass ?>"><div <?php echo $ruang_kelas_edit->KETERANGAN_RUANG->cellAttributes() ?>>
<span id="el_ruang_kelas_KETERANGAN_RUANG">
<input type="text" data-table="ruang_kelas" data-field="x_KETERANGAN_RUANG" name="x_KETERANGAN_RUANG" id="x_KETERANGAN_RUANG" size="30" maxlength="200" placeholder="<?php echo HtmlEncode($ruang_kelas_edit->KETERANGAN_RUANG->getPlaceHolder()) ?>" value="<?php echo $ruang_kelas_edit->KETERANGAN_RUANG->EditValue ?>"<?php echo $ruang_kelas_edit->KETERANGAN_RUANG->editAttributes() ?>>
</span>
<?php echo $ruang_kelas_edit->KETERANGAN_RUANG->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($ruang_kelas_edit->KELENGKAPAN_ALAT->Visible) { // KELENGKAPAN_ALAT ?>
	<div id="r_KELENGKAPAN_ALAT" class="form-group row">
		<label id="elh_ruang_kelas_KELENGKAPAN_ALAT" for="x_KELENGKAPAN_ALAT" class="<?php echo $ruang_kelas_edit->LeftColumnClass ?>"><?php echo $ruang_kelas_edit->KELENGKAPAN_ALAT->caption() ?><?php echo $ruang_kelas_edit->KELENGKAPAN_ALAT->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $ruang_kelas_edit->RightColumnClass ?>"><div <?php echo $ruang_kelas_edit->KELENGKAPAN_ALAT->cellAttributes() ?>>
<span id="el_ruang_kelas_KELENGKAPAN_ALAT">
<input type="text" data-table="ruang_kelas" data-field="x_KELENGKAPAN_ALAT" name="x_KELENGKAPAN_ALAT" id="x_KELENGKAPAN_ALAT" size="30" maxlength="200" placeholder="<?php echo HtmlEncode($ruang_kelas_edit->KELENGKAPAN_ALAT->getPlaceHolder()) ?>" value="<?php echo $ruang_kelas_edit->KELENGKAPAN_ALAT->EditValue ?>"<?php echo $ruang_kelas_edit->KELENGKAPAN_ALAT->editAttributes() ?>>
</span>
<?php echo $ruang_kelas_edit->KELENGKAPAN_ALAT->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($ruang_kelas_edit->RENOVASI_TERAKHIR->Visible) { // RENOVASI_TERAKHIR ?>
	<div id="r_RENOVASI_TERAKHIR" class="form-group row">
		<label id="elh_ruang_kelas_RENOVASI_TERAKHIR" for="x_RENOVASI_TERAKHIR" class="<?php echo $ruang_kelas_edit->LeftColumnClass ?>"><?php echo $ruang_kelas_edit->RENOVASI_TERAKHIR->caption() ?><?php echo $ruang_kelas_edit->RENOVASI_TERAKHIR->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $ruang_kelas_edit->RightColumnClass ?>"><div <?php echo $ruang_kelas_edit->RENOVASI_TERAKHIR->cellAttributes() ?>>
<span id="el_ruang_kelas_RENOVASI_TERAKHIR">
<input type="text" data-table="ruang_kelas" data-field="x_RENOVASI_TERAKHIR" name="x_RENOVASI_TERAKHIR" id="x_RENOVASI_TERAKHIR" maxlength="10" placeholder="<?php echo HtmlEncode($ruang_kelas_edit->RENOVASI_TERAKHIR->getPlaceHolder()) ?>" value="<?php echo $ruang_kelas_edit->RENOVASI_TERAKHIR->EditValue ?>"<?php echo $ruang_kelas_edit->RENOVASI_TERAKHIR->editAttributes() ?>>
</span>
<?php echo $ruang_kelas_edit->RENOVASI_TERAKHIR->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$ruang_kelas_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $ruang_kelas_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $ruang_kelas_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$ruang_kelas_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$ruang_kelas_edit->terminate();
?>