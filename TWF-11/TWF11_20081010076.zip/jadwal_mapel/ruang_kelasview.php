<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$ruang_kelas_view = new ruang_kelas_view();

// Run the page
$ruang_kelas_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$ruang_kelas_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$ruang_kelas_view->isExport()) { ?>
<script>
var fruang_kelasview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fruang_kelasview = currentForm = new ew.Form("fruang_kelasview", "view");
	loadjs.done("fruang_kelasview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$ruang_kelas_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $ruang_kelas_view->ExportOptions->render("body") ?>
<?php $ruang_kelas_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $ruang_kelas_view->showPageHeader(); ?>
<?php
$ruang_kelas_view->showMessage();
?>
<form name="fruang_kelasview" id="fruang_kelasview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="ruang_kelas">
<input type="hidden" name="modal" value="<?php echo (int)$ruang_kelas_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($ruang_kelas_view->IDRUANG->Visible) { // IDRUANG ?>
	<tr id="r_IDRUANG">
		<td class="<?php echo $ruang_kelas_view->TableLeftColumnClass ?>"><span id="elh_ruang_kelas_IDRUANG"><?php echo $ruang_kelas_view->IDRUANG->caption() ?></span></td>
		<td data-name="IDRUANG" <?php echo $ruang_kelas_view->IDRUANG->cellAttributes() ?>>
<span id="el_ruang_kelas_IDRUANG">
<span<?php echo $ruang_kelas_view->IDRUANG->viewAttributes() ?>><?php echo $ruang_kelas_view->IDRUANG->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($ruang_kelas_view->NAMA_RUANG->Visible) { // NAMA_RUANG ?>
	<tr id="r_NAMA_RUANG">
		<td class="<?php echo $ruang_kelas_view->TableLeftColumnClass ?>"><span id="elh_ruang_kelas_NAMA_RUANG"><?php echo $ruang_kelas_view->NAMA_RUANG->caption() ?></span></td>
		<td data-name="NAMA_RUANG" <?php echo $ruang_kelas_view->NAMA_RUANG->cellAttributes() ?>>
<span id="el_ruang_kelas_NAMA_RUANG">
<span<?php echo $ruang_kelas_view->NAMA_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_view->NAMA_RUANG->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($ruang_kelas_view->TIPE_RUANG->Visible) { // TIPE_RUANG ?>
	<tr id="r_TIPE_RUANG">
		<td class="<?php echo $ruang_kelas_view->TableLeftColumnClass ?>"><span id="elh_ruang_kelas_TIPE_RUANG"><?php echo $ruang_kelas_view->TIPE_RUANG->caption() ?></span></td>
		<td data-name="TIPE_RUANG" <?php echo $ruang_kelas_view->TIPE_RUANG->cellAttributes() ?>>
<span id="el_ruang_kelas_TIPE_RUANG">
<span<?php echo $ruang_kelas_view->TIPE_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_view->TIPE_RUANG->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($ruang_kelas_view->UKURAN_RUANG->Visible) { // UKURAN_RUANG ?>
	<tr id="r_UKURAN_RUANG">
		<td class="<?php echo $ruang_kelas_view->TableLeftColumnClass ?>"><span id="elh_ruang_kelas_UKURAN_RUANG"><?php echo $ruang_kelas_view->UKURAN_RUANG->caption() ?></span></td>
		<td data-name="UKURAN_RUANG" <?php echo $ruang_kelas_view->UKURAN_RUANG->cellAttributes() ?>>
<span id="el_ruang_kelas_UKURAN_RUANG">
<span<?php echo $ruang_kelas_view->UKURAN_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_view->UKURAN_RUANG->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($ruang_kelas_view->KAPASITAS_RUANG->Visible) { // KAPASITAS_RUANG ?>
	<tr id="r_KAPASITAS_RUANG">
		<td class="<?php echo $ruang_kelas_view->TableLeftColumnClass ?>"><span id="elh_ruang_kelas_KAPASITAS_RUANG"><?php echo $ruang_kelas_view->KAPASITAS_RUANG->caption() ?></span></td>
		<td data-name="KAPASITAS_RUANG" <?php echo $ruang_kelas_view->KAPASITAS_RUANG->cellAttributes() ?>>
<span id="el_ruang_kelas_KAPASITAS_RUANG">
<span<?php echo $ruang_kelas_view->KAPASITAS_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_view->KAPASITAS_RUANG->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($ruang_kelas_view->JUMLAH_MEJA->Visible) { // JUMLAH_MEJA ?>
	<tr id="r_JUMLAH_MEJA">
		<td class="<?php echo $ruang_kelas_view->TableLeftColumnClass ?>"><span id="elh_ruang_kelas_JUMLAH_MEJA"><?php echo $ruang_kelas_view->JUMLAH_MEJA->caption() ?></span></td>
		<td data-name="JUMLAH_MEJA" <?php echo $ruang_kelas_view->JUMLAH_MEJA->cellAttributes() ?>>
<span id="el_ruang_kelas_JUMLAH_MEJA">
<span<?php echo $ruang_kelas_view->JUMLAH_MEJA->viewAttributes() ?>><?php echo $ruang_kelas_view->JUMLAH_MEJA->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($ruang_kelas_view->JUMLAH_KURSI->Visible) { // JUMLAH_KURSI ?>
	<tr id="r_JUMLAH_KURSI">
		<td class="<?php echo $ruang_kelas_view->TableLeftColumnClass ?>"><span id="elh_ruang_kelas_JUMLAH_KURSI"><?php echo $ruang_kelas_view->JUMLAH_KURSI->caption() ?></span></td>
		<td data-name="JUMLAH_KURSI" <?php echo $ruang_kelas_view->JUMLAH_KURSI->cellAttributes() ?>>
<span id="el_ruang_kelas_JUMLAH_KURSI">
<span<?php echo $ruang_kelas_view->JUMLAH_KURSI->viewAttributes() ?>><?php echo $ruang_kelas_view->JUMLAH_KURSI->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($ruang_kelas_view->KETERANGAN_RUANG->Visible) { // KETERANGAN_RUANG ?>
	<tr id="r_KETERANGAN_RUANG">
		<td class="<?php echo $ruang_kelas_view->TableLeftColumnClass ?>"><span id="elh_ruang_kelas_KETERANGAN_RUANG"><?php echo $ruang_kelas_view->KETERANGAN_RUANG->caption() ?></span></td>
		<td data-name="KETERANGAN_RUANG" <?php echo $ruang_kelas_view->KETERANGAN_RUANG->cellAttributes() ?>>
<span id="el_ruang_kelas_KETERANGAN_RUANG">
<span<?php echo $ruang_kelas_view->KETERANGAN_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_view->KETERANGAN_RUANG->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($ruang_kelas_view->KELENGKAPAN_ALAT->Visible) { // KELENGKAPAN_ALAT ?>
	<tr id="r_KELENGKAPAN_ALAT">
		<td class="<?php echo $ruang_kelas_view->TableLeftColumnClass ?>"><span id="elh_ruang_kelas_KELENGKAPAN_ALAT"><?php echo $ruang_kelas_view->KELENGKAPAN_ALAT->caption() ?></span></td>
		<td data-name="KELENGKAPAN_ALAT" <?php echo $ruang_kelas_view->KELENGKAPAN_ALAT->cellAttributes() ?>>
<span id="el_ruang_kelas_KELENGKAPAN_ALAT">
<span<?php echo $ruang_kelas_view->KELENGKAPAN_ALAT->viewAttributes() ?>><?php echo $ruang_kelas_view->KELENGKAPAN_ALAT->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($ruang_kelas_view->RENOVASI_TERAKHIR->Visible) { // RENOVASI_TERAKHIR ?>
	<tr id="r_RENOVASI_TERAKHIR">
		<td class="<?php echo $ruang_kelas_view->TableLeftColumnClass ?>"><span id="elh_ruang_kelas_RENOVASI_TERAKHIR"><?php echo $ruang_kelas_view->RENOVASI_TERAKHIR->caption() ?></span></td>
		<td data-name="RENOVASI_TERAKHIR" <?php echo $ruang_kelas_view->RENOVASI_TERAKHIR->cellAttributes() ?>>
<span id="el_ruang_kelas_RENOVASI_TERAKHIR">
<span<?php echo $ruang_kelas_view->RENOVASI_TERAKHIR->viewAttributes() ?>><?php echo $ruang_kelas_view->RENOVASI_TERAKHIR->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$ruang_kelas_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$ruang_kelas_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$ruang_kelas_view->terminate();
?>