<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$jadwal_pelajaran_delete = new jadwal_pelajaran_delete();

// Run the page
$jadwal_pelajaran_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$jadwal_pelajaran_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fjadwal_pelajarandelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fjadwal_pelajarandelete = currentForm = new ew.Form("fjadwal_pelajarandelete", "delete");
	loadjs.done("fjadwal_pelajarandelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $jadwal_pelajaran_delete->showPageHeader(); ?>
<?php
$jadwal_pelajaran_delete->showMessage();
?>
<form name="fjadwal_pelajarandelete" id="fjadwal_pelajarandelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="jadwal_pelajaran">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($jadwal_pelajaran_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($jadwal_pelajaran_delete->IDJADWAL->Visible) { // IDJADWAL ?>
		<th class="<?php echo $jadwal_pelajaran_delete->IDJADWAL->headerCellClass() ?>"><span id="elh_jadwal_pelajaran_IDJADWAL" class="jadwal_pelajaran_IDJADWAL"><?php echo $jadwal_pelajaran_delete->IDJADWAL->caption() ?></span></th>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->ID_GURU->Visible) { // ID_GURU ?>
		<th class="<?php echo $jadwal_pelajaran_delete->ID_GURU->headerCellClass() ?>"><span id="elh_jadwal_pelajaran_ID_GURU" class="jadwal_pelajaran_ID_GURU"><?php echo $jadwal_pelajaran_delete->ID_GURU->caption() ?></span></th>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->KODE_MAPEL->Visible) { // KODE_MAPEL ?>
		<th class="<?php echo $jadwal_pelajaran_delete->KODE_MAPEL->headerCellClass() ?>"><span id="elh_jadwal_pelajaran_KODE_MAPEL" class="jadwal_pelajaran_KODE_MAPEL"><?php echo $jadwal_pelajaran_delete->KODE_MAPEL->caption() ?></span></th>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->IDRUANG->Visible) { // IDRUANG ?>
		<th class="<?php echo $jadwal_pelajaran_delete->IDRUANG->headerCellClass() ?>"><span id="elh_jadwal_pelajaran_IDRUANG" class="jadwal_pelajaran_IDRUANG"><?php echo $jadwal_pelajaran_delete->IDRUANG->caption() ?></span></th>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->NO_INDUK->Visible) { // NO_INDUK ?>
		<th class="<?php echo $jadwal_pelajaran_delete->NO_INDUK->headerCellClass() ?>"><span id="elh_jadwal_pelajaran_NO_INDUK" class="jadwal_pelajaran_NO_INDUK"><?php echo $jadwal_pelajaran_delete->NO_INDUK->caption() ?></span></th>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->HARIJADWAL->Visible) { // HARIJADWAL ?>
		<th class="<?php echo $jadwal_pelajaran_delete->HARIJADWAL->headerCellClass() ?>"><span id="elh_jadwal_pelajaran_HARIJADWAL" class="jadwal_pelajaran_HARIJADWAL"><?php echo $jadwal_pelajaran_delete->HARIJADWAL->caption() ?></span></th>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->SESIJADWAL->Visible) { // SESIJADWAL ?>
		<th class="<?php echo $jadwal_pelajaran_delete->SESIJADWAL->headerCellClass() ?>"><span id="elh_jadwal_pelajaran_SESIJADWAL" class="jadwal_pelajaran_SESIJADWAL"><?php echo $jadwal_pelajaran_delete->SESIJADWAL->caption() ?></span></th>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->WAKTU_MULAI->Visible) { // WAKTU_MULAI ?>
		<th class="<?php echo $jadwal_pelajaran_delete->WAKTU_MULAI->headerCellClass() ?>"><span id="elh_jadwal_pelajaran_WAKTU_MULAI" class="jadwal_pelajaran_WAKTU_MULAI"><?php echo $jadwal_pelajaran_delete->WAKTU_MULAI->caption() ?></span></th>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->WAKTU_SELESAI->Visible) { // WAKTU_SELESAI ?>
		<th class="<?php echo $jadwal_pelajaran_delete->WAKTU_SELESAI->headerCellClass() ?>"><span id="elh_jadwal_pelajaran_WAKTU_SELESAI" class="jadwal_pelajaran_WAKTU_SELESAI"><?php echo $jadwal_pelajaran_delete->WAKTU_SELESAI->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$jadwal_pelajaran_delete->RecordCount = 0;
$i = 0;
while (!$jadwal_pelajaran_delete->Recordset->EOF) {
	$jadwal_pelajaran_delete->RecordCount++;
	$jadwal_pelajaran_delete->RowCount++;

	// Set row properties
	$jadwal_pelajaran->resetAttributes();
	$jadwal_pelajaran->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$jadwal_pelajaran_delete->loadRowValues($jadwal_pelajaran_delete->Recordset);

	// Render row
	$jadwal_pelajaran_delete->renderRow();
?>
	<tr <?php echo $jadwal_pelajaran->rowAttributes() ?>>
<?php if ($jadwal_pelajaran_delete->IDJADWAL->Visible) { // IDJADWAL ?>
		<td <?php echo $jadwal_pelajaran_delete->IDJADWAL->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_delete->RowCount ?>_jadwal_pelajaran_IDJADWAL" class="jadwal_pelajaran_IDJADWAL">
<span<?php echo $jadwal_pelajaran_delete->IDJADWAL->viewAttributes() ?>><?php echo $jadwal_pelajaran_delete->IDJADWAL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->ID_GURU->Visible) { // ID_GURU ?>
		<td <?php echo $jadwal_pelajaran_delete->ID_GURU->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_delete->RowCount ?>_jadwal_pelajaran_ID_GURU" class="jadwal_pelajaran_ID_GURU">
<span<?php echo $jadwal_pelajaran_delete->ID_GURU->viewAttributes() ?>><?php echo $jadwal_pelajaran_delete->ID_GURU->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->KODE_MAPEL->Visible) { // KODE_MAPEL ?>
		<td <?php echo $jadwal_pelajaran_delete->KODE_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_delete->RowCount ?>_jadwal_pelajaran_KODE_MAPEL" class="jadwal_pelajaran_KODE_MAPEL">
<span<?php echo $jadwal_pelajaran_delete->KODE_MAPEL->viewAttributes() ?>><?php echo $jadwal_pelajaran_delete->KODE_MAPEL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->IDRUANG->Visible) { // IDRUANG ?>
		<td <?php echo $jadwal_pelajaran_delete->IDRUANG->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_delete->RowCount ?>_jadwal_pelajaran_IDRUANG" class="jadwal_pelajaran_IDRUANG">
<span<?php echo $jadwal_pelajaran_delete->IDRUANG->viewAttributes() ?>><?php echo $jadwal_pelajaran_delete->IDRUANG->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->NO_INDUK->Visible) { // NO_INDUK ?>
		<td <?php echo $jadwal_pelajaran_delete->NO_INDUK->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_delete->RowCount ?>_jadwal_pelajaran_NO_INDUK" class="jadwal_pelajaran_NO_INDUK">
<span<?php echo $jadwal_pelajaran_delete->NO_INDUK->viewAttributes() ?>><?php echo $jadwal_pelajaran_delete->NO_INDUK->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->HARIJADWAL->Visible) { // HARIJADWAL ?>
		<td <?php echo $jadwal_pelajaran_delete->HARIJADWAL->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_delete->RowCount ?>_jadwal_pelajaran_HARIJADWAL" class="jadwal_pelajaran_HARIJADWAL">
<span<?php echo $jadwal_pelajaran_delete->HARIJADWAL->viewAttributes() ?>><?php echo $jadwal_pelajaran_delete->HARIJADWAL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->SESIJADWAL->Visible) { // SESIJADWAL ?>
		<td <?php echo $jadwal_pelajaran_delete->SESIJADWAL->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_delete->RowCount ?>_jadwal_pelajaran_SESIJADWAL" class="jadwal_pelajaran_SESIJADWAL">
<span<?php echo $jadwal_pelajaran_delete->SESIJADWAL->viewAttributes() ?>><?php echo $jadwal_pelajaran_delete->SESIJADWAL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->WAKTU_MULAI->Visible) { // WAKTU_MULAI ?>
		<td <?php echo $jadwal_pelajaran_delete->WAKTU_MULAI->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_delete->RowCount ?>_jadwal_pelajaran_WAKTU_MULAI" class="jadwal_pelajaran_WAKTU_MULAI">
<span<?php echo $jadwal_pelajaran_delete->WAKTU_MULAI->viewAttributes() ?>><?php echo $jadwal_pelajaran_delete->WAKTU_MULAI->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($jadwal_pelajaran_delete->WAKTU_SELESAI->Visible) { // WAKTU_SELESAI ?>
		<td <?php echo $jadwal_pelajaran_delete->WAKTU_SELESAI->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_delete->RowCount ?>_jadwal_pelajaran_WAKTU_SELESAI" class="jadwal_pelajaran_WAKTU_SELESAI">
<span<?php echo $jadwal_pelajaran_delete->WAKTU_SELESAI->viewAttributes() ?>><?php echo $jadwal_pelajaran_delete->WAKTU_SELESAI->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$jadwal_pelajaran_delete->Recordset->moveNext();
}
$jadwal_pelajaran_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $jadwal_pelajaran_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$jadwal_pelajaran_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$jadwal_pelajaran_delete->terminate();
?>