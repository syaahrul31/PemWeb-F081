<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$mata_pelajaran_view = new mata_pelajaran_view();

// Run the page
$mata_pelajaran_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$mata_pelajaran_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$mata_pelajaran_view->isExport()) { ?>
<script>
var fmata_pelajaranview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fmata_pelajaranview = currentForm = new ew.Form("fmata_pelajaranview", "view");
	loadjs.done("fmata_pelajaranview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$mata_pelajaran_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $mata_pelajaran_view->ExportOptions->render("body") ?>
<?php $mata_pelajaran_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $mata_pelajaran_view->showPageHeader(); ?>
<?php
$mata_pelajaran_view->showMessage();
?>
<form name="fmata_pelajaranview" id="fmata_pelajaranview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="mata_pelajaran">
<input type="hidden" name="modal" value="<?php echo (int)$mata_pelajaran_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($mata_pelajaran_view->KODE_MAPEL->Visible) { // KODE_MAPEL ?>
	<tr id="r_KODE_MAPEL">
		<td class="<?php echo $mata_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_mata_pelajaran_KODE_MAPEL"><?php echo $mata_pelajaran_view->KODE_MAPEL->caption() ?></span></td>
		<td data-name="KODE_MAPEL" <?php echo $mata_pelajaran_view->KODE_MAPEL->cellAttributes() ?>>
<span id="el_mata_pelajaran_KODE_MAPEL">
<span<?php echo $mata_pelajaran_view->KODE_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_view->KODE_MAPEL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($mata_pelajaran_view->NAMA_MAPEL->Visible) { // NAMA_MAPEL ?>
	<tr id="r_NAMA_MAPEL">
		<td class="<?php echo $mata_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_mata_pelajaran_NAMA_MAPEL"><?php echo $mata_pelajaran_view->NAMA_MAPEL->caption() ?></span></td>
		<td data-name="NAMA_MAPEL" <?php echo $mata_pelajaran_view->NAMA_MAPEL->cellAttributes() ?>>
<span id="el_mata_pelajaran_NAMA_MAPEL">
<span<?php echo $mata_pelajaran_view->NAMA_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_view->NAMA_MAPEL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($mata_pelajaran_view->BIDANG_MAPEL->Visible) { // BIDANG_MAPEL ?>
	<tr id="r_BIDANG_MAPEL">
		<td class="<?php echo $mata_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_mata_pelajaran_BIDANG_MAPEL"><?php echo $mata_pelajaran_view->BIDANG_MAPEL->caption() ?></span></td>
		<td data-name="BIDANG_MAPEL" <?php echo $mata_pelajaran_view->BIDANG_MAPEL->cellAttributes() ?>>
<span id="el_mata_pelajaran_BIDANG_MAPEL">
<span<?php echo $mata_pelajaran_view->BIDANG_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_view->BIDANG_MAPEL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($mata_pelajaran_view->JENIS_MAPEL->Visible) { // JENIS_MAPEL ?>
	<tr id="r_JENIS_MAPEL">
		<td class="<?php echo $mata_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_mata_pelajaran_JENIS_MAPEL"><?php echo $mata_pelajaran_view->JENIS_MAPEL->caption() ?></span></td>
		<td data-name="JENIS_MAPEL" <?php echo $mata_pelajaran_view->JENIS_MAPEL->cellAttributes() ?>>
<span id="el_mata_pelajaran_JENIS_MAPEL">
<span<?php echo $mata_pelajaran_view->JENIS_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_view->JENIS_MAPEL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($mata_pelajaran_view->TIPE_MAPEL->Visible) { // TIPE_MAPEL ?>
	<tr id="r_TIPE_MAPEL">
		<td class="<?php echo $mata_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_mata_pelajaran_TIPE_MAPEL"><?php echo $mata_pelajaran_view->TIPE_MAPEL->caption() ?></span></td>
		<td data-name="TIPE_MAPEL" <?php echo $mata_pelajaran_view->TIPE_MAPEL->cellAttributes() ?>>
<span id="el_mata_pelajaran_TIPE_MAPEL">
<span<?php echo $mata_pelajaran_view->TIPE_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_view->TIPE_MAPEL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($mata_pelajaran_view->JUMLAH_PERTEMUAN->Visible) { // JUMLAH_PERTEMUAN ?>
	<tr id="r_JUMLAH_PERTEMUAN">
		<td class="<?php echo $mata_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_mata_pelajaran_JUMLAH_PERTEMUAN"><?php echo $mata_pelajaran_view->JUMLAH_PERTEMUAN->caption() ?></span></td>
		<td data-name="JUMLAH_PERTEMUAN" <?php echo $mata_pelajaran_view->JUMLAH_PERTEMUAN->cellAttributes() ?>>
<span id="el_mata_pelajaran_JUMLAH_PERTEMUAN">
<span<?php echo $mata_pelajaran_view->JUMLAH_PERTEMUAN->viewAttributes() ?>><?php echo $mata_pelajaran_view->JUMLAH_PERTEMUAN->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($mata_pelajaran_view->DURASI_MAPEL->Visible) { // DURASI_MAPEL ?>
	<tr id="r_DURASI_MAPEL">
		<td class="<?php echo $mata_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_mata_pelajaran_DURASI_MAPEL"><?php echo $mata_pelajaran_view->DURASI_MAPEL->caption() ?></span></td>
		<td data-name="DURASI_MAPEL" <?php echo $mata_pelajaran_view->DURASI_MAPEL->cellAttributes() ?>>
<span id="el_mata_pelajaran_DURASI_MAPEL">
<span<?php echo $mata_pelajaran_view->DURASI_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_view->DURASI_MAPEL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$mata_pelajaran_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$mata_pelajaran_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$mata_pelajaran_view->terminate();
?>