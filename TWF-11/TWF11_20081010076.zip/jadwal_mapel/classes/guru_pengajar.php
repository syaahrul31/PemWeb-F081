<?php namespace PHPMaker2020\project1; ?>
<?php

/**
 * Table class for guru_pengajar
 */
class guru_pengajar extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Export
	public $ExportDoc;

	// Fields
	public $ID_GURU;
	public $NAMA_GURU;
	public $GELAR_DEPAN;
	public $GELAR_BELAKANG;
	public $JENIS_KELAMIN;
	public $AGAMA;
	public $ALAMAT_TINGGAL;
	public $NO_HP;
	public $NO_WA;
	public $ID_TELEGRAM;
	public $ID_LINE;
	public $ID_FACEBOOK;
	public $ID_INSTAGRAM;
	public $ID_TWITTER;
	public $ID_YOUTUBE;
	public $EMAIL_GURU;
	public $TEMPAT_LAHIR;
	public $TANGGAL_LAHIR;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'guru_pengajar';
		$this->TableName = 'guru_pengajar';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`guru_pengajar`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = ""; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = ""; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = 0; // User ID Allow
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// ID_GURU
		$this->ID_GURU = new DbField('guru_pengajar', 'guru_pengajar', 'x_ID_GURU', 'ID_GURU', '`ID_GURU`', '`ID_GURU`', 200, 12, -1, FALSE, '`ID_GURU`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ID_GURU->IsPrimaryKey = TRUE; // Primary key field
		$this->ID_GURU->Nullable = FALSE; // NOT NULL field
		$this->ID_GURU->Required = TRUE; // Required field
		$this->ID_GURU->Sortable = TRUE; // Allow sort
		$this->fields['ID_GURU'] = &$this->ID_GURU;

		// NAMA_GURU
		$this->NAMA_GURU = new DbField('guru_pengajar', 'guru_pengajar', 'x_NAMA_GURU', 'NAMA_GURU', '`NAMA_GURU`', '`NAMA_GURU`', 200, 25, -1, FALSE, '`NAMA_GURU`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->NAMA_GURU->Nullable = FALSE; // NOT NULL field
		$this->NAMA_GURU->Required = TRUE; // Required field
		$this->NAMA_GURU->Sortable = TRUE; // Allow sort
		$this->fields['NAMA_GURU'] = &$this->NAMA_GURU;

		// GELAR_DEPAN
		$this->GELAR_DEPAN = new DbField('guru_pengajar', 'guru_pengajar', 'x_GELAR_DEPAN', 'GELAR_DEPAN', '`GELAR_DEPAN`', '`GELAR_DEPAN`', 200, 10, -1, FALSE, '`GELAR_DEPAN`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->GELAR_DEPAN->Sortable = TRUE; // Allow sort
		$this->fields['GELAR_DEPAN'] = &$this->GELAR_DEPAN;

		// GELAR_BELAKANG
		$this->GELAR_BELAKANG = new DbField('guru_pengajar', 'guru_pengajar', 'x_GELAR_BELAKANG', 'GELAR_BELAKANG', '`GELAR_BELAKANG`', '`GELAR_BELAKANG`', 200, 10, -1, FALSE, '`GELAR_BELAKANG`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->GELAR_BELAKANG->Sortable = TRUE; // Allow sort
		$this->fields['GELAR_BELAKANG'] = &$this->GELAR_BELAKANG;

		// JENIS_KELAMIN
		$this->JENIS_KELAMIN = new DbField('guru_pengajar', 'guru_pengajar', 'x_JENIS_KELAMIN', 'JENIS_KELAMIN', '`JENIS_KELAMIN`', '`JENIS_KELAMIN`', 200, 1, -1, FALSE, '`JENIS_KELAMIN`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->JENIS_KELAMIN->Sortable = TRUE; // Allow sort
		$this->fields['JENIS_KELAMIN'] = &$this->JENIS_KELAMIN;

		// AGAMA
		$this->AGAMA = new DbField('guru_pengajar', 'guru_pengajar', 'x_AGAMA', 'AGAMA', '`AGAMA`', '`AGAMA`', 200, 10, -1, FALSE, '`AGAMA`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->AGAMA->Sortable = TRUE; // Allow sort
		$this->fields['AGAMA'] = &$this->AGAMA;

		// ALAMAT_TINGGAL
		$this->ALAMAT_TINGGAL = new DbField('guru_pengajar', 'guru_pengajar', 'x_ALAMAT_TINGGAL', 'ALAMAT_TINGGAL', '`ALAMAT_TINGGAL`', '`ALAMAT_TINGGAL`', 200, 100, -1, FALSE, '`ALAMAT_TINGGAL`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ALAMAT_TINGGAL->Sortable = TRUE; // Allow sort
		$this->fields['ALAMAT_TINGGAL'] = &$this->ALAMAT_TINGGAL;

		// NO_HP
		$this->NO_HP = new DbField('guru_pengajar', 'guru_pengajar', 'x_NO_HP', 'NO_HP', '`NO_HP`', '`NO_HP`', 200, 15, -1, FALSE, '`NO_HP`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->NO_HP->Sortable = TRUE; // Allow sort
		$this->fields['NO_HP'] = &$this->NO_HP;

		// NO_WA
		$this->NO_WA = new DbField('guru_pengajar', 'guru_pengajar', 'x_NO_WA', 'NO_WA', '`NO_WA`', '`NO_WA`', 200, 15, -1, FALSE, '`NO_WA`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->NO_WA->Sortable = TRUE; // Allow sort
		$this->fields['NO_WA'] = &$this->NO_WA;

		// ID_TELEGRAM
		$this->ID_TELEGRAM = new DbField('guru_pengajar', 'guru_pengajar', 'x_ID_TELEGRAM', 'ID_TELEGRAM', '`ID_TELEGRAM`', '`ID_TELEGRAM`', 200, 25, -1, FALSE, '`ID_TELEGRAM`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ID_TELEGRAM->Sortable = TRUE; // Allow sort
		$this->fields['ID_TELEGRAM'] = &$this->ID_TELEGRAM;

		// ID_LINE
		$this->ID_LINE = new DbField('guru_pengajar', 'guru_pengajar', 'x_ID_LINE', 'ID_LINE', '`ID_LINE`', '`ID_LINE`', 200, 25, -1, FALSE, '`ID_LINE`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ID_LINE->Sortable = TRUE; // Allow sort
		$this->fields['ID_LINE'] = &$this->ID_LINE;

		// ID_FACEBOOK
		$this->ID_FACEBOOK = new DbField('guru_pengajar', 'guru_pengajar', 'x_ID_FACEBOOK', 'ID_FACEBOOK', '`ID_FACEBOOK`', '`ID_FACEBOOK`', 200, 25, -1, FALSE, '`ID_FACEBOOK`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ID_FACEBOOK->Sortable = TRUE; // Allow sort
		$this->fields['ID_FACEBOOK'] = &$this->ID_FACEBOOK;

		// ID_INSTAGRAM
		$this->ID_INSTAGRAM = new DbField('guru_pengajar', 'guru_pengajar', 'x_ID_INSTAGRAM', 'ID_INSTAGRAM', '`ID_INSTAGRAM`', '`ID_INSTAGRAM`', 200, 25, -1, FALSE, '`ID_INSTAGRAM`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ID_INSTAGRAM->Sortable = TRUE; // Allow sort
		$this->fields['ID_INSTAGRAM'] = &$this->ID_INSTAGRAM;

		// ID_TWITTER
		$this->ID_TWITTER = new DbField('guru_pengajar', 'guru_pengajar', 'x_ID_TWITTER', 'ID_TWITTER', '`ID_TWITTER`', '`ID_TWITTER`', 200, 25, -1, FALSE, '`ID_TWITTER`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ID_TWITTER->Sortable = TRUE; // Allow sort
		$this->fields['ID_TWITTER'] = &$this->ID_TWITTER;

		// ID_YOUTUBE
		$this->ID_YOUTUBE = new DbField('guru_pengajar', 'guru_pengajar', 'x_ID_YOUTUBE', 'ID_YOUTUBE', '`ID_YOUTUBE`', '`ID_YOUTUBE`', 200, 25, -1, FALSE, '`ID_YOUTUBE`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ID_YOUTUBE->Sortable = TRUE; // Allow sort
		$this->fields['ID_YOUTUBE'] = &$this->ID_YOUTUBE;

		// EMAIL_GURU
		$this->EMAIL_GURU = new DbField('guru_pengajar', 'guru_pengajar', 'x_EMAIL_GURU', 'EMAIL_GURU', '`EMAIL_GURU`', '`EMAIL_GURU`', 200, 50, -1, FALSE, '`EMAIL_GURU`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->EMAIL_GURU->Sortable = TRUE; // Allow sort
		$this->fields['EMAIL_GURU'] = &$this->EMAIL_GURU;

		// TEMPAT_LAHIR
		$this->TEMPAT_LAHIR = new DbField('guru_pengajar', 'guru_pengajar', 'x_TEMPAT_LAHIR', 'TEMPAT_LAHIR', '`TEMPAT_LAHIR`', '`TEMPAT_LAHIR`', 200, 30, -1, FALSE, '`TEMPAT_LAHIR`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->TEMPAT_LAHIR->Sortable = TRUE; // Allow sort
		$this->fields['TEMPAT_LAHIR'] = &$this->TEMPAT_LAHIR;

		// TANGGAL_LAHIR
		$this->TANGGAL_LAHIR = new DbField('guru_pengajar', 'guru_pengajar', 'x_TANGGAL_LAHIR', 'TANGGAL_LAHIR', '`TANGGAL_LAHIR`', CastDateFieldForLike("`TANGGAL_LAHIR`", 0, "DB"), 133, 10, 0, FALSE, '`TANGGAL_LAHIR`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->TANGGAL_LAHIR->Sortable = TRUE; // Allow sort
		$this->TANGGAL_LAHIR->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['TANGGAL_LAHIR'] = &$this->TANGGAL_LAHIR;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`guru_pengajar`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter)
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = Config("USER_ID_ALLOW");
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('ID_GURU', $rs))
				AddFilter($where, QuotedName('ID_GURU', $this->Dbid) . '=' . QuotedValue($rs['ID_GURU'], $this->ID_GURU->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->ID_GURU->DbValue = $row['ID_GURU'];
		$this->NAMA_GURU->DbValue = $row['NAMA_GURU'];
		$this->GELAR_DEPAN->DbValue = $row['GELAR_DEPAN'];
		$this->GELAR_BELAKANG->DbValue = $row['GELAR_BELAKANG'];
		$this->JENIS_KELAMIN->DbValue = $row['JENIS_KELAMIN'];
		$this->AGAMA->DbValue = $row['AGAMA'];
		$this->ALAMAT_TINGGAL->DbValue = $row['ALAMAT_TINGGAL'];
		$this->NO_HP->DbValue = $row['NO_HP'];
		$this->NO_WA->DbValue = $row['NO_WA'];
		$this->ID_TELEGRAM->DbValue = $row['ID_TELEGRAM'];
		$this->ID_LINE->DbValue = $row['ID_LINE'];
		$this->ID_FACEBOOK->DbValue = $row['ID_FACEBOOK'];
		$this->ID_INSTAGRAM->DbValue = $row['ID_INSTAGRAM'];
		$this->ID_TWITTER->DbValue = $row['ID_TWITTER'];
		$this->ID_YOUTUBE->DbValue = $row['ID_YOUTUBE'];
		$this->EMAIL_GURU->DbValue = $row['EMAIL_GURU'];
		$this->TEMPAT_LAHIR->DbValue = $row['TEMPAT_LAHIR'];
		$this->TANGGAL_LAHIR->DbValue = $row['TANGGAL_LAHIR'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`ID_GURU` = '@ID_GURU@'";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('ID_GURU', $row) ? $row['ID_GURU'] : NULL;
		else
			$val = $this->ID_GURU->OldValue !== NULL ? $this->ID_GURU->OldValue : $this->ID_GURU->CurrentValue;
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@ID_GURU@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "guru_pengajarlist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "guru_pengajarview.php")
			return $Language->phrase("View");
		elseif ($pageName == "guru_pengajaredit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "guru_pengajaradd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "guru_pengajarlist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("guru_pengajarview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("guru_pengajarview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "guru_pengajaradd.php?" . $this->getUrlParm($parm);
		else
			$url = "guru_pengajaradd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("guru_pengajaredit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("guru_pengajaradd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("guru_pengajardelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "ID_GURU:" . JsonEncode($this->ID_GURU->CurrentValue, "string");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->ID_GURU->CurrentValue != NULL) {
			$url .= "ID_GURU=" . urlencode($this->ID_GURU->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("ID_GURU") !== NULL)
				$arKeys[] = Param("ID_GURU");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->ID_GURU->CurrentValue = $key;
			else
				$this->ID_GURU->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->ID_GURU->setDbValue($rs->fields('ID_GURU'));
		$this->NAMA_GURU->setDbValue($rs->fields('NAMA_GURU'));
		$this->GELAR_DEPAN->setDbValue($rs->fields('GELAR_DEPAN'));
		$this->GELAR_BELAKANG->setDbValue($rs->fields('GELAR_BELAKANG'));
		$this->JENIS_KELAMIN->setDbValue($rs->fields('JENIS_KELAMIN'));
		$this->AGAMA->setDbValue($rs->fields('AGAMA'));
		$this->ALAMAT_TINGGAL->setDbValue($rs->fields('ALAMAT_TINGGAL'));
		$this->NO_HP->setDbValue($rs->fields('NO_HP'));
		$this->NO_WA->setDbValue($rs->fields('NO_WA'));
		$this->ID_TELEGRAM->setDbValue($rs->fields('ID_TELEGRAM'));
		$this->ID_LINE->setDbValue($rs->fields('ID_LINE'));
		$this->ID_FACEBOOK->setDbValue($rs->fields('ID_FACEBOOK'));
		$this->ID_INSTAGRAM->setDbValue($rs->fields('ID_INSTAGRAM'));
		$this->ID_TWITTER->setDbValue($rs->fields('ID_TWITTER'));
		$this->ID_YOUTUBE->setDbValue($rs->fields('ID_YOUTUBE'));
		$this->EMAIL_GURU->setDbValue($rs->fields('EMAIL_GURU'));
		$this->TEMPAT_LAHIR->setDbValue($rs->fields('TEMPAT_LAHIR'));
		$this->TANGGAL_LAHIR->setDbValue($rs->fields('TANGGAL_LAHIR'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// ID_GURU
		// NAMA_GURU
		// GELAR_DEPAN
		// GELAR_BELAKANG
		// JENIS_KELAMIN
		// AGAMA
		// ALAMAT_TINGGAL
		// NO_HP
		// NO_WA
		// ID_TELEGRAM
		// ID_LINE
		// ID_FACEBOOK
		// ID_INSTAGRAM
		// ID_TWITTER
		// ID_YOUTUBE
		// EMAIL_GURU
		// TEMPAT_LAHIR
		// TANGGAL_LAHIR
		// ID_GURU

		$this->ID_GURU->ViewValue = $this->ID_GURU->CurrentValue;
		$this->ID_GURU->ViewCustomAttributes = "";

		// NAMA_GURU
		$this->NAMA_GURU->ViewValue = $this->NAMA_GURU->CurrentValue;
		$this->NAMA_GURU->ViewCustomAttributes = "";

		// GELAR_DEPAN
		$this->GELAR_DEPAN->ViewValue = $this->GELAR_DEPAN->CurrentValue;
		$this->GELAR_DEPAN->ViewCustomAttributes = "";

		// GELAR_BELAKANG
		$this->GELAR_BELAKANG->ViewValue = $this->GELAR_BELAKANG->CurrentValue;
		$this->GELAR_BELAKANG->ViewCustomAttributes = "";

		// JENIS_KELAMIN
		$this->JENIS_KELAMIN->ViewValue = $this->JENIS_KELAMIN->CurrentValue;
		$this->JENIS_KELAMIN->ViewCustomAttributes = "";

		// AGAMA
		$this->AGAMA->ViewValue = $this->AGAMA->CurrentValue;
		$this->AGAMA->ViewCustomAttributes = "";

		// ALAMAT_TINGGAL
		$this->ALAMAT_TINGGAL->ViewValue = $this->ALAMAT_TINGGAL->CurrentValue;
		$this->ALAMAT_TINGGAL->ViewCustomAttributes = "";

		// NO_HP
		$this->NO_HP->ViewValue = $this->NO_HP->CurrentValue;
		$this->NO_HP->ViewCustomAttributes = "";

		// NO_WA
		$this->NO_WA->ViewValue = $this->NO_WA->CurrentValue;
		$this->NO_WA->ViewCustomAttributes = "";

		// ID_TELEGRAM
		$this->ID_TELEGRAM->ViewValue = $this->ID_TELEGRAM->CurrentValue;
		$this->ID_TELEGRAM->ViewCustomAttributes = "";

		// ID_LINE
		$this->ID_LINE->ViewValue = $this->ID_LINE->CurrentValue;
		$this->ID_LINE->ViewCustomAttributes = "";

		// ID_FACEBOOK
		$this->ID_FACEBOOK->ViewValue = $this->ID_FACEBOOK->CurrentValue;
		$this->ID_FACEBOOK->ViewCustomAttributes = "";

		// ID_INSTAGRAM
		$this->ID_INSTAGRAM->ViewValue = $this->ID_INSTAGRAM->CurrentValue;
		$this->ID_INSTAGRAM->ViewCustomAttributes = "";

		// ID_TWITTER
		$this->ID_TWITTER->ViewValue = $this->ID_TWITTER->CurrentValue;
		$this->ID_TWITTER->ViewCustomAttributes = "";

		// ID_YOUTUBE
		$this->ID_YOUTUBE->ViewValue = $this->ID_YOUTUBE->CurrentValue;
		$this->ID_YOUTUBE->ViewCustomAttributes = "";

		// EMAIL_GURU
		$this->EMAIL_GURU->ViewValue = $this->EMAIL_GURU->CurrentValue;
		$this->EMAIL_GURU->ViewCustomAttributes = "";

		// TEMPAT_LAHIR
		$this->TEMPAT_LAHIR->ViewValue = $this->TEMPAT_LAHIR->CurrentValue;
		$this->TEMPAT_LAHIR->ViewCustomAttributes = "";

		// TANGGAL_LAHIR
		$this->TANGGAL_LAHIR->ViewValue = $this->TANGGAL_LAHIR->CurrentValue;
		$this->TANGGAL_LAHIR->ViewValue = FormatDateTime($this->TANGGAL_LAHIR->ViewValue, 0);
		$this->TANGGAL_LAHIR->ViewCustomAttributes = "";

		// ID_GURU
		$this->ID_GURU->LinkCustomAttributes = "";
		$this->ID_GURU->HrefValue = "";
		$this->ID_GURU->TooltipValue = "";

		// NAMA_GURU
		$this->NAMA_GURU->LinkCustomAttributes = "";
		$this->NAMA_GURU->HrefValue = "";
		$this->NAMA_GURU->TooltipValue = "";

		// GELAR_DEPAN
		$this->GELAR_DEPAN->LinkCustomAttributes = "";
		$this->GELAR_DEPAN->HrefValue = "";
		$this->GELAR_DEPAN->TooltipValue = "";

		// GELAR_BELAKANG
		$this->GELAR_BELAKANG->LinkCustomAttributes = "";
		$this->GELAR_BELAKANG->HrefValue = "";
		$this->GELAR_BELAKANG->TooltipValue = "";

		// JENIS_KELAMIN
		$this->JENIS_KELAMIN->LinkCustomAttributes = "";
		$this->JENIS_KELAMIN->HrefValue = "";
		$this->JENIS_KELAMIN->TooltipValue = "";

		// AGAMA
		$this->AGAMA->LinkCustomAttributes = "";
		$this->AGAMA->HrefValue = "";
		$this->AGAMA->TooltipValue = "";

		// ALAMAT_TINGGAL
		$this->ALAMAT_TINGGAL->LinkCustomAttributes = "";
		$this->ALAMAT_TINGGAL->HrefValue = "";
		$this->ALAMAT_TINGGAL->TooltipValue = "";

		// NO_HP
		$this->NO_HP->LinkCustomAttributes = "";
		$this->NO_HP->HrefValue = "";
		$this->NO_HP->TooltipValue = "";

		// NO_WA
		$this->NO_WA->LinkCustomAttributes = "";
		$this->NO_WA->HrefValue = "";
		$this->NO_WA->TooltipValue = "";

		// ID_TELEGRAM
		$this->ID_TELEGRAM->LinkCustomAttributes = "";
		$this->ID_TELEGRAM->HrefValue = "";
		$this->ID_TELEGRAM->TooltipValue = "";

		// ID_LINE
		$this->ID_LINE->LinkCustomAttributes = "";
		$this->ID_LINE->HrefValue = "";
		$this->ID_LINE->TooltipValue = "";

		// ID_FACEBOOK
		$this->ID_FACEBOOK->LinkCustomAttributes = "";
		$this->ID_FACEBOOK->HrefValue = "";
		$this->ID_FACEBOOK->TooltipValue = "";

		// ID_INSTAGRAM
		$this->ID_INSTAGRAM->LinkCustomAttributes = "";
		$this->ID_INSTAGRAM->HrefValue = "";
		$this->ID_INSTAGRAM->TooltipValue = "";

		// ID_TWITTER
		$this->ID_TWITTER->LinkCustomAttributes = "";
		$this->ID_TWITTER->HrefValue = "";
		$this->ID_TWITTER->TooltipValue = "";

		// ID_YOUTUBE
		$this->ID_YOUTUBE->LinkCustomAttributes = "";
		$this->ID_YOUTUBE->HrefValue = "";
		$this->ID_YOUTUBE->TooltipValue = "";

		// EMAIL_GURU
		$this->EMAIL_GURU->LinkCustomAttributes = "";
		$this->EMAIL_GURU->HrefValue = "";
		$this->EMAIL_GURU->TooltipValue = "";

		// TEMPAT_LAHIR
		$this->TEMPAT_LAHIR->LinkCustomAttributes = "";
		$this->TEMPAT_LAHIR->HrefValue = "";
		$this->TEMPAT_LAHIR->TooltipValue = "";

		// TANGGAL_LAHIR
		$this->TANGGAL_LAHIR->LinkCustomAttributes = "";
		$this->TANGGAL_LAHIR->HrefValue = "";
		$this->TANGGAL_LAHIR->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// ID_GURU
		$this->ID_GURU->EditAttrs["class"] = "form-control";
		$this->ID_GURU->EditCustomAttributes = "";
		if (!$this->ID_GURU->Raw)
			$this->ID_GURU->CurrentValue = HtmlDecode($this->ID_GURU->CurrentValue);
		$this->ID_GURU->EditValue = $this->ID_GURU->CurrentValue;
		$this->ID_GURU->PlaceHolder = RemoveHtml($this->ID_GURU->caption());

		// NAMA_GURU
		$this->NAMA_GURU->EditAttrs["class"] = "form-control";
		$this->NAMA_GURU->EditCustomAttributes = "";
		if (!$this->NAMA_GURU->Raw)
			$this->NAMA_GURU->CurrentValue = HtmlDecode($this->NAMA_GURU->CurrentValue);
		$this->NAMA_GURU->EditValue = $this->NAMA_GURU->CurrentValue;
		$this->NAMA_GURU->PlaceHolder = RemoveHtml($this->NAMA_GURU->caption());

		// GELAR_DEPAN
		$this->GELAR_DEPAN->EditAttrs["class"] = "form-control";
		$this->GELAR_DEPAN->EditCustomAttributes = "";
		if (!$this->GELAR_DEPAN->Raw)
			$this->GELAR_DEPAN->CurrentValue = HtmlDecode($this->GELAR_DEPAN->CurrentValue);
		$this->GELAR_DEPAN->EditValue = $this->GELAR_DEPAN->CurrentValue;
		$this->GELAR_DEPAN->PlaceHolder = RemoveHtml($this->GELAR_DEPAN->caption());

		// GELAR_BELAKANG
		$this->GELAR_BELAKANG->EditAttrs["class"] = "form-control";
		$this->GELAR_BELAKANG->EditCustomAttributes = "";
		if (!$this->GELAR_BELAKANG->Raw)
			$this->GELAR_BELAKANG->CurrentValue = HtmlDecode($this->GELAR_BELAKANG->CurrentValue);
		$this->GELAR_BELAKANG->EditValue = $this->GELAR_BELAKANG->CurrentValue;
		$this->GELAR_BELAKANG->PlaceHolder = RemoveHtml($this->GELAR_BELAKANG->caption());

		// JENIS_KELAMIN
		$this->JENIS_KELAMIN->EditAttrs["class"] = "form-control";
		$this->JENIS_KELAMIN->EditCustomAttributes = "";
		if (!$this->JENIS_KELAMIN->Raw)
			$this->JENIS_KELAMIN->CurrentValue = HtmlDecode($this->JENIS_KELAMIN->CurrentValue);
		$this->JENIS_KELAMIN->EditValue = $this->JENIS_KELAMIN->CurrentValue;
		$this->JENIS_KELAMIN->PlaceHolder = RemoveHtml($this->JENIS_KELAMIN->caption());

		// AGAMA
		$this->AGAMA->EditAttrs["class"] = "form-control";
		$this->AGAMA->EditCustomAttributes = "";
		if (!$this->AGAMA->Raw)
			$this->AGAMA->CurrentValue = HtmlDecode($this->AGAMA->CurrentValue);
		$this->AGAMA->EditValue = $this->AGAMA->CurrentValue;
		$this->AGAMA->PlaceHolder = RemoveHtml($this->AGAMA->caption());

		// ALAMAT_TINGGAL
		$this->ALAMAT_TINGGAL->EditAttrs["class"] = "form-control";
		$this->ALAMAT_TINGGAL->EditCustomAttributes = "";
		if (!$this->ALAMAT_TINGGAL->Raw)
			$this->ALAMAT_TINGGAL->CurrentValue = HtmlDecode($this->ALAMAT_TINGGAL->CurrentValue);
		$this->ALAMAT_TINGGAL->EditValue = $this->ALAMAT_TINGGAL->CurrentValue;
		$this->ALAMAT_TINGGAL->PlaceHolder = RemoveHtml($this->ALAMAT_TINGGAL->caption());

		// NO_HP
		$this->NO_HP->EditAttrs["class"] = "form-control";
		$this->NO_HP->EditCustomAttributes = "";
		if (!$this->NO_HP->Raw)
			$this->NO_HP->CurrentValue = HtmlDecode($this->NO_HP->CurrentValue);
		$this->NO_HP->EditValue = $this->NO_HP->CurrentValue;
		$this->NO_HP->PlaceHolder = RemoveHtml($this->NO_HP->caption());

		// NO_WA
		$this->NO_WA->EditAttrs["class"] = "form-control";
		$this->NO_WA->EditCustomAttributes = "";
		if (!$this->NO_WA->Raw)
			$this->NO_WA->CurrentValue = HtmlDecode($this->NO_WA->CurrentValue);
		$this->NO_WA->EditValue = $this->NO_WA->CurrentValue;
		$this->NO_WA->PlaceHolder = RemoveHtml($this->NO_WA->caption());

		// ID_TELEGRAM
		$this->ID_TELEGRAM->EditAttrs["class"] = "form-control";
		$this->ID_TELEGRAM->EditCustomAttributes = "";
		if (!$this->ID_TELEGRAM->Raw)
			$this->ID_TELEGRAM->CurrentValue = HtmlDecode($this->ID_TELEGRAM->CurrentValue);
		$this->ID_TELEGRAM->EditValue = $this->ID_TELEGRAM->CurrentValue;
		$this->ID_TELEGRAM->PlaceHolder = RemoveHtml($this->ID_TELEGRAM->caption());

		// ID_LINE
		$this->ID_LINE->EditAttrs["class"] = "form-control";
		$this->ID_LINE->EditCustomAttributes = "";
		if (!$this->ID_LINE->Raw)
			$this->ID_LINE->CurrentValue = HtmlDecode($this->ID_LINE->CurrentValue);
		$this->ID_LINE->EditValue = $this->ID_LINE->CurrentValue;
		$this->ID_LINE->PlaceHolder = RemoveHtml($this->ID_LINE->caption());

		// ID_FACEBOOK
		$this->ID_FACEBOOK->EditAttrs["class"] = "form-control";
		$this->ID_FACEBOOK->EditCustomAttributes = "";
		if (!$this->ID_FACEBOOK->Raw)
			$this->ID_FACEBOOK->CurrentValue = HtmlDecode($this->ID_FACEBOOK->CurrentValue);
		$this->ID_FACEBOOK->EditValue = $this->ID_FACEBOOK->CurrentValue;
		$this->ID_FACEBOOK->PlaceHolder = RemoveHtml($this->ID_FACEBOOK->caption());

		// ID_INSTAGRAM
		$this->ID_INSTAGRAM->EditAttrs["class"] = "form-control";
		$this->ID_INSTAGRAM->EditCustomAttributes = "";
		if (!$this->ID_INSTAGRAM->Raw)
			$this->ID_INSTAGRAM->CurrentValue = HtmlDecode($this->ID_INSTAGRAM->CurrentValue);
		$this->ID_INSTAGRAM->EditValue = $this->ID_INSTAGRAM->CurrentValue;
		$this->ID_INSTAGRAM->PlaceHolder = RemoveHtml($this->ID_INSTAGRAM->caption());

		// ID_TWITTER
		$this->ID_TWITTER->EditAttrs["class"] = "form-control";
		$this->ID_TWITTER->EditCustomAttributes = "";
		if (!$this->ID_TWITTER->Raw)
			$this->ID_TWITTER->CurrentValue = HtmlDecode($this->ID_TWITTER->CurrentValue);
		$this->ID_TWITTER->EditValue = $this->ID_TWITTER->CurrentValue;
		$this->ID_TWITTER->PlaceHolder = RemoveHtml($this->ID_TWITTER->caption());

		// ID_YOUTUBE
		$this->ID_YOUTUBE->EditAttrs["class"] = "form-control";
		$this->ID_YOUTUBE->EditCustomAttributes = "";
		if (!$this->ID_YOUTUBE->Raw)
			$this->ID_YOUTUBE->CurrentValue = HtmlDecode($this->ID_YOUTUBE->CurrentValue);
		$this->ID_YOUTUBE->EditValue = $this->ID_YOUTUBE->CurrentValue;
		$this->ID_YOUTUBE->PlaceHolder = RemoveHtml($this->ID_YOUTUBE->caption());

		// EMAIL_GURU
		$this->EMAIL_GURU->EditAttrs["class"] = "form-control";
		$this->EMAIL_GURU->EditCustomAttributes = "";
		if (!$this->EMAIL_GURU->Raw)
			$this->EMAIL_GURU->CurrentValue = HtmlDecode($this->EMAIL_GURU->CurrentValue);
		$this->EMAIL_GURU->EditValue = $this->EMAIL_GURU->CurrentValue;
		$this->EMAIL_GURU->PlaceHolder = RemoveHtml($this->EMAIL_GURU->caption());

		// TEMPAT_LAHIR
		$this->TEMPAT_LAHIR->EditAttrs["class"] = "form-control";
		$this->TEMPAT_LAHIR->EditCustomAttributes = "";
		if (!$this->TEMPAT_LAHIR->Raw)
			$this->TEMPAT_LAHIR->CurrentValue = HtmlDecode($this->TEMPAT_LAHIR->CurrentValue);
		$this->TEMPAT_LAHIR->EditValue = $this->TEMPAT_LAHIR->CurrentValue;
		$this->TEMPAT_LAHIR->PlaceHolder = RemoveHtml($this->TEMPAT_LAHIR->caption());

		// TANGGAL_LAHIR
		$this->TANGGAL_LAHIR->EditAttrs["class"] = "form-control";
		$this->TANGGAL_LAHIR->EditCustomAttributes = "";
		$this->TANGGAL_LAHIR->EditValue = FormatDateTime($this->TANGGAL_LAHIR->CurrentValue, 8);
		$this->TANGGAL_LAHIR->PlaceHolder = RemoveHtml($this->TANGGAL_LAHIR->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->ID_GURU);
					$doc->exportCaption($this->NAMA_GURU);
					$doc->exportCaption($this->GELAR_DEPAN);
					$doc->exportCaption($this->GELAR_BELAKANG);
					$doc->exportCaption($this->JENIS_KELAMIN);
					$doc->exportCaption($this->AGAMA);
					$doc->exportCaption($this->ALAMAT_TINGGAL);
					$doc->exportCaption($this->NO_HP);
					$doc->exportCaption($this->NO_WA);
					$doc->exportCaption($this->ID_TELEGRAM);
					$doc->exportCaption($this->ID_LINE);
					$doc->exportCaption($this->ID_FACEBOOK);
					$doc->exportCaption($this->ID_INSTAGRAM);
					$doc->exportCaption($this->ID_TWITTER);
					$doc->exportCaption($this->ID_YOUTUBE);
					$doc->exportCaption($this->EMAIL_GURU);
					$doc->exportCaption($this->TEMPAT_LAHIR);
					$doc->exportCaption($this->TANGGAL_LAHIR);
				} else {
					$doc->exportCaption($this->ID_GURU);
					$doc->exportCaption($this->NAMA_GURU);
					$doc->exportCaption($this->GELAR_DEPAN);
					$doc->exportCaption($this->GELAR_BELAKANG);
					$doc->exportCaption($this->JENIS_KELAMIN);
					$doc->exportCaption($this->AGAMA);
					$doc->exportCaption($this->ALAMAT_TINGGAL);
					$doc->exportCaption($this->NO_HP);
					$doc->exportCaption($this->NO_WA);
					$doc->exportCaption($this->ID_TELEGRAM);
					$doc->exportCaption($this->ID_LINE);
					$doc->exportCaption($this->ID_FACEBOOK);
					$doc->exportCaption($this->ID_INSTAGRAM);
					$doc->exportCaption($this->ID_TWITTER);
					$doc->exportCaption($this->ID_YOUTUBE);
					$doc->exportCaption($this->EMAIL_GURU);
					$doc->exportCaption($this->TEMPAT_LAHIR);
					$doc->exportCaption($this->TANGGAL_LAHIR);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->ID_GURU);
						$doc->exportField($this->NAMA_GURU);
						$doc->exportField($this->GELAR_DEPAN);
						$doc->exportField($this->GELAR_BELAKANG);
						$doc->exportField($this->JENIS_KELAMIN);
						$doc->exportField($this->AGAMA);
						$doc->exportField($this->ALAMAT_TINGGAL);
						$doc->exportField($this->NO_HP);
						$doc->exportField($this->NO_WA);
						$doc->exportField($this->ID_TELEGRAM);
						$doc->exportField($this->ID_LINE);
						$doc->exportField($this->ID_FACEBOOK);
						$doc->exportField($this->ID_INSTAGRAM);
						$doc->exportField($this->ID_TWITTER);
						$doc->exportField($this->ID_YOUTUBE);
						$doc->exportField($this->EMAIL_GURU);
						$doc->exportField($this->TEMPAT_LAHIR);
						$doc->exportField($this->TANGGAL_LAHIR);
					} else {
						$doc->exportField($this->ID_GURU);
						$doc->exportField($this->NAMA_GURU);
						$doc->exportField($this->GELAR_DEPAN);
						$doc->exportField($this->GELAR_BELAKANG);
						$doc->exportField($this->JENIS_KELAMIN);
						$doc->exportField($this->AGAMA);
						$doc->exportField($this->ALAMAT_TINGGAL);
						$doc->exportField($this->NO_HP);
						$doc->exportField($this->NO_WA);
						$doc->exportField($this->ID_TELEGRAM);
						$doc->exportField($this->ID_LINE);
						$doc->exportField($this->ID_FACEBOOK);
						$doc->exportField($this->ID_INSTAGRAM);
						$doc->exportField($this->ID_TWITTER);
						$doc->exportField($this->ID_YOUTUBE);
						$doc->exportField($this->EMAIL_GURU);
						$doc->exportField($this->TEMPAT_LAHIR);
						$doc->exportField($this->TANGGAL_LAHIR);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>