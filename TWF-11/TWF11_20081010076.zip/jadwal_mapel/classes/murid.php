<?php namespace PHPMaker2020\project1; ?>
<?php

/**
 * Table class for murid
 */
class murid extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Export
	public $ExportDoc;

	// Fields
	public $NO_INDUK;
	public $NAMA_MURID;
	public $JEN_KEL;
	public $AGAMA_MURID;
	public $ALAMAT_RUMAH;
	public $TEMPATLAHIR;
	public $TGL_LAHIR;
	public $NOHP;
	public $NOWA;
	public $IDTELEGRAM;
	public $IDLINE;
	public $IDFACEBOOK;
	public $IDINSTAGRAM;
	public $IDTWITTER;
	public $IDYOUTUBE;
	public $_EMAIL;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'murid';
		$this->TableName = 'murid';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`murid`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = ""; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = ""; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = 0; // User ID Allow
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// NO_INDUK
		$this->NO_INDUK = new DbField('murid', 'murid', 'x_NO_INDUK', 'NO_INDUK', '`NO_INDUK`', '`NO_INDUK`', 200, 10, -1, FALSE, '`NO_INDUK`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->NO_INDUK->IsPrimaryKey = TRUE; // Primary key field
		$this->NO_INDUK->Nullable = FALSE; // NOT NULL field
		$this->NO_INDUK->Required = TRUE; // Required field
		$this->NO_INDUK->Sortable = TRUE; // Allow sort
		$this->fields['NO_INDUK'] = &$this->NO_INDUK;

		// NAMA_MURID
		$this->NAMA_MURID = new DbField('murid', 'murid', 'x_NAMA_MURID', 'NAMA_MURID', '`NAMA_MURID`', '`NAMA_MURID`', 200, 25, -1, FALSE, '`NAMA_MURID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->NAMA_MURID->Nullable = FALSE; // NOT NULL field
		$this->NAMA_MURID->Required = TRUE; // Required field
		$this->NAMA_MURID->Sortable = TRUE; // Allow sort
		$this->fields['NAMA_MURID'] = &$this->NAMA_MURID;

		// JEN_KEL
		$this->JEN_KEL = new DbField('murid', 'murid', 'x_JEN_KEL', 'JEN_KEL', '`JEN_KEL`', '`JEN_KEL`', 200, 1, -1, FALSE, '`JEN_KEL`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->JEN_KEL->Sortable = TRUE; // Allow sort
		$this->fields['JEN_KEL'] = &$this->JEN_KEL;

		// AGAMA_MURID
		$this->AGAMA_MURID = new DbField('murid', 'murid', 'x_AGAMA_MURID', 'AGAMA_MURID', '`AGAMA_MURID`', '`AGAMA_MURID`', 200, 10, -1, FALSE, '`AGAMA_MURID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->AGAMA_MURID->Sortable = TRUE; // Allow sort
		$this->fields['AGAMA_MURID'] = &$this->AGAMA_MURID;

		// ALAMAT_RUMAH
		$this->ALAMAT_RUMAH = new DbField('murid', 'murid', 'x_ALAMAT_RUMAH', 'ALAMAT_RUMAH', '`ALAMAT_RUMAH`', '`ALAMAT_RUMAH`', 200, 50, -1, FALSE, '`ALAMAT_RUMAH`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ALAMAT_RUMAH->Sortable = TRUE; // Allow sort
		$this->fields['ALAMAT_RUMAH'] = &$this->ALAMAT_RUMAH;

		// TEMPATLAHIR
		$this->TEMPATLAHIR = new DbField('murid', 'murid', 'x_TEMPATLAHIR', 'TEMPATLAHIR', '`TEMPATLAHIR`', '`TEMPATLAHIR`', 200, 25, -1, FALSE, '`TEMPATLAHIR`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->TEMPATLAHIR->Sortable = TRUE; // Allow sort
		$this->fields['TEMPATLAHIR'] = &$this->TEMPATLAHIR;

		// TGL_LAHIR
		$this->TGL_LAHIR = new DbField('murid', 'murid', 'x_TGL_LAHIR', 'TGL_LAHIR', '`TGL_LAHIR`', CastDateFieldForLike("`TGL_LAHIR`", 0, "DB"), 133, 10, 0, FALSE, '`TGL_LAHIR`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->TGL_LAHIR->Sortable = TRUE; // Allow sort
		$this->TGL_LAHIR->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['TGL_LAHIR'] = &$this->TGL_LAHIR;

		// NOHP
		$this->NOHP = new DbField('murid', 'murid', 'x_NOHP', 'NOHP', '`NOHP`', '`NOHP`', 200, 14, -1, FALSE, '`NOHP`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->NOHP->Sortable = TRUE; // Allow sort
		$this->fields['NOHP'] = &$this->NOHP;

		// NOWA
		$this->NOWA = new DbField('murid', 'murid', 'x_NOWA', 'NOWA', '`NOWA`', '`NOWA`', 200, 14, -1, FALSE, '`NOWA`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->NOWA->Sortable = TRUE; // Allow sort
		$this->fields['NOWA'] = &$this->NOWA;

		// IDTELEGRAM
		$this->IDTELEGRAM = new DbField('murid', 'murid', 'x_IDTELEGRAM', 'IDTELEGRAM', '`IDTELEGRAM`', '`IDTELEGRAM`', 200, 20, -1, FALSE, '`IDTELEGRAM`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->IDTELEGRAM->Sortable = TRUE; // Allow sort
		$this->fields['IDTELEGRAM'] = &$this->IDTELEGRAM;

		// IDLINE
		$this->IDLINE = new DbField('murid', 'murid', 'x_IDLINE', 'IDLINE', '`IDLINE`', '`IDLINE`', 200, 20, -1, FALSE, '`IDLINE`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->IDLINE->Sortable = TRUE; // Allow sort
		$this->fields['IDLINE'] = &$this->IDLINE;

		// IDFACEBOOK
		$this->IDFACEBOOK = new DbField('murid', 'murid', 'x_IDFACEBOOK', 'IDFACEBOOK', '`IDFACEBOOK`', '`IDFACEBOOK`', 200, 20, -1, FALSE, '`IDFACEBOOK`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->IDFACEBOOK->Sortable = TRUE; // Allow sort
		$this->fields['IDFACEBOOK'] = &$this->IDFACEBOOK;

		// IDINSTAGRAM
		$this->IDINSTAGRAM = new DbField('murid', 'murid', 'x_IDINSTAGRAM', 'IDINSTAGRAM', '`IDINSTAGRAM`', '`IDINSTAGRAM`', 200, 20, -1, FALSE, '`IDINSTAGRAM`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->IDINSTAGRAM->Sortable = TRUE; // Allow sort
		$this->fields['IDINSTAGRAM'] = &$this->IDINSTAGRAM;

		// IDTWITTER
		$this->IDTWITTER = new DbField('murid', 'murid', 'x_IDTWITTER', 'IDTWITTER', '`IDTWITTER`', '`IDTWITTER`', 200, 20, -1, FALSE, '`IDTWITTER`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->IDTWITTER->Sortable = TRUE; // Allow sort
		$this->fields['IDTWITTER'] = &$this->IDTWITTER;

		// IDYOUTUBE
		$this->IDYOUTUBE = new DbField('murid', 'murid', 'x_IDYOUTUBE', 'IDYOUTUBE', '`IDYOUTUBE`', '`IDYOUTUBE`', 200, 20, -1, FALSE, '`IDYOUTUBE`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->IDYOUTUBE->Sortable = TRUE; // Allow sort
		$this->fields['IDYOUTUBE'] = &$this->IDYOUTUBE;

		// EMAIL
		$this->_EMAIL = new DbField('murid', 'murid', 'x__EMAIL', 'EMAIL', '`EMAIL`', '`EMAIL`', 200, 50, -1, FALSE, '`EMAIL`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->_EMAIL->Sortable = TRUE; // Allow sort
		$this->fields['EMAIL'] = &$this->_EMAIL;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`murid`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter)
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = Config("USER_ID_ALLOW");
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('NO_INDUK', $rs))
				AddFilter($where, QuotedName('NO_INDUK', $this->Dbid) . '=' . QuotedValue($rs['NO_INDUK'], $this->NO_INDUK->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->NO_INDUK->DbValue = $row['NO_INDUK'];
		$this->NAMA_MURID->DbValue = $row['NAMA_MURID'];
		$this->JEN_KEL->DbValue = $row['JEN_KEL'];
		$this->AGAMA_MURID->DbValue = $row['AGAMA_MURID'];
		$this->ALAMAT_RUMAH->DbValue = $row['ALAMAT_RUMAH'];
		$this->TEMPATLAHIR->DbValue = $row['TEMPATLAHIR'];
		$this->TGL_LAHIR->DbValue = $row['TGL_LAHIR'];
		$this->NOHP->DbValue = $row['NOHP'];
		$this->NOWA->DbValue = $row['NOWA'];
		$this->IDTELEGRAM->DbValue = $row['IDTELEGRAM'];
		$this->IDLINE->DbValue = $row['IDLINE'];
		$this->IDFACEBOOK->DbValue = $row['IDFACEBOOK'];
		$this->IDINSTAGRAM->DbValue = $row['IDINSTAGRAM'];
		$this->IDTWITTER->DbValue = $row['IDTWITTER'];
		$this->IDYOUTUBE->DbValue = $row['IDYOUTUBE'];
		$this->_EMAIL->DbValue = $row['EMAIL'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`NO_INDUK` = '@NO_INDUK@'";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('NO_INDUK', $row) ? $row['NO_INDUK'] : NULL;
		else
			$val = $this->NO_INDUK->OldValue !== NULL ? $this->NO_INDUK->OldValue : $this->NO_INDUK->CurrentValue;
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@NO_INDUK@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "muridlist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "muridview.php")
			return $Language->phrase("View");
		elseif ($pageName == "muridedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "muridadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "muridlist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("muridview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("muridview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "muridadd.php?" . $this->getUrlParm($parm);
		else
			$url = "muridadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("muridedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("muridadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("muriddelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "NO_INDUK:" . JsonEncode($this->NO_INDUK->CurrentValue, "string");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->NO_INDUK->CurrentValue != NULL) {
			$url .= "NO_INDUK=" . urlencode($this->NO_INDUK->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("NO_INDUK") !== NULL)
				$arKeys[] = Param("NO_INDUK");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->NO_INDUK->CurrentValue = $key;
			else
				$this->NO_INDUK->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->NO_INDUK->setDbValue($rs->fields('NO_INDUK'));
		$this->NAMA_MURID->setDbValue($rs->fields('NAMA_MURID'));
		$this->JEN_KEL->setDbValue($rs->fields('JEN_KEL'));
		$this->AGAMA_MURID->setDbValue($rs->fields('AGAMA_MURID'));
		$this->ALAMAT_RUMAH->setDbValue($rs->fields('ALAMAT_RUMAH'));
		$this->TEMPATLAHIR->setDbValue($rs->fields('TEMPATLAHIR'));
		$this->TGL_LAHIR->setDbValue($rs->fields('TGL_LAHIR'));
		$this->NOHP->setDbValue($rs->fields('NOHP'));
		$this->NOWA->setDbValue($rs->fields('NOWA'));
		$this->IDTELEGRAM->setDbValue($rs->fields('IDTELEGRAM'));
		$this->IDLINE->setDbValue($rs->fields('IDLINE'));
		$this->IDFACEBOOK->setDbValue($rs->fields('IDFACEBOOK'));
		$this->IDINSTAGRAM->setDbValue($rs->fields('IDINSTAGRAM'));
		$this->IDTWITTER->setDbValue($rs->fields('IDTWITTER'));
		$this->IDYOUTUBE->setDbValue($rs->fields('IDYOUTUBE'));
		$this->_EMAIL->setDbValue($rs->fields('EMAIL'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// NO_INDUK
		// NAMA_MURID
		// JEN_KEL
		// AGAMA_MURID
		// ALAMAT_RUMAH
		// TEMPATLAHIR
		// TGL_LAHIR
		// NOHP
		// NOWA
		// IDTELEGRAM
		// IDLINE
		// IDFACEBOOK
		// IDINSTAGRAM
		// IDTWITTER
		// IDYOUTUBE
		// EMAIL
		// NO_INDUK

		$this->NO_INDUK->ViewValue = $this->NO_INDUK->CurrentValue;
		$this->NO_INDUK->ViewCustomAttributes = "";

		// NAMA_MURID
		$this->NAMA_MURID->ViewValue = $this->NAMA_MURID->CurrentValue;
		$this->NAMA_MURID->ViewCustomAttributes = "";

		// JEN_KEL
		$this->JEN_KEL->ViewValue = $this->JEN_KEL->CurrentValue;
		$this->JEN_KEL->ViewCustomAttributes = "";

		// AGAMA_MURID
		$this->AGAMA_MURID->ViewValue = $this->AGAMA_MURID->CurrentValue;
		$this->AGAMA_MURID->ViewCustomAttributes = "";

		// ALAMAT_RUMAH
		$this->ALAMAT_RUMAH->ViewValue = $this->ALAMAT_RUMAH->CurrentValue;
		$this->ALAMAT_RUMAH->ViewCustomAttributes = "";

		// TEMPATLAHIR
		$this->TEMPATLAHIR->ViewValue = $this->TEMPATLAHIR->CurrentValue;
		$this->TEMPATLAHIR->ViewCustomAttributes = "";

		// TGL_LAHIR
		$this->TGL_LAHIR->ViewValue = $this->TGL_LAHIR->CurrentValue;
		$this->TGL_LAHIR->ViewValue = FormatDateTime($this->TGL_LAHIR->ViewValue, 0);
		$this->TGL_LAHIR->ViewCustomAttributes = "";

		// NOHP
		$this->NOHP->ViewValue = $this->NOHP->CurrentValue;
		$this->NOHP->ViewCustomAttributes = "";

		// NOWA
		$this->NOWA->ViewValue = $this->NOWA->CurrentValue;
		$this->NOWA->ViewCustomAttributes = "";

		// IDTELEGRAM
		$this->IDTELEGRAM->ViewValue = $this->IDTELEGRAM->CurrentValue;
		$this->IDTELEGRAM->ViewCustomAttributes = "";

		// IDLINE
		$this->IDLINE->ViewValue = $this->IDLINE->CurrentValue;
		$this->IDLINE->ViewCustomAttributes = "";

		// IDFACEBOOK
		$this->IDFACEBOOK->ViewValue = $this->IDFACEBOOK->CurrentValue;
		$this->IDFACEBOOK->ViewCustomAttributes = "";

		// IDINSTAGRAM
		$this->IDINSTAGRAM->ViewValue = $this->IDINSTAGRAM->CurrentValue;
		$this->IDINSTAGRAM->ViewCustomAttributes = "";

		// IDTWITTER
		$this->IDTWITTER->ViewValue = $this->IDTWITTER->CurrentValue;
		$this->IDTWITTER->ViewCustomAttributes = "";

		// IDYOUTUBE
		$this->IDYOUTUBE->ViewValue = $this->IDYOUTUBE->CurrentValue;
		$this->IDYOUTUBE->ViewCustomAttributes = "";

		// EMAIL
		$this->_EMAIL->ViewValue = $this->_EMAIL->CurrentValue;
		$this->_EMAIL->ViewCustomAttributes = "";

		// NO_INDUK
		$this->NO_INDUK->LinkCustomAttributes = "";
		$this->NO_INDUK->HrefValue = "";
		$this->NO_INDUK->TooltipValue = "";

		// NAMA_MURID
		$this->NAMA_MURID->LinkCustomAttributes = "";
		$this->NAMA_MURID->HrefValue = "";
		$this->NAMA_MURID->TooltipValue = "";

		// JEN_KEL
		$this->JEN_KEL->LinkCustomAttributes = "";
		$this->JEN_KEL->HrefValue = "";
		$this->JEN_KEL->TooltipValue = "";

		// AGAMA_MURID
		$this->AGAMA_MURID->LinkCustomAttributes = "";
		$this->AGAMA_MURID->HrefValue = "";
		$this->AGAMA_MURID->TooltipValue = "";

		// ALAMAT_RUMAH
		$this->ALAMAT_RUMAH->LinkCustomAttributes = "";
		$this->ALAMAT_RUMAH->HrefValue = "";
		$this->ALAMAT_RUMAH->TooltipValue = "";

		// TEMPATLAHIR
		$this->TEMPATLAHIR->LinkCustomAttributes = "";
		$this->TEMPATLAHIR->HrefValue = "";
		$this->TEMPATLAHIR->TooltipValue = "";

		// TGL_LAHIR
		$this->TGL_LAHIR->LinkCustomAttributes = "";
		$this->TGL_LAHIR->HrefValue = "";
		$this->TGL_LAHIR->TooltipValue = "";

		// NOHP
		$this->NOHP->LinkCustomAttributes = "";
		$this->NOHP->HrefValue = "";
		$this->NOHP->TooltipValue = "";

		// NOWA
		$this->NOWA->LinkCustomAttributes = "";
		$this->NOWA->HrefValue = "";
		$this->NOWA->TooltipValue = "";

		// IDTELEGRAM
		$this->IDTELEGRAM->LinkCustomAttributes = "";
		$this->IDTELEGRAM->HrefValue = "";
		$this->IDTELEGRAM->TooltipValue = "";

		// IDLINE
		$this->IDLINE->LinkCustomAttributes = "";
		$this->IDLINE->HrefValue = "";
		$this->IDLINE->TooltipValue = "";

		// IDFACEBOOK
		$this->IDFACEBOOK->LinkCustomAttributes = "";
		$this->IDFACEBOOK->HrefValue = "";
		$this->IDFACEBOOK->TooltipValue = "";

		// IDINSTAGRAM
		$this->IDINSTAGRAM->LinkCustomAttributes = "";
		$this->IDINSTAGRAM->HrefValue = "";
		$this->IDINSTAGRAM->TooltipValue = "";

		// IDTWITTER
		$this->IDTWITTER->LinkCustomAttributes = "";
		$this->IDTWITTER->HrefValue = "";
		$this->IDTWITTER->TooltipValue = "";

		// IDYOUTUBE
		$this->IDYOUTUBE->LinkCustomAttributes = "";
		$this->IDYOUTUBE->HrefValue = "";
		$this->IDYOUTUBE->TooltipValue = "";

		// EMAIL
		$this->_EMAIL->LinkCustomAttributes = "";
		$this->_EMAIL->HrefValue = "";
		$this->_EMAIL->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// NO_INDUK
		$this->NO_INDUK->EditAttrs["class"] = "form-control";
		$this->NO_INDUK->EditCustomAttributes = "";
		if (!$this->NO_INDUK->Raw)
			$this->NO_INDUK->CurrentValue = HtmlDecode($this->NO_INDUK->CurrentValue);
		$this->NO_INDUK->EditValue = $this->NO_INDUK->CurrentValue;
		$this->NO_INDUK->PlaceHolder = RemoveHtml($this->NO_INDUK->caption());

		// NAMA_MURID
		$this->NAMA_MURID->EditAttrs["class"] = "form-control";
		$this->NAMA_MURID->EditCustomAttributes = "";
		if (!$this->NAMA_MURID->Raw)
			$this->NAMA_MURID->CurrentValue = HtmlDecode($this->NAMA_MURID->CurrentValue);
		$this->NAMA_MURID->EditValue = $this->NAMA_MURID->CurrentValue;
		$this->NAMA_MURID->PlaceHolder = RemoveHtml($this->NAMA_MURID->caption());

		// JEN_KEL
		$this->JEN_KEL->EditAttrs["class"] = "form-control";
		$this->JEN_KEL->EditCustomAttributes = "";
		if (!$this->JEN_KEL->Raw)
			$this->JEN_KEL->CurrentValue = HtmlDecode($this->JEN_KEL->CurrentValue);
		$this->JEN_KEL->EditValue = $this->JEN_KEL->CurrentValue;
		$this->JEN_KEL->PlaceHolder = RemoveHtml($this->JEN_KEL->caption());

		// AGAMA_MURID
		$this->AGAMA_MURID->EditAttrs["class"] = "form-control";
		$this->AGAMA_MURID->EditCustomAttributes = "";
		if (!$this->AGAMA_MURID->Raw)
			$this->AGAMA_MURID->CurrentValue = HtmlDecode($this->AGAMA_MURID->CurrentValue);
		$this->AGAMA_MURID->EditValue = $this->AGAMA_MURID->CurrentValue;
		$this->AGAMA_MURID->PlaceHolder = RemoveHtml($this->AGAMA_MURID->caption());

		// ALAMAT_RUMAH
		$this->ALAMAT_RUMAH->EditAttrs["class"] = "form-control";
		$this->ALAMAT_RUMAH->EditCustomAttributes = "";
		if (!$this->ALAMAT_RUMAH->Raw)
			$this->ALAMAT_RUMAH->CurrentValue = HtmlDecode($this->ALAMAT_RUMAH->CurrentValue);
		$this->ALAMAT_RUMAH->EditValue = $this->ALAMAT_RUMAH->CurrentValue;
		$this->ALAMAT_RUMAH->PlaceHolder = RemoveHtml($this->ALAMAT_RUMAH->caption());

		// TEMPATLAHIR
		$this->TEMPATLAHIR->EditAttrs["class"] = "form-control";
		$this->TEMPATLAHIR->EditCustomAttributes = "";
		if (!$this->TEMPATLAHIR->Raw)
			$this->TEMPATLAHIR->CurrentValue = HtmlDecode($this->TEMPATLAHIR->CurrentValue);
		$this->TEMPATLAHIR->EditValue = $this->TEMPATLAHIR->CurrentValue;
		$this->TEMPATLAHIR->PlaceHolder = RemoveHtml($this->TEMPATLAHIR->caption());

		// TGL_LAHIR
		$this->TGL_LAHIR->EditAttrs["class"] = "form-control";
		$this->TGL_LAHIR->EditCustomAttributes = "";
		$this->TGL_LAHIR->EditValue = FormatDateTime($this->TGL_LAHIR->CurrentValue, 8);
		$this->TGL_LAHIR->PlaceHolder = RemoveHtml($this->TGL_LAHIR->caption());

		// NOHP
		$this->NOHP->EditAttrs["class"] = "form-control";
		$this->NOHP->EditCustomAttributes = "";
		if (!$this->NOHP->Raw)
			$this->NOHP->CurrentValue = HtmlDecode($this->NOHP->CurrentValue);
		$this->NOHP->EditValue = $this->NOHP->CurrentValue;
		$this->NOHP->PlaceHolder = RemoveHtml($this->NOHP->caption());

		// NOWA
		$this->NOWA->EditAttrs["class"] = "form-control";
		$this->NOWA->EditCustomAttributes = "";
		if (!$this->NOWA->Raw)
			$this->NOWA->CurrentValue = HtmlDecode($this->NOWA->CurrentValue);
		$this->NOWA->EditValue = $this->NOWA->CurrentValue;
		$this->NOWA->PlaceHolder = RemoveHtml($this->NOWA->caption());

		// IDTELEGRAM
		$this->IDTELEGRAM->EditAttrs["class"] = "form-control";
		$this->IDTELEGRAM->EditCustomAttributes = "";
		if (!$this->IDTELEGRAM->Raw)
			$this->IDTELEGRAM->CurrentValue = HtmlDecode($this->IDTELEGRAM->CurrentValue);
		$this->IDTELEGRAM->EditValue = $this->IDTELEGRAM->CurrentValue;
		$this->IDTELEGRAM->PlaceHolder = RemoveHtml($this->IDTELEGRAM->caption());

		// IDLINE
		$this->IDLINE->EditAttrs["class"] = "form-control";
		$this->IDLINE->EditCustomAttributes = "";
		if (!$this->IDLINE->Raw)
			$this->IDLINE->CurrentValue = HtmlDecode($this->IDLINE->CurrentValue);
		$this->IDLINE->EditValue = $this->IDLINE->CurrentValue;
		$this->IDLINE->PlaceHolder = RemoveHtml($this->IDLINE->caption());

		// IDFACEBOOK
		$this->IDFACEBOOK->EditAttrs["class"] = "form-control";
		$this->IDFACEBOOK->EditCustomAttributes = "";
		if (!$this->IDFACEBOOK->Raw)
			$this->IDFACEBOOK->CurrentValue = HtmlDecode($this->IDFACEBOOK->CurrentValue);
		$this->IDFACEBOOK->EditValue = $this->IDFACEBOOK->CurrentValue;
		$this->IDFACEBOOK->PlaceHolder = RemoveHtml($this->IDFACEBOOK->caption());

		// IDINSTAGRAM
		$this->IDINSTAGRAM->EditAttrs["class"] = "form-control";
		$this->IDINSTAGRAM->EditCustomAttributes = "";
		if (!$this->IDINSTAGRAM->Raw)
			$this->IDINSTAGRAM->CurrentValue = HtmlDecode($this->IDINSTAGRAM->CurrentValue);
		$this->IDINSTAGRAM->EditValue = $this->IDINSTAGRAM->CurrentValue;
		$this->IDINSTAGRAM->PlaceHolder = RemoveHtml($this->IDINSTAGRAM->caption());

		// IDTWITTER
		$this->IDTWITTER->EditAttrs["class"] = "form-control";
		$this->IDTWITTER->EditCustomAttributes = "";
		if (!$this->IDTWITTER->Raw)
			$this->IDTWITTER->CurrentValue = HtmlDecode($this->IDTWITTER->CurrentValue);
		$this->IDTWITTER->EditValue = $this->IDTWITTER->CurrentValue;
		$this->IDTWITTER->PlaceHolder = RemoveHtml($this->IDTWITTER->caption());

		// IDYOUTUBE
		$this->IDYOUTUBE->EditAttrs["class"] = "form-control";
		$this->IDYOUTUBE->EditCustomAttributes = "";
		if (!$this->IDYOUTUBE->Raw)
			$this->IDYOUTUBE->CurrentValue = HtmlDecode($this->IDYOUTUBE->CurrentValue);
		$this->IDYOUTUBE->EditValue = $this->IDYOUTUBE->CurrentValue;
		$this->IDYOUTUBE->PlaceHolder = RemoveHtml($this->IDYOUTUBE->caption());

		// EMAIL
		$this->_EMAIL->EditAttrs["class"] = "form-control";
		$this->_EMAIL->EditCustomAttributes = "";
		if (!$this->_EMAIL->Raw)
			$this->_EMAIL->CurrentValue = HtmlDecode($this->_EMAIL->CurrentValue);
		$this->_EMAIL->EditValue = $this->_EMAIL->CurrentValue;
		$this->_EMAIL->PlaceHolder = RemoveHtml($this->_EMAIL->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->NO_INDUK);
					$doc->exportCaption($this->NAMA_MURID);
					$doc->exportCaption($this->JEN_KEL);
					$doc->exportCaption($this->AGAMA_MURID);
					$doc->exportCaption($this->ALAMAT_RUMAH);
					$doc->exportCaption($this->TEMPATLAHIR);
					$doc->exportCaption($this->TGL_LAHIR);
					$doc->exportCaption($this->NOHP);
					$doc->exportCaption($this->NOWA);
					$doc->exportCaption($this->IDTELEGRAM);
					$doc->exportCaption($this->IDLINE);
					$doc->exportCaption($this->IDFACEBOOK);
					$doc->exportCaption($this->IDINSTAGRAM);
					$doc->exportCaption($this->IDTWITTER);
					$doc->exportCaption($this->IDYOUTUBE);
					$doc->exportCaption($this->_EMAIL);
				} else {
					$doc->exportCaption($this->NO_INDUK);
					$doc->exportCaption($this->NAMA_MURID);
					$doc->exportCaption($this->JEN_KEL);
					$doc->exportCaption($this->AGAMA_MURID);
					$doc->exportCaption($this->ALAMAT_RUMAH);
					$doc->exportCaption($this->TEMPATLAHIR);
					$doc->exportCaption($this->TGL_LAHIR);
					$doc->exportCaption($this->NOHP);
					$doc->exportCaption($this->NOWA);
					$doc->exportCaption($this->IDTELEGRAM);
					$doc->exportCaption($this->IDLINE);
					$doc->exportCaption($this->IDFACEBOOK);
					$doc->exportCaption($this->IDINSTAGRAM);
					$doc->exportCaption($this->IDTWITTER);
					$doc->exportCaption($this->IDYOUTUBE);
					$doc->exportCaption($this->_EMAIL);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->NO_INDUK);
						$doc->exportField($this->NAMA_MURID);
						$doc->exportField($this->JEN_KEL);
						$doc->exportField($this->AGAMA_MURID);
						$doc->exportField($this->ALAMAT_RUMAH);
						$doc->exportField($this->TEMPATLAHIR);
						$doc->exportField($this->TGL_LAHIR);
						$doc->exportField($this->NOHP);
						$doc->exportField($this->NOWA);
						$doc->exportField($this->IDTELEGRAM);
						$doc->exportField($this->IDLINE);
						$doc->exportField($this->IDFACEBOOK);
						$doc->exportField($this->IDINSTAGRAM);
						$doc->exportField($this->IDTWITTER);
						$doc->exportField($this->IDYOUTUBE);
						$doc->exportField($this->_EMAIL);
					} else {
						$doc->exportField($this->NO_INDUK);
						$doc->exportField($this->NAMA_MURID);
						$doc->exportField($this->JEN_KEL);
						$doc->exportField($this->AGAMA_MURID);
						$doc->exportField($this->ALAMAT_RUMAH);
						$doc->exportField($this->TEMPATLAHIR);
						$doc->exportField($this->TGL_LAHIR);
						$doc->exportField($this->NOHP);
						$doc->exportField($this->NOWA);
						$doc->exportField($this->IDTELEGRAM);
						$doc->exportField($this->IDLINE);
						$doc->exportField($this->IDFACEBOOK);
						$doc->exportField($this->IDINSTAGRAM);
						$doc->exportField($this->IDTWITTER);
						$doc->exportField($this->IDYOUTUBE);
						$doc->exportField($this->_EMAIL);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>