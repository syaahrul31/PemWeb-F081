<?php namespace PHPMaker2020\project1; ?>
<?php

/**
 * Table class for ruang_kelas
 */
class ruang_kelas extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Export
	public $ExportDoc;

	// Fields
	public $IDRUANG;
	public $NAMA_RUANG;
	public $TIPE_RUANG;
	public $UKURAN_RUANG;
	public $KAPASITAS_RUANG;
	public $JUMLAH_MEJA;
	public $JUMLAH_KURSI;
	public $KETERANGAN_RUANG;
	public $KELENGKAPAN_ALAT;
	public $RENOVASI_TERAKHIR;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'ruang_kelas';
		$this->TableName = 'ruang_kelas';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`ruang_kelas`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = ""; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = ""; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = 0; // User ID Allow
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// IDRUANG
		$this->IDRUANG = new DbField('ruang_kelas', 'ruang_kelas', 'x_IDRUANG', 'IDRUANG', '`IDRUANG`', '`IDRUANG`', 200, 10, -1, FALSE, '`IDRUANG`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->IDRUANG->IsPrimaryKey = TRUE; // Primary key field
		$this->IDRUANG->Nullable = FALSE; // NOT NULL field
		$this->IDRUANG->Required = TRUE; // Required field
		$this->IDRUANG->Sortable = TRUE; // Allow sort
		$this->fields['IDRUANG'] = &$this->IDRUANG;

		// NAMA_RUANG
		$this->NAMA_RUANG = new DbField('ruang_kelas', 'ruang_kelas', 'x_NAMA_RUANG', 'NAMA_RUANG', '`NAMA_RUANG`', '`NAMA_RUANG`', 200, 15, -1, FALSE, '`NAMA_RUANG`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->NAMA_RUANG->Nullable = FALSE; // NOT NULL field
		$this->NAMA_RUANG->Required = TRUE; // Required field
		$this->NAMA_RUANG->Sortable = TRUE; // Allow sort
		$this->fields['NAMA_RUANG'] = &$this->NAMA_RUANG;

		// TIPE_RUANG
		$this->TIPE_RUANG = new DbField('ruang_kelas', 'ruang_kelas', 'x_TIPE_RUANG', 'TIPE_RUANG', '`TIPE_RUANG`', '`TIPE_RUANG`', 200, 10, -1, FALSE, '`TIPE_RUANG`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->TIPE_RUANG->Sortable = TRUE; // Allow sort
		$this->fields['TIPE_RUANG'] = &$this->TIPE_RUANG;

		// UKURAN_RUANG
		$this->UKURAN_RUANG = new DbField('ruang_kelas', 'ruang_kelas', 'x_UKURAN_RUANG', 'UKURAN_RUANG', '`UKURAN_RUANG`', '`UKURAN_RUANG`', 200, 10, -1, FALSE, '`UKURAN_RUANG`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->UKURAN_RUANG->Sortable = TRUE; // Allow sort
		$this->fields['UKURAN_RUANG'] = &$this->UKURAN_RUANG;

		// KAPASITAS_RUANG
		$this->KAPASITAS_RUANG = new DbField('ruang_kelas', 'ruang_kelas', 'x_KAPASITAS_RUANG', 'KAPASITAS_RUANG', '`KAPASITAS_RUANG`', '`KAPASITAS_RUANG`', 131, 4, -1, FALSE, '`KAPASITAS_RUANG`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->KAPASITAS_RUANG->Sortable = TRUE; // Allow sort
		$this->KAPASITAS_RUANG->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['KAPASITAS_RUANG'] = &$this->KAPASITAS_RUANG;

		// JUMLAH_MEJA
		$this->JUMLAH_MEJA = new DbField('ruang_kelas', 'ruang_kelas', 'x_JUMLAH_MEJA', 'JUMLAH_MEJA', '`JUMLAH_MEJA`', '`JUMLAH_MEJA`', 131, 4, -1, FALSE, '`JUMLAH_MEJA`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->JUMLAH_MEJA->Sortable = TRUE; // Allow sort
		$this->JUMLAH_MEJA->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['JUMLAH_MEJA'] = &$this->JUMLAH_MEJA;

		// JUMLAH_KURSI
		$this->JUMLAH_KURSI = new DbField('ruang_kelas', 'ruang_kelas', 'x_JUMLAH_KURSI', 'JUMLAH_KURSI', '`JUMLAH_KURSI`', '`JUMLAH_KURSI`', 131, 4, -1, FALSE, '`JUMLAH_KURSI`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->JUMLAH_KURSI->Sortable = TRUE; // Allow sort
		$this->JUMLAH_KURSI->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['JUMLAH_KURSI'] = &$this->JUMLAH_KURSI;

		// KETERANGAN_RUANG
		$this->KETERANGAN_RUANG = new DbField('ruang_kelas', 'ruang_kelas', 'x_KETERANGAN_RUANG', 'KETERANGAN_RUANG', '`KETERANGAN_RUANG`', '`KETERANGAN_RUANG`', 200, 200, -1, FALSE, '`KETERANGAN_RUANG`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->KETERANGAN_RUANG->Sortable = TRUE; // Allow sort
		$this->fields['KETERANGAN_RUANG'] = &$this->KETERANGAN_RUANG;

		// KELENGKAPAN_ALAT
		$this->KELENGKAPAN_ALAT = new DbField('ruang_kelas', 'ruang_kelas', 'x_KELENGKAPAN_ALAT', 'KELENGKAPAN_ALAT', '`KELENGKAPAN_ALAT`', '`KELENGKAPAN_ALAT`', 200, 200, -1, FALSE, '`KELENGKAPAN_ALAT`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->KELENGKAPAN_ALAT->Sortable = TRUE; // Allow sort
		$this->fields['KELENGKAPAN_ALAT'] = &$this->KELENGKAPAN_ALAT;

		// RENOVASI_TERAKHIR
		$this->RENOVASI_TERAKHIR = new DbField('ruang_kelas', 'ruang_kelas', 'x_RENOVASI_TERAKHIR', 'RENOVASI_TERAKHIR', '`RENOVASI_TERAKHIR`', CastDateFieldForLike("`RENOVASI_TERAKHIR`", 0, "DB"), 133, 10, 0, FALSE, '`RENOVASI_TERAKHIR`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->RENOVASI_TERAKHIR->Sortable = TRUE; // Allow sort
		$this->RENOVASI_TERAKHIR->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['RENOVASI_TERAKHIR'] = &$this->RENOVASI_TERAKHIR;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`ruang_kelas`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter)
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = Config("USER_ID_ALLOW");
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('IDRUANG', $rs))
				AddFilter($where, QuotedName('IDRUANG', $this->Dbid) . '=' . QuotedValue($rs['IDRUANG'], $this->IDRUANG->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->IDRUANG->DbValue = $row['IDRUANG'];
		$this->NAMA_RUANG->DbValue = $row['NAMA_RUANG'];
		$this->TIPE_RUANG->DbValue = $row['TIPE_RUANG'];
		$this->UKURAN_RUANG->DbValue = $row['UKURAN_RUANG'];
		$this->KAPASITAS_RUANG->DbValue = $row['KAPASITAS_RUANG'];
		$this->JUMLAH_MEJA->DbValue = $row['JUMLAH_MEJA'];
		$this->JUMLAH_KURSI->DbValue = $row['JUMLAH_KURSI'];
		$this->KETERANGAN_RUANG->DbValue = $row['KETERANGAN_RUANG'];
		$this->KELENGKAPAN_ALAT->DbValue = $row['KELENGKAPAN_ALAT'];
		$this->RENOVASI_TERAKHIR->DbValue = $row['RENOVASI_TERAKHIR'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`IDRUANG` = '@IDRUANG@'";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('IDRUANG', $row) ? $row['IDRUANG'] : NULL;
		else
			$val = $this->IDRUANG->OldValue !== NULL ? $this->IDRUANG->OldValue : $this->IDRUANG->CurrentValue;
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@IDRUANG@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "ruang_kelaslist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "ruang_kelasview.php")
			return $Language->phrase("View");
		elseif ($pageName == "ruang_kelasedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "ruang_kelasadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "ruang_kelaslist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("ruang_kelasview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("ruang_kelasview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "ruang_kelasadd.php?" . $this->getUrlParm($parm);
		else
			$url = "ruang_kelasadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("ruang_kelasedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("ruang_kelasadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("ruang_kelasdelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "IDRUANG:" . JsonEncode($this->IDRUANG->CurrentValue, "string");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->IDRUANG->CurrentValue != NULL) {
			$url .= "IDRUANG=" . urlencode($this->IDRUANG->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("IDRUANG") !== NULL)
				$arKeys[] = Param("IDRUANG");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->IDRUANG->CurrentValue = $key;
			else
				$this->IDRUANG->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->IDRUANG->setDbValue($rs->fields('IDRUANG'));
		$this->NAMA_RUANG->setDbValue($rs->fields('NAMA_RUANG'));
		$this->TIPE_RUANG->setDbValue($rs->fields('TIPE_RUANG'));
		$this->UKURAN_RUANG->setDbValue($rs->fields('UKURAN_RUANG'));
		$this->KAPASITAS_RUANG->setDbValue($rs->fields('KAPASITAS_RUANG'));
		$this->JUMLAH_MEJA->setDbValue($rs->fields('JUMLAH_MEJA'));
		$this->JUMLAH_KURSI->setDbValue($rs->fields('JUMLAH_KURSI'));
		$this->KETERANGAN_RUANG->setDbValue($rs->fields('KETERANGAN_RUANG'));
		$this->KELENGKAPAN_ALAT->setDbValue($rs->fields('KELENGKAPAN_ALAT'));
		$this->RENOVASI_TERAKHIR->setDbValue($rs->fields('RENOVASI_TERAKHIR'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// IDRUANG
		// NAMA_RUANG
		// TIPE_RUANG
		// UKURAN_RUANG
		// KAPASITAS_RUANG
		// JUMLAH_MEJA
		// JUMLAH_KURSI
		// KETERANGAN_RUANG
		// KELENGKAPAN_ALAT
		// RENOVASI_TERAKHIR
		// IDRUANG

		$this->IDRUANG->ViewValue = $this->IDRUANG->CurrentValue;
		$this->IDRUANG->ViewCustomAttributes = "";

		// NAMA_RUANG
		$this->NAMA_RUANG->ViewValue = $this->NAMA_RUANG->CurrentValue;
		$this->NAMA_RUANG->ViewCustomAttributes = "";

		// TIPE_RUANG
		$this->TIPE_RUANG->ViewValue = $this->TIPE_RUANG->CurrentValue;
		$this->TIPE_RUANG->ViewCustomAttributes = "";

		// UKURAN_RUANG
		$this->UKURAN_RUANG->ViewValue = $this->UKURAN_RUANG->CurrentValue;
		$this->UKURAN_RUANG->ViewCustomAttributes = "";

		// KAPASITAS_RUANG
		$this->KAPASITAS_RUANG->ViewValue = $this->KAPASITAS_RUANG->CurrentValue;
		$this->KAPASITAS_RUANG->ViewValue = FormatNumber($this->KAPASITAS_RUANG->ViewValue, 2, -2, -2, -2);
		$this->KAPASITAS_RUANG->ViewCustomAttributes = "";

		// JUMLAH_MEJA
		$this->JUMLAH_MEJA->ViewValue = $this->JUMLAH_MEJA->CurrentValue;
		$this->JUMLAH_MEJA->ViewValue = FormatNumber($this->JUMLAH_MEJA->ViewValue, 2, -2, -2, -2);
		$this->JUMLAH_MEJA->ViewCustomAttributes = "";

		// JUMLAH_KURSI
		$this->JUMLAH_KURSI->ViewValue = $this->JUMLAH_KURSI->CurrentValue;
		$this->JUMLAH_KURSI->ViewValue = FormatNumber($this->JUMLAH_KURSI->ViewValue, 2, -2, -2, -2);
		$this->JUMLAH_KURSI->ViewCustomAttributes = "";

		// KETERANGAN_RUANG
		$this->KETERANGAN_RUANG->ViewValue = $this->KETERANGAN_RUANG->CurrentValue;
		$this->KETERANGAN_RUANG->ViewCustomAttributes = "";

		// KELENGKAPAN_ALAT
		$this->KELENGKAPAN_ALAT->ViewValue = $this->KELENGKAPAN_ALAT->CurrentValue;
		$this->KELENGKAPAN_ALAT->ViewCustomAttributes = "";

		// RENOVASI_TERAKHIR
		$this->RENOVASI_TERAKHIR->ViewValue = $this->RENOVASI_TERAKHIR->CurrentValue;
		$this->RENOVASI_TERAKHIR->ViewValue = FormatDateTime($this->RENOVASI_TERAKHIR->ViewValue, 0);
		$this->RENOVASI_TERAKHIR->ViewCustomAttributes = "";

		// IDRUANG
		$this->IDRUANG->LinkCustomAttributes = "";
		$this->IDRUANG->HrefValue = "";
		$this->IDRUANG->TooltipValue = "";

		// NAMA_RUANG
		$this->NAMA_RUANG->LinkCustomAttributes = "";
		$this->NAMA_RUANG->HrefValue = "";
		$this->NAMA_RUANG->TooltipValue = "";

		// TIPE_RUANG
		$this->TIPE_RUANG->LinkCustomAttributes = "";
		$this->TIPE_RUANG->HrefValue = "";
		$this->TIPE_RUANG->TooltipValue = "";

		// UKURAN_RUANG
		$this->UKURAN_RUANG->LinkCustomAttributes = "";
		$this->UKURAN_RUANG->HrefValue = "";
		$this->UKURAN_RUANG->TooltipValue = "";

		// KAPASITAS_RUANG
		$this->KAPASITAS_RUANG->LinkCustomAttributes = "";
		$this->KAPASITAS_RUANG->HrefValue = "";
		$this->KAPASITAS_RUANG->TooltipValue = "";

		// JUMLAH_MEJA
		$this->JUMLAH_MEJA->LinkCustomAttributes = "";
		$this->JUMLAH_MEJA->HrefValue = "";
		$this->JUMLAH_MEJA->TooltipValue = "";

		// JUMLAH_KURSI
		$this->JUMLAH_KURSI->LinkCustomAttributes = "";
		$this->JUMLAH_KURSI->HrefValue = "";
		$this->JUMLAH_KURSI->TooltipValue = "";

		// KETERANGAN_RUANG
		$this->KETERANGAN_RUANG->LinkCustomAttributes = "";
		$this->KETERANGAN_RUANG->HrefValue = "";
		$this->KETERANGAN_RUANG->TooltipValue = "";

		// KELENGKAPAN_ALAT
		$this->KELENGKAPAN_ALAT->LinkCustomAttributes = "";
		$this->KELENGKAPAN_ALAT->HrefValue = "";
		$this->KELENGKAPAN_ALAT->TooltipValue = "";

		// RENOVASI_TERAKHIR
		$this->RENOVASI_TERAKHIR->LinkCustomAttributes = "";
		$this->RENOVASI_TERAKHIR->HrefValue = "";
		$this->RENOVASI_TERAKHIR->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// IDRUANG
		$this->IDRUANG->EditAttrs["class"] = "form-control";
		$this->IDRUANG->EditCustomAttributes = "";
		if (!$this->IDRUANG->Raw)
			$this->IDRUANG->CurrentValue = HtmlDecode($this->IDRUANG->CurrentValue);
		$this->IDRUANG->EditValue = $this->IDRUANG->CurrentValue;
		$this->IDRUANG->PlaceHolder = RemoveHtml($this->IDRUANG->caption());

		// NAMA_RUANG
		$this->NAMA_RUANG->EditAttrs["class"] = "form-control";
		$this->NAMA_RUANG->EditCustomAttributes = "";
		if (!$this->NAMA_RUANG->Raw)
			$this->NAMA_RUANG->CurrentValue = HtmlDecode($this->NAMA_RUANG->CurrentValue);
		$this->NAMA_RUANG->EditValue = $this->NAMA_RUANG->CurrentValue;
		$this->NAMA_RUANG->PlaceHolder = RemoveHtml($this->NAMA_RUANG->caption());

		// TIPE_RUANG
		$this->TIPE_RUANG->EditAttrs["class"] = "form-control";
		$this->TIPE_RUANG->EditCustomAttributes = "";
		if (!$this->TIPE_RUANG->Raw)
			$this->TIPE_RUANG->CurrentValue = HtmlDecode($this->TIPE_RUANG->CurrentValue);
		$this->TIPE_RUANG->EditValue = $this->TIPE_RUANG->CurrentValue;
		$this->TIPE_RUANG->PlaceHolder = RemoveHtml($this->TIPE_RUANG->caption());

		// UKURAN_RUANG
		$this->UKURAN_RUANG->EditAttrs["class"] = "form-control";
		$this->UKURAN_RUANG->EditCustomAttributes = "";
		if (!$this->UKURAN_RUANG->Raw)
			$this->UKURAN_RUANG->CurrentValue = HtmlDecode($this->UKURAN_RUANG->CurrentValue);
		$this->UKURAN_RUANG->EditValue = $this->UKURAN_RUANG->CurrentValue;
		$this->UKURAN_RUANG->PlaceHolder = RemoveHtml($this->UKURAN_RUANG->caption());

		// KAPASITAS_RUANG
		$this->KAPASITAS_RUANG->EditAttrs["class"] = "form-control";
		$this->KAPASITAS_RUANG->EditCustomAttributes = "";
		$this->KAPASITAS_RUANG->EditValue = $this->KAPASITAS_RUANG->CurrentValue;
		$this->KAPASITAS_RUANG->PlaceHolder = RemoveHtml($this->KAPASITAS_RUANG->caption());
		if (strval($this->KAPASITAS_RUANG->EditValue) != "" && is_numeric($this->KAPASITAS_RUANG->EditValue))
			$this->KAPASITAS_RUANG->EditValue = FormatNumber($this->KAPASITAS_RUANG->EditValue, -2, -2, -2, -2);
		

		// JUMLAH_MEJA
		$this->JUMLAH_MEJA->EditAttrs["class"] = "form-control";
		$this->JUMLAH_MEJA->EditCustomAttributes = "";
		$this->JUMLAH_MEJA->EditValue = $this->JUMLAH_MEJA->CurrentValue;
		$this->JUMLAH_MEJA->PlaceHolder = RemoveHtml($this->JUMLAH_MEJA->caption());
		if (strval($this->JUMLAH_MEJA->EditValue) != "" && is_numeric($this->JUMLAH_MEJA->EditValue))
			$this->JUMLAH_MEJA->EditValue = FormatNumber($this->JUMLAH_MEJA->EditValue, -2, -2, -2, -2);
		

		// JUMLAH_KURSI
		$this->JUMLAH_KURSI->EditAttrs["class"] = "form-control";
		$this->JUMLAH_KURSI->EditCustomAttributes = "";
		$this->JUMLAH_KURSI->EditValue = $this->JUMLAH_KURSI->CurrentValue;
		$this->JUMLAH_KURSI->PlaceHolder = RemoveHtml($this->JUMLAH_KURSI->caption());
		if (strval($this->JUMLAH_KURSI->EditValue) != "" && is_numeric($this->JUMLAH_KURSI->EditValue))
			$this->JUMLAH_KURSI->EditValue = FormatNumber($this->JUMLAH_KURSI->EditValue, -2, -2, -2, -2);
		

		// KETERANGAN_RUANG
		$this->KETERANGAN_RUANG->EditAttrs["class"] = "form-control";
		$this->KETERANGAN_RUANG->EditCustomAttributes = "";
		if (!$this->KETERANGAN_RUANG->Raw)
			$this->KETERANGAN_RUANG->CurrentValue = HtmlDecode($this->KETERANGAN_RUANG->CurrentValue);
		$this->KETERANGAN_RUANG->EditValue = $this->KETERANGAN_RUANG->CurrentValue;
		$this->KETERANGAN_RUANG->PlaceHolder = RemoveHtml($this->KETERANGAN_RUANG->caption());

		// KELENGKAPAN_ALAT
		$this->KELENGKAPAN_ALAT->EditAttrs["class"] = "form-control";
		$this->KELENGKAPAN_ALAT->EditCustomAttributes = "";
		if (!$this->KELENGKAPAN_ALAT->Raw)
			$this->KELENGKAPAN_ALAT->CurrentValue = HtmlDecode($this->KELENGKAPAN_ALAT->CurrentValue);
		$this->KELENGKAPAN_ALAT->EditValue = $this->KELENGKAPAN_ALAT->CurrentValue;
		$this->KELENGKAPAN_ALAT->PlaceHolder = RemoveHtml($this->KELENGKAPAN_ALAT->caption());

		// RENOVASI_TERAKHIR
		$this->RENOVASI_TERAKHIR->EditAttrs["class"] = "form-control";
		$this->RENOVASI_TERAKHIR->EditCustomAttributes = "";
		$this->RENOVASI_TERAKHIR->EditValue = FormatDateTime($this->RENOVASI_TERAKHIR->CurrentValue, 8);
		$this->RENOVASI_TERAKHIR->PlaceHolder = RemoveHtml($this->RENOVASI_TERAKHIR->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->IDRUANG);
					$doc->exportCaption($this->NAMA_RUANG);
					$doc->exportCaption($this->TIPE_RUANG);
					$doc->exportCaption($this->UKURAN_RUANG);
					$doc->exportCaption($this->KAPASITAS_RUANG);
					$doc->exportCaption($this->JUMLAH_MEJA);
					$doc->exportCaption($this->JUMLAH_KURSI);
					$doc->exportCaption($this->KETERANGAN_RUANG);
					$doc->exportCaption($this->KELENGKAPAN_ALAT);
					$doc->exportCaption($this->RENOVASI_TERAKHIR);
				} else {
					$doc->exportCaption($this->IDRUANG);
					$doc->exportCaption($this->NAMA_RUANG);
					$doc->exportCaption($this->TIPE_RUANG);
					$doc->exportCaption($this->UKURAN_RUANG);
					$doc->exportCaption($this->KAPASITAS_RUANG);
					$doc->exportCaption($this->JUMLAH_MEJA);
					$doc->exportCaption($this->JUMLAH_KURSI);
					$doc->exportCaption($this->KETERANGAN_RUANG);
					$doc->exportCaption($this->KELENGKAPAN_ALAT);
					$doc->exportCaption($this->RENOVASI_TERAKHIR);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->IDRUANG);
						$doc->exportField($this->NAMA_RUANG);
						$doc->exportField($this->TIPE_RUANG);
						$doc->exportField($this->UKURAN_RUANG);
						$doc->exportField($this->KAPASITAS_RUANG);
						$doc->exportField($this->JUMLAH_MEJA);
						$doc->exportField($this->JUMLAH_KURSI);
						$doc->exportField($this->KETERANGAN_RUANG);
						$doc->exportField($this->KELENGKAPAN_ALAT);
						$doc->exportField($this->RENOVASI_TERAKHIR);
					} else {
						$doc->exportField($this->IDRUANG);
						$doc->exportField($this->NAMA_RUANG);
						$doc->exportField($this->TIPE_RUANG);
						$doc->exportField($this->UKURAN_RUANG);
						$doc->exportField($this->KAPASITAS_RUANG);
						$doc->exportField($this->JUMLAH_MEJA);
						$doc->exportField($this->JUMLAH_KURSI);
						$doc->exportField($this->KETERANGAN_RUANG);
						$doc->exportField($this->KELENGKAPAN_ALAT);
						$doc->exportField($this->RENOVASI_TERAKHIR);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>