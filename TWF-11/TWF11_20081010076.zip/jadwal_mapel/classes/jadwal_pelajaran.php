<?php namespace PHPMaker2020\project1; ?>
<?php

/**
 * Table class for jadwal_pelajaran
 */
class jadwal_pelajaran extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Export
	public $ExportDoc;

	// Fields
	public $IDJADWAL;
	public $ID_GURU;
	public $KODE_MAPEL;
	public $IDRUANG;
	public $NO_INDUK;
	public $HARIJADWAL;
	public $SESIJADWAL;
	public $WAKTU_MULAI;
	public $WAKTU_SELESAI;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'jadwal_pelajaran';
		$this->TableName = 'jadwal_pelajaran';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`jadwal_pelajaran`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = ""; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = ""; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = 0; // User ID Allow
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// IDJADWAL
		$this->IDJADWAL = new DbField('jadwal_pelajaran', 'jadwal_pelajaran', 'x_IDJADWAL', 'IDJADWAL', '`IDJADWAL`', '`IDJADWAL`', 200, 15, -1, FALSE, '`IDJADWAL`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->IDJADWAL->IsPrimaryKey = TRUE; // Primary key field
		$this->IDJADWAL->Nullable = FALSE; // NOT NULL field
		$this->IDJADWAL->Required = TRUE; // Required field
		$this->IDJADWAL->Sortable = TRUE; // Allow sort
		$this->fields['IDJADWAL'] = &$this->IDJADWAL;

		// ID_GURU
		$this->ID_GURU = new DbField('jadwal_pelajaran', 'jadwal_pelajaran', 'x_ID_GURU', 'ID_GURU', '`ID_GURU`', '`ID_GURU`', 200, 12, -1, FALSE, '`ID_GURU`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ID_GURU->Sortable = TRUE; // Allow sort
		$this->fields['ID_GURU'] = &$this->ID_GURU;

		// KODE_MAPEL
		$this->KODE_MAPEL = new DbField('jadwal_pelajaran', 'jadwal_pelajaran', 'x_KODE_MAPEL', 'KODE_MAPEL', '`KODE_MAPEL`', '`KODE_MAPEL`', 200, 10, -1, FALSE, '`KODE_MAPEL`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->KODE_MAPEL->Sortable = TRUE; // Allow sort
		$this->fields['KODE_MAPEL'] = &$this->KODE_MAPEL;

		// IDRUANG
		$this->IDRUANG = new DbField('jadwal_pelajaran', 'jadwal_pelajaran', 'x_IDRUANG', 'IDRUANG', '`IDRUANG`', '`IDRUANG`', 200, 10, -1, FALSE, '`IDRUANG`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->IDRUANG->Sortable = TRUE; // Allow sort
		$this->fields['IDRUANG'] = &$this->IDRUANG;

		// NO_INDUK
		$this->NO_INDUK = new DbField('jadwal_pelajaran', 'jadwal_pelajaran', 'x_NO_INDUK', 'NO_INDUK', '`NO_INDUK`', '`NO_INDUK`', 200, 10, -1, FALSE, '`NO_INDUK`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->NO_INDUK->Sortable = TRUE; // Allow sort
		$this->fields['NO_INDUK'] = &$this->NO_INDUK;

		// HARIJADWAL
		$this->HARIJADWAL = new DbField('jadwal_pelajaran', 'jadwal_pelajaran', 'x_HARIJADWAL', 'HARIJADWAL', '`HARIJADWAL`', '`HARIJADWAL`', 200, 6, -1, FALSE, '`HARIJADWAL`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->HARIJADWAL->Sortable = TRUE; // Allow sort
		$this->fields['HARIJADWAL'] = &$this->HARIJADWAL;

		// SESIJADWAL
		$this->SESIJADWAL = new DbField('jadwal_pelajaran', 'jadwal_pelajaran', 'x_SESIJADWAL', 'SESIJADWAL', '`SESIJADWAL`', '`SESIJADWAL`', 200, 1, -1, FALSE, '`SESIJADWAL`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->SESIJADWAL->Sortable = TRUE; // Allow sort
		$this->fields['SESIJADWAL'] = &$this->SESIJADWAL;

		// WAKTU_MULAI
		$this->WAKTU_MULAI = new DbField('jadwal_pelajaran', 'jadwal_pelajaran', 'x_WAKTU_MULAI', 'WAKTU_MULAI', '`WAKTU_MULAI`', CastDateFieldForLike("`WAKTU_MULAI`", 4, "DB"), 134, 10, 4, FALSE, '`WAKTU_MULAI`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->WAKTU_MULAI->Sortable = TRUE; // Allow sort
		$this->WAKTU_MULAI->DefaultErrorMessage = str_replace("%s", $GLOBALS["TIME_SEPARATOR"], $Language->phrase("IncorrectTime"));
		$this->fields['WAKTU_MULAI'] = &$this->WAKTU_MULAI;

		// WAKTU_SELESAI
		$this->WAKTU_SELESAI = new DbField('jadwal_pelajaran', 'jadwal_pelajaran', 'x_WAKTU_SELESAI', 'WAKTU_SELESAI', '`WAKTU_SELESAI`', CastDateFieldForLike("`WAKTU_SELESAI`", 4, "DB"), 134, 10, 4, FALSE, '`WAKTU_SELESAI`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->WAKTU_SELESAI->Sortable = TRUE; // Allow sort
		$this->WAKTU_SELESAI->DefaultErrorMessage = str_replace("%s", $GLOBALS["TIME_SEPARATOR"], $Language->phrase("IncorrectTime"));
		$this->fields['WAKTU_SELESAI'] = &$this->WAKTU_SELESAI;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`jadwal_pelajaran`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter)
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = Config("USER_ID_ALLOW");
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('IDJADWAL', $rs))
				AddFilter($where, QuotedName('IDJADWAL', $this->Dbid) . '=' . QuotedValue($rs['IDJADWAL'], $this->IDJADWAL->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->IDJADWAL->DbValue = $row['IDJADWAL'];
		$this->ID_GURU->DbValue = $row['ID_GURU'];
		$this->KODE_MAPEL->DbValue = $row['KODE_MAPEL'];
		$this->IDRUANG->DbValue = $row['IDRUANG'];
		$this->NO_INDUK->DbValue = $row['NO_INDUK'];
		$this->HARIJADWAL->DbValue = $row['HARIJADWAL'];
		$this->SESIJADWAL->DbValue = $row['SESIJADWAL'];
		$this->WAKTU_MULAI->DbValue = $row['WAKTU_MULAI'];
		$this->WAKTU_SELESAI->DbValue = $row['WAKTU_SELESAI'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`IDJADWAL` = '@IDJADWAL@'";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('IDJADWAL', $row) ? $row['IDJADWAL'] : NULL;
		else
			$val = $this->IDJADWAL->OldValue !== NULL ? $this->IDJADWAL->OldValue : $this->IDJADWAL->CurrentValue;
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@IDJADWAL@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "jadwal_pelajaranlist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "jadwal_pelajaranview.php")
			return $Language->phrase("View");
		elseif ($pageName == "jadwal_pelajaranedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "jadwal_pelajaranadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "jadwal_pelajaranlist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("jadwal_pelajaranview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("jadwal_pelajaranview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "jadwal_pelajaranadd.php?" . $this->getUrlParm($parm);
		else
			$url = "jadwal_pelajaranadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("jadwal_pelajaranedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("jadwal_pelajaranadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("jadwal_pelajarandelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "IDJADWAL:" . JsonEncode($this->IDJADWAL->CurrentValue, "string");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->IDJADWAL->CurrentValue != NULL) {
			$url .= "IDJADWAL=" . urlencode($this->IDJADWAL->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("IDJADWAL") !== NULL)
				$arKeys[] = Param("IDJADWAL");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->IDJADWAL->CurrentValue = $key;
			else
				$this->IDJADWAL->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->IDJADWAL->setDbValue($rs->fields('IDJADWAL'));
		$this->ID_GURU->setDbValue($rs->fields('ID_GURU'));
		$this->KODE_MAPEL->setDbValue($rs->fields('KODE_MAPEL'));
		$this->IDRUANG->setDbValue($rs->fields('IDRUANG'));
		$this->NO_INDUK->setDbValue($rs->fields('NO_INDUK'));
		$this->HARIJADWAL->setDbValue($rs->fields('HARIJADWAL'));
		$this->SESIJADWAL->setDbValue($rs->fields('SESIJADWAL'));
		$this->WAKTU_MULAI->setDbValue($rs->fields('WAKTU_MULAI'));
		$this->WAKTU_SELESAI->setDbValue($rs->fields('WAKTU_SELESAI'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// IDJADWAL
		// ID_GURU
		// KODE_MAPEL
		// IDRUANG
		// NO_INDUK
		// HARIJADWAL
		// SESIJADWAL
		// WAKTU_MULAI
		// WAKTU_SELESAI
		// IDJADWAL

		$this->IDJADWAL->ViewValue = $this->IDJADWAL->CurrentValue;
		$this->IDJADWAL->ViewCustomAttributes = "";

		// ID_GURU
		$this->ID_GURU->ViewValue = $this->ID_GURU->CurrentValue;
		$this->ID_GURU->ViewCustomAttributes = "";

		// KODE_MAPEL
		$this->KODE_MAPEL->ViewValue = $this->KODE_MAPEL->CurrentValue;
		$this->KODE_MAPEL->ViewCustomAttributes = "";

		// IDRUANG
		$this->IDRUANG->ViewValue = $this->IDRUANG->CurrentValue;
		$this->IDRUANG->ViewCustomAttributes = "";

		// NO_INDUK
		$this->NO_INDUK->ViewValue = $this->NO_INDUK->CurrentValue;
		$this->NO_INDUK->ViewCustomAttributes = "";

		// HARIJADWAL
		$this->HARIJADWAL->ViewValue = $this->HARIJADWAL->CurrentValue;
		$this->HARIJADWAL->ViewCustomAttributes = "";

		// SESIJADWAL
		$this->SESIJADWAL->ViewValue = $this->SESIJADWAL->CurrentValue;
		$this->SESIJADWAL->ViewCustomAttributes = "";

		// WAKTU_MULAI
		$this->WAKTU_MULAI->ViewValue = $this->WAKTU_MULAI->CurrentValue;
		$this->WAKTU_MULAI->ViewValue = FormatDateTime($this->WAKTU_MULAI->ViewValue, 4);
		$this->WAKTU_MULAI->ViewCustomAttributes = "";

		// WAKTU_SELESAI
		$this->WAKTU_SELESAI->ViewValue = $this->WAKTU_SELESAI->CurrentValue;
		$this->WAKTU_SELESAI->ViewValue = FormatDateTime($this->WAKTU_SELESAI->ViewValue, 4);
		$this->WAKTU_SELESAI->ViewCustomAttributes = "";

		// IDJADWAL
		$this->IDJADWAL->LinkCustomAttributes = "";
		$this->IDJADWAL->HrefValue = "";
		$this->IDJADWAL->TooltipValue = "";

		// ID_GURU
		$this->ID_GURU->LinkCustomAttributes = "";
		$this->ID_GURU->HrefValue = "";
		$this->ID_GURU->TooltipValue = "";

		// KODE_MAPEL
		$this->KODE_MAPEL->LinkCustomAttributes = "";
		$this->KODE_MAPEL->HrefValue = "";
		$this->KODE_MAPEL->TooltipValue = "";

		// IDRUANG
		$this->IDRUANG->LinkCustomAttributes = "";
		$this->IDRUANG->HrefValue = "";
		$this->IDRUANG->TooltipValue = "";

		// NO_INDUK
		$this->NO_INDUK->LinkCustomAttributes = "";
		$this->NO_INDUK->HrefValue = "";
		$this->NO_INDUK->TooltipValue = "";

		// HARIJADWAL
		$this->HARIJADWAL->LinkCustomAttributes = "";
		$this->HARIJADWAL->HrefValue = "";
		$this->HARIJADWAL->TooltipValue = "";

		// SESIJADWAL
		$this->SESIJADWAL->LinkCustomAttributes = "";
		$this->SESIJADWAL->HrefValue = "";
		$this->SESIJADWAL->TooltipValue = "";

		// WAKTU_MULAI
		$this->WAKTU_MULAI->LinkCustomAttributes = "";
		$this->WAKTU_MULAI->HrefValue = "";
		$this->WAKTU_MULAI->TooltipValue = "";

		// WAKTU_SELESAI
		$this->WAKTU_SELESAI->LinkCustomAttributes = "";
		$this->WAKTU_SELESAI->HrefValue = "";
		$this->WAKTU_SELESAI->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// IDJADWAL
		$this->IDJADWAL->EditAttrs["class"] = "form-control";
		$this->IDJADWAL->EditCustomAttributes = "";
		if (!$this->IDJADWAL->Raw)
			$this->IDJADWAL->CurrentValue = HtmlDecode($this->IDJADWAL->CurrentValue);
		$this->IDJADWAL->EditValue = $this->IDJADWAL->CurrentValue;
		$this->IDJADWAL->PlaceHolder = RemoveHtml($this->IDJADWAL->caption());

		// ID_GURU
		$this->ID_GURU->EditAttrs["class"] = "form-control";
		$this->ID_GURU->EditCustomAttributes = "";
		if (!$this->ID_GURU->Raw)
			$this->ID_GURU->CurrentValue = HtmlDecode($this->ID_GURU->CurrentValue);
		$this->ID_GURU->EditValue = $this->ID_GURU->CurrentValue;
		$this->ID_GURU->PlaceHolder = RemoveHtml($this->ID_GURU->caption());

		// KODE_MAPEL
		$this->KODE_MAPEL->EditAttrs["class"] = "form-control";
		$this->KODE_MAPEL->EditCustomAttributes = "";
		if (!$this->KODE_MAPEL->Raw)
			$this->KODE_MAPEL->CurrentValue = HtmlDecode($this->KODE_MAPEL->CurrentValue);
		$this->KODE_MAPEL->EditValue = $this->KODE_MAPEL->CurrentValue;
		$this->KODE_MAPEL->PlaceHolder = RemoveHtml($this->KODE_MAPEL->caption());

		// IDRUANG
		$this->IDRUANG->EditAttrs["class"] = "form-control";
		$this->IDRUANG->EditCustomAttributes = "";
		if (!$this->IDRUANG->Raw)
			$this->IDRUANG->CurrentValue = HtmlDecode($this->IDRUANG->CurrentValue);
		$this->IDRUANG->EditValue = $this->IDRUANG->CurrentValue;
		$this->IDRUANG->PlaceHolder = RemoveHtml($this->IDRUANG->caption());

		// NO_INDUK
		$this->NO_INDUK->EditAttrs["class"] = "form-control";
		$this->NO_INDUK->EditCustomAttributes = "";
		if (!$this->NO_INDUK->Raw)
			$this->NO_INDUK->CurrentValue = HtmlDecode($this->NO_INDUK->CurrentValue);
		$this->NO_INDUK->EditValue = $this->NO_INDUK->CurrentValue;
		$this->NO_INDUK->PlaceHolder = RemoveHtml($this->NO_INDUK->caption());

		// HARIJADWAL
		$this->HARIJADWAL->EditAttrs["class"] = "form-control";
		$this->HARIJADWAL->EditCustomAttributes = "";
		if (!$this->HARIJADWAL->Raw)
			$this->HARIJADWAL->CurrentValue = HtmlDecode($this->HARIJADWAL->CurrentValue);
		$this->HARIJADWAL->EditValue = $this->HARIJADWAL->CurrentValue;
		$this->HARIJADWAL->PlaceHolder = RemoveHtml($this->HARIJADWAL->caption());

		// SESIJADWAL
		$this->SESIJADWAL->EditAttrs["class"] = "form-control";
		$this->SESIJADWAL->EditCustomAttributes = "";
		if (!$this->SESIJADWAL->Raw)
			$this->SESIJADWAL->CurrentValue = HtmlDecode($this->SESIJADWAL->CurrentValue);
		$this->SESIJADWAL->EditValue = $this->SESIJADWAL->CurrentValue;
		$this->SESIJADWAL->PlaceHolder = RemoveHtml($this->SESIJADWAL->caption());

		// WAKTU_MULAI
		$this->WAKTU_MULAI->EditAttrs["class"] = "form-control";
		$this->WAKTU_MULAI->EditCustomAttributes = "";
		$this->WAKTU_MULAI->EditValue = $this->WAKTU_MULAI->CurrentValue;
		$this->WAKTU_MULAI->PlaceHolder = RemoveHtml($this->WAKTU_MULAI->caption());

		// WAKTU_SELESAI
		$this->WAKTU_SELESAI->EditAttrs["class"] = "form-control";
		$this->WAKTU_SELESAI->EditCustomAttributes = "";
		$this->WAKTU_SELESAI->EditValue = $this->WAKTU_SELESAI->CurrentValue;
		$this->WAKTU_SELESAI->PlaceHolder = RemoveHtml($this->WAKTU_SELESAI->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->IDJADWAL);
					$doc->exportCaption($this->ID_GURU);
					$doc->exportCaption($this->KODE_MAPEL);
					$doc->exportCaption($this->IDRUANG);
					$doc->exportCaption($this->NO_INDUK);
					$doc->exportCaption($this->HARIJADWAL);
					$doc->exportCaption($this->SESIJADWAL);
					$doc->exportCaption($this->WAKTU_MULAI);
					$doc->exportCaption($this->WAKTU_SELESAI);
				} else {
					$doc->exportCaption($this->IDJADWAL);
					$doc->exportCaption($this->ID_GURU);
					$doc->exportCaption($this->KODE_MAPEL);
					$doc->exportCaption($this->IDRUANG);
					$doc->exportCaption($this->NO_INDUK);
					$doc->exportCaption($this->HARIJADWAL);
					$doc->exportCaption($this->SESIJADWAL);
					$doc->exportCaption($this->WAKTU_MULAI);
					$doc->exportCaption($this->WAKTU_SELESAI);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->IDJADWAL);
						$doc->exportField($this->ID_GURU);
						$doc->exportField($this->KODE_MAPEL);
						$doc->exportField($this->IDRUANG);
						$doc->exportField($this->NO_INDUK);
						$doc->exportField($this->HARIJADWAL);
						$doc->exportField($this->SESIJADWAL);
						$doc->exportField($this->WAKTU_MULAI);
						$doc->exportField($this->WAKTU_SELESAI);
					} else {
						$doc->exportField($this->IDJADWAL);
						$doc->exportField($this->ID_GURU);
						$doc->exportField($this->KODE_MAPEL);
						$doc->exportField($this->IDRUANG);
						$doc->exportField($this->NO_INDUK);
						$doc->exportField($this->HARIJADWAL);
						$doc->exportField($this->SESIJADWAL);
						$doc->exportField($this->WAKTU_MULAI);
						$doc->exportField($this->WAKTU_SELESAI);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>