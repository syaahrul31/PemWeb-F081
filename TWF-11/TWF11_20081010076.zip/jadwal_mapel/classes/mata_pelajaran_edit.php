<?php
namespace PHPMaker2020\project1;

/**
 * Page class
 */
class mata_pelajaran_edit extends mata_pelajaran
{

	// Page ID
	public $PageID = "edit";

	// Project ID
	public $ProjectID = "{6B4A168D-AFB7-4B2A-A9A9-04A7731AE34A}";

	// Table name
	public $TableName = 'mata_pelajaran';

	// Page object name
	public $PageObjName = "mata_pelajaran_edit";

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = TRUE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (mata_pelajaran)
		if (!isset($GLOBALS["mata_pelajaran"]) || get_class($GLOBALS["mata_pelajaran"]) == PROJECT_NAMESPACE . "mata_pelajaran") {
			$GLOBALS["mata_pelajaran"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["mata_pelajaran"];
		}

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'edit');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'mata_pelajaran');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $mata_pelajaran;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($mata_pelajaran);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();

			// Handle modal response
			if ($this->IsModal) { // Show as modal
				$row = ["url" => $url, "modal" => "1"];
				$pageName = GetPageName($url);
				if ($pageName != $this->getListUrl()) { // Not List page
					$row["caption"] = $this->getModalCaption($pageName);
					if ($pageName == "mata_pelajaranview.php")
						$row["view"] = "1";
				} else { // List page should not be shown as modal => error
					$row["error"] = $this->getFailureMessage();
					$this->clearFailureMessage();
				}
				WriteJson($row);
			} else {
				SaveDebugMessage();
				AddHeader("Location", $url);
			}
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["mimeType" => ContentType($val), "url" => $url];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$row[$fldname] = ["mimeType" => MimeContentType($val), "url" => FullUrl($fld->hrefPath() . $val)];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => FullUrl($fld->hrefPath() . $file)];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['KODE_MAPEL'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!$this->setupApiRequest())
			return FALSE;

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		if (!$Security->isLoggedIn()) // Logged in
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Get("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API request
	public function setupApiRequest()
	{
		global $Security;

		// Check security for API request
		If (ValidApiRequest()) {
			return TRUE;
		}
		return FALSE;
	}
	public $FormClassName = "ew-horizontal ew-form ew-edit-form";
	public $IsModal = FALSE;
	public $IsMobileOrModal = FALSE;
	public $DbMasterFilter;
	public $DbDetailFilter;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SkipHeaderFooter;

		// Is modal
		$this->IsModal = (Param("modal") == "1");

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (!$this->setupApiRequest()) {
			$Security = new AdvancedSecurity();
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if (!$Security->canEdit()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("mata_pelajaranlist.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}

		// Create form object
		$CurrentForm = new HttpForm();
		$this->CurrentAction = Param("action"); // Set up current action
		$this->KODE_MAPEL->setVisibility();
		$this->NAMA_MAPEL->setVisibility();
		$this->BIDANG_MAPEL->setVisibility();
		$this->JENIS_MAPEL->setVisibility();
		$this->TIPE_MAPEL->setVisibility();
		$this->JUMLAH_PERTEMUAN->setVisibility();
		$this->DURASI_MAPEL->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		// Check modal

		if ($this->IsModal)
			$SkipHeaderFooter = TRUE;
		$this->IsMobileOrModal = IsMobile() || $this->IsModal;
		$this->FormClassName = "ew-form ew-edit-form ew-horizontal";
		$loaded = FALSE;
		$postBack = FALSE;

		// Set up current action and primary key
		if (IsApi()) {

			// Load key values
			$loaded = TRUE;
			if (Get("KODE_MAPEL") !== NULL) {
				$this->KODE_MAPEL->setQueryStringValue(Get("KODE_MAPEL"));
				$this->KODE_MAPEL->setOldValue($this->KODE_MAPEL->QueryStringValue);
			} elseif (Key(0) !== NULL) {
				$this->KODE_MAPEL->setQueryStringValue(Key(0));
				$this->KODE_MAPEL->setOldValue($this->KODE_MAPEL->QueryStringValue);
			} elseif (Post("KODE_MAPEL") !== NULL) {
				$this->KODE_MAPEL->setFormValue(Post("KODE_MAPEL"));
				$this->KODE_MAPEL->setOldValue($this->KODE_MAPEL->FormValue);
			} elseif (Route(2) !== NULL) {
				$this->KODE_MAPEL->setQueryStringValue(Route(2));
				$this->KODE_MAPEL->setOldValue($this->KODE_MAPEL->QueryStringValue);
			} else {
				$loaded = FALSE; // Unable to load key
			}

			// Load record
			if ($loaded)
				$loaded = $this->loadRow();
			if (!$loaded) {
				$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
				$this->terminate();
				return;
			}
			$this->CurrentAction = "update"; // Update record directly
			$postBack = TRUE;
		} else {
			if (Post("action") !== NULL) {
				$this->CurrentAction = Post("action"); // Get action code
				if (!$this->isShow()) // Not reload record, handle as postback
					$postBack = TRUE;

				// Load key from Form
				if ($CurrentForm->hasValue("x_KODE_MAPEL")) {
					$this->KODE_MAPEL->setFormValue($CurrentForm->getValue("x_KODE_MAPEL"));
				}
			} else {
				$this->CurrentAction = "show"; // Default action is display

				// Load key from QueryString / Route
				$loadByQuery = FALSE;
				if (Get("KODE_MAPEL") !== NULL) {
					$this->KODE_MAPEL->setQueryStringValue(Get("KODE_MAPEL"));
					$loadByQuery = TRUE;
				} elseif (Route(2) !== NULL) {
					$this->KODE_MAPEL->setQueryStringValue(Route(2));
					$loadByQuery = TRUE;
				} else {
					$this->KODE_MAPEL->CurrentValue = NULL;
				}
			}

			// Load current record
			$loaded = $this->loadRow();
		}

		// Process form if post back
		if ($postBack) {
			$this->loadFormValues(); // Get form values
		}

		// Validate form if post back
		if ($postBack) {
			if (!$this->validateForm()) {
				$this->setFailureMessage($FormError);
				$this->EventCancelled = TRUE; // Event cancelled
				$this->restoreFormValues();
				if (IsApi()) {
					$this->terminate();
					return;
				} else {
					$this->CurrentAction = ""; // Form error, reset action
				}
			}
		}

		// Perform current action
		switch ($this->CurrentAction) {
			case "show": // Get a record to display
				if (!$loaded) { // Load record based on key
					if ($this->getFailureMessage() == "")
						$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
					$this->terminate("mata_pelajaranlist.php"); // No matching record, return to list
				}
				break;
			case "update": // Update
				$returnUrl = $this->getReturnUrl();
				if (GetPageName($returnUrl) == "mata_pelajaranlist.php")
					$returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
				$this->SendEmail = TRUE; // Send email on update success
				if ($this->editRow()) { // Update record based on key
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->phrase("UpdateSuccess")); // Update success
					if (IsApi()) {
						$this->terminate(TRUE);
						return;
					} else {
						$this->terminate($returnUrl); // Return to caller
					}
				} elseif (IsApi()) { // API request, return
					$this->terminate();
					return;
				} elseif ($this->getFailureMessage() == $Language->phrase("NoRecord")) {
					$this->terminate($returnUrl); // Return to caller
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->restoreFormValues(); // Restore form values if update failed
				}
		}

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Render the record
		$this->RowType = ROWTYPE_EDIT; // Render as Edit
		$this->resetAttributes();
		$this->renderRow();
	}

	// Get upload files
	protected function getUploadFiles()
	{
		global $CurrentForm, $Language;
	}

	// Load form values
	protected function loadFormValues()
	{

		// Load from form
		global $CurrentForm;

		// Check field name 'KODE_MAPEL' first before field var 'x_KODE_MAPEL'
		$val = $CurrentForm->hasValue("KODE_MAPEL") ? $CurrentForm->getValue("KODE_MAPEL") : $CurrentForm->getValue("x_KODE_MAPEL");
		if (!$this->KODE_MAPEL->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->KODE_MAPEL->Visible = FALSE; // Disable update for API request
			else
				$this->KODE_MAPEL->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_KODE_MAPEL"))
			$this->KODE_MAPEL->setOldValue($CurrentForm->getValue("o_KODE_MAPEL"));

		// Check field name 'NAMA_MAPEL' first before field var 'x_NAMA_MAPEL'
		$val = $CurrentForm->hasValue("NAMA_MAPEL") ? $CurrentForm->getValue("NAMA_MAPEL") : $CurrentForm->getValue("x_NAMA_MAPEL");
		if (!$this->NAMA_MAPEL->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->NAMA_MAPEL->Visible = FALSE; // Disable update for API request
			else
				$this->NAMA_MAPEL->setFormValue($val);
		}

		// Check field name 'BIDANG_MAPEL' first before field var 'x_BIDANG_MAPEL'
		$val = $CurrentForm->hasValue("BIDANG_MAPEL") ? $CurrentForm->getValue("BIDANG_MAPEL") : $CurrentForm->getValue("x_BIDANG_MAPEL");
		if (!$this->BIDANG_MAPEL->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->BIDANG_MAPEL->Visible = FALSE; // Disable update for API request
			else
				$this->BIDANG_MAPEL->setFormValue($val);
		}

		// Check field name 'JENIS_MAPEL' first before field var 'x_JENIS_MAPEL'
		$val = $CurrentForm->hasValue("JENIS_MAPEL") ? $CurrentForm->getValue("JENIS_MAPEL") : $CurrentForm->getValue("x_JENIS_MAPEL");
		if (!$this->JENIS_MAPEL->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->JENIS_MAPEL->Visible = FALSE; // Disable update for API request
			else
				$this->JENIS_MAPEL->setFormValue($val);
		}

		// Check field name 'TIPE_MAPEL' first before field var 'x_TIPE_MAPEL'
		$val = $CurrentForm->hasValue("TIPE_MAPEL") ? $CurrentForm->getValue("TIPE_MAPEL") : $CurrentForm->getValue("x_TIPE_MAPEL");
		if (!$this->TIPE_MAPEL->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->TIPE_MAPEL->Visible = FALSE; // Disable update for API request
			else
				$this->TIPE_MAPEL->setFormValue($val);
		}

		// Check field name 'JUMLAH_PERTEMUAN' first before field var 'x_JUMLAH_PERTEMUAN'
		$val = $CurrentForm->hasValue("JUMLAH_PERTEMUAN") ? $CurrentForm->getValue("JUMLAH_PERTEMUAN") : $CurrentForm->getValue("x_JUMLAH_PERTEMUAN");
		if (!$this->JUMLAH_PERTEMUAN->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->JUMLAH_PERTEMUAN->Visible = FALSE; // Disable update for API request
			else
				$this->JUMLAH_PERTEMUAN->setFormValue($val);
		}

		// Check field name 'DURASI_MAPEL' first before field var 'x_DURASI_MAPEL'
		$val = $CurrentForm->hasValue("DURASI_MAPEL") ? $CurrentForm->getValue("DURASI_MAPEL") : $CurrentForm->getValue("x_DURASI_MAPEL");
		if (!$this->DURASI_MAPEL->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->DURASI_MAPEL->Visible = FALSE; // Disable update for API request
			else
				$this->DURASI_MAPEL->setFormValue($val);
			$this->DURASI_MAPEL->CurrentValue = UnFormatDateTime($this->DURASI_MAPEL->CurrentValue, 4);
		}
	}

	// Restore form values
	public function restoreFormValues()
	{
		global $CurrentForm;
		$this->KODE_MAPEL->CurrentValue = $this->KODE_MAPEL->FormValue;
		$this->NAMA_MAPEL->CurrentValue = $this->NAMA_MAPEL->FormValue;
		$this->BIDANG_MAPEL->CurrentValue = $this->BIDANG_MAPEL->FormValue;
		$this->JENIS_MAPEL->CurrentValue = $this->JENIS_MAPEL->FormValue;
		$this->TIPE_MAPEL->CurrentValue = $this->TIPE_MAPEL->FormValue;
		$this->JUMLAH_PERTEMUAN->CurrentValue = $this->JUMLAH_PERTEMUAN->FormValue;
		$this->DURASI_MAPEL->CurrentValue = $this->DURASI_MAPEL->FormValue;
		$this->DURASI_MAPEL->CurrentValue = UnFormatDateTime($this->DURASI_MAPEL->CurrentValue, 4);
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->KODE_MAPEL->setDbValue($row['KODE_MAPEL']);
		$this->NAMA_MAPEL->setDbValue($row['NAMA_MAPEL']);
		$this->BIDANG_MAPEL->setDbValue($row['BIDANG_MAPEL']);
		$this->JENIS_MAPEL->setDbValue($row['JENIS_MAPEL']);
		$this->TIPE_MAPEL->setDbValue($row['TIPE_MAPEL']);
		$this->JUMLAH_PERTEMUAN->setDbValue($row['JUMLAH_PERTEMUAN']);
		$this->DURASI_MAPEL->setDbValue($row['DURASI_MAPEL']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$row = [];
		$row['KODE_MAPEL'] = NULL;
		$row['NAMA_MAPEL'] = NULL;
		$row['BIDANG_MAPEL'] = NULL;
		$row['JENIS_MAPEL'] = NULL;
		$row['TIPE_MAPEL'] = NULL;
		$row['JUMLAH_PERTEMUAN'] = NULL;
		$row['DURASI_MAPEL'] = NULL;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("KODE_MAPEL")) != "")
			$this->KODE_MAPEL->OldValue = $this->getKey("KODE_MAPEL"); // KODE_MAPEL
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Convert decimal values if posted back

		if ($this->JUMLAH_PERTEMUAN->FormValue == $this->JUMLAH_PERTEMUAN->CurrentValue && is_numeric(ConvertToFloatString($this->JUMLAH_PERTEMUAN->CurrentValue)))
			$this->JUMLAH_PERTEMUAN->CurrentValue = ConvertToFloatString($this->JUMLAH_PERTEMUAN->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// KODE_MAPEL
		// NAMA_MAPEL
		// BIDANG_MAPEL
		// JENIS_MAPEL
		// TIPE_MAPEL
		// JUMLAH_PERTEMUAN
		// DURASI_MAPEL

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// KODE_MAPEL
			$this->KODE_MAPEL->ViewValue = $this->KODE_MAPEL->CurrentValue;
			$this->KODE_MAPEL->ViewCustomAttributes = "";

			// NAMA_MAPEL
			$this->NAMA_MAPEL->ViewValue = $this->NAMA_MAPEL->CurrentValue;
			$this->NAMA_MAPEL->ViewCustomAttributes = "";

			// BIDANG_MAPEL
			$this->BIDANG_MAPEL->ViewValue = $this->BIDANG_MAPEL->CurrentValue;
			$this->BIDANG_MAPEL->ViewCustomAttributes = "";

			// JENIS_MAPEL
			$this->JENIS_MAPEL->ViewValue = $this->JENIS_MAPEL->CurrentValue;
			$this->JENIS_MAPEL->ViewCustomAttributes = "";

			// TIPE_MAPEL
			$this->TIPE_MAPEL->ViewValue = $this->TIPE_MAPEL->CurrentValue;
			$this->TIPE_MAPEL->ViewCustomAttributes = "";

			// JUMLAH_PERTEMUAN
			$this->JUMLAH_PERTEMUAN->ViewValue = $this->JUMLAH_PERTEMUAN->CurrentValue;
			$this->JUMLAH_PERTEMUAN->ViewValue = FormatNumber($this->JUMLAH_PERTEMUAN->ViewValue, 2, -2, -2, -2);
			$this->JUMLAH_PERTEMUAN->ViewCustomAttributes = "";

			// DURASI_MAPEL
			$this->DURASI_MAPEL->ViewValue = $this->DURASI_MAPEL->CurrentValue;
			$this->DURASI_MAPEL->ViewValue = FormatDateTime($this->DURASI_MAPEL->ViewValue, 4);
			$this->DURASI_MAPEL->ViewCustomAttributes = "";

			// KODE_MAPEL
			$this->KODE_MAPEL->LinkCustomAttributes = "";
			$this->KODE_MAPEL->HrefValue = "";
			$this->KODE_MAPEL->TooltipValue = "";

			// NAMA_MAPEL
			$this->NAMA_MAPEL->LinkCustomAttributes = "";
			$this->NAMA_MAPEL->HrefValue = "";
			$this->NAMA_MAPEL->TooltipValue = "";

			// BIDANG_MAPEL
			$this->BIDANG_MAPEL->LinkCustomAttributes = "";
			$this->BIDANG_MAPEL->HrefValue = "";
			$this->BIDANG_MAPEL->TooltipValue = "";

			// JENIS_MAPEL
			$this->JENIS_MAPEL->LinkCustomAttributes = "";
			$this->JENIS_MAPEL->HrefValue = "";
			$this->JENIS_MAPEL->TooltipValue = "";

			// TIPE_MAPEL
			$this->TIPE_MAPEL->LinkCustomAttributes = "";
			$this->TIPE_MAPEL->HrefValue = "";
			$this->TIPE_MAPEL->TooltipValue = "";

			// JUMLAH_PERTEMUAN
			$this->JUMLAH_PERTEMUAN->LinkCustomAttributes = "";
			$this->JUMLAH_PERTEMUAN->HrefValue = "";
			$this->JUMLAH_PERTEMUAN->TooltipValue = "";

			// DURASI_MAPEL
			$this->DURASI_MAPEL->LinkCustomAttributes = "";
			$this->DURASI_MAPEL->HrefValue = "";
			$this->DURASI_MAPEL->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_EDIT) { // Edit row

			// KODE_MAPEL
			$this->KODE_MAPEL->EditAttrs["class"] = "form-control";
			$this->KODE_MAPEL->EditCustomAttributes = "";
			if (!$this->KODE_MAPEL->Raw)
				$this->KODE_MAPEL->CurrentValue = HtmlDecode($this->KODE_MAPEL->CurrentValue);
			$this->KODE_MAPEL->EditValue = HtmlEncode($this->KODE_MAPEL->CurrentValue);
			$this->KODE_MAPEL->PlaceHolder = RemoveHtml($this->KODE_MAPEL->caption());

			// NAMA_MAPEL
			$this->NAMA_MAPEL->EditAttrs["class"] = "form-control";
			$this->NAMA_MAPEL->EditCustomAttributes = "";
			if (!$this->NAMA_MAPEL->Raw)
				$this->NAMA_MAPEL->CurrentValue = HtmlDecode($this->NAMA_MAPEL->CurrentValue);
			$this->NAMA_MAPEL->EditValue = HtmlEncode($this->NAMA_MAPEL->CurrentValue);
			$this->NAMA_MAPEL->PlaceHolder = RemoveHtml($this->NAMA_MAPEL->caption());

			// BIDANG_MAPEL
			$this->BIDANG_MAPEL->EditAttrs["class"] = "form-control";
			$this->BIDANG_MAPEL->EditCustomAttributes = "";
			if (!$this->BIDANG_MAPEL->Raw)
				$this->BIDANG_MAPEL->CurrentValue = HtmlDecode($this->BIDANG_MAPEL->CurrentValue);
			$this->BIDANG_MAPEL->EditValue = HtmlEncode($this->BIDANG_MAPEL->CurrentValue);
			$this->BIDANG_MAPEL->PlaceHolder = RemoveHtml($this->BIDANG_MAPEL->caption());

			// JENIS_MAPEL
			$this->JENIS_MAPEL->EditAttrs["class"] = "form-control";
			$this->JENIS_MAPEL->EditCustomAttributes = "";
			if (!$this->JENIS_MAPEL->Raw)
				$this->JENIS_MAPEL->CurrentValue = HtmlDecode($this->JENIS_MAPEL->CurrentValue);
			$this->JENIS_MAPEL->EditValue = HtmlEncode($this->JENIS_MAPEL->CurrentValue);
			$this->JENIS_MAPEL->PlaceHolder = RemoveHtml($this->JENIS_MAPEL->caption());

			// TIPE_MAPEL
			$this->TIPE_MAPEL->EditAttrs["class"] = "form-control";
			$this->TIPE_MAPEL->EditCustomAttributes = "";
			if (!$this->TIPE_MAPEL->Raw)
				$this->TIPE_MAPEL->CurrentValue = HtmlDecode($this->TIPE_MAPEL->CurrentValue);
			$this->TIPE_MAPEL->EditValue = HtmlEncode($this->TIPE_MAPEL->CurrentValue);
			$this->TIPE_MAPEL->PlaceHolder = RemoveHtml($this->TIPE_MAPEL->caption());

			// JUMLAH_PERTEMUAN
			$this->JUMLAH_PERTEMUAN->EditAttrs["class"] = "form-control";
			$this->JUMLAH_PERTEMUAN->EditCustomAttributes = "";
			$this->JUMLAH_PERTEMUAN->EditValue = HtmlEncode($this->JUMLAH_PERTEMUAN->CurrentValue);
			$this->JUMLAH_PERTEMUAN->PlaceHolder = RemoveHtml($this->JUMLAH_PERTEMUAN->caption());
			if (strval($this->JUMLAH_PERTEMUAN->EditValue) != "" && is_numeric($this->JUMLAH_PERTEMUAN->EditValue))
				$this->JUMLAH_PERTEMUAN->EditValue = FormatNumber($this->JUMLAH_PERTEMUAN->EditValue, -2, -2, -2, -2);
			

			// DURASI_MAPEL
			$this->DURASI_MAPEL->EditAttrs["class"] = "form-control";
			$this->DURASI_MAPEL->EditCustomAttributes = "";
			$this->DURASI_MAPEL->EditValue = HtmlEncode($this->DURASI_MAPEL->CurrentValue);
			$this->DURASI_MAPEL->PlaceHolder = RemoveHtml($this->DURASI_MAPEL->caption());

			// Edit refer script
			// KODE_MAPEL

			$this->KODE_MAPEL->LinkCustomAttributes = "";
			$this->KODE_MAPEL->HrefValue = "";

			// NAMA_MAPEL
			$this->NAMA_MAPEL->LinkCustomAttributes = "";
			$this->NAMA_MAPEL->HrefValue = "";

			// BIDANG_MAPEL
			$this->BIDANG_MAPEL->LinkCustomAttributes = "";
			$this->BIDANG_MAPEL->HrefValue = "";

			// JENIS_MAPEL
			$this->JENIS_MAPEL->LinkCustomAttributes = "";
			$this->JENIS_MAPEL->HrefValue = "";

			// TIPE_MAPEL
			$this->TIPE_MAPEL->LinkCustomAttributes = "";
			$this->TIPE_MAPEL->HrefValue = "";

			// JUMLAH_PERTEMUAN
			$this->JUMLAH_PERTEMUAN->LinkCustomAttributes = "";
			$this->JUMLAH_PERTEMUAN->HrefValue = "";

			// DURASI_MAPEL
			$this->DURASI_MAPEL->LinkCustomAttributes = "";
			$this->DURASI_MAPEL->HrefValue = "";
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	protected function validateForm()
	{
		global $Language, $FormError;

		// Initialize form error message
		$FormError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return ($FormError == "");
		if ($this->KODE_MAPEL->Required) {
			if (!$this->KODE_MAPEL->IsDetailKey && $this->KODE_MAPEL->FormValue != NULL && $this->KODE_MAPEL->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->KODE_MAPEL->caption(), $this->KODE_MAPEL->RequiredErrorMessage));
			}
		}
		if ($this->NAMA_MAPEL->Required) {
			if (!$this->NAMA_MAPEL->IsDetailKey && $this->NAMA_MAPEL->FormValue != NULL && $this->NAMA_MAPEL->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->NAMA_MAPEL->caption(), $this->NAMA_MAPEL->RequiredErrorMessage));
			}
		}
		if ($this->BIDANG_MAPEL->Required) {
			if (!$this->BIDANG_MAPEL->IsDetailKey && $this->BIDANG_MAPEL->FormValue != NULL && $this->BIDANG_MAPEL->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->BIDANG_MAPEL->caption(), $this->BIDANG_MAPEL->RequiredErrorMessage));
			}
		}
		if ($this->JENIS_MAPEL->Required) {
			if (!$this->JENIS_MAPEL->IsDetailKey && $this->JENIS_MAPEL->FormValue != NULL && $this->JENIS_MAPEL->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->JENIS_MAPEL->caption(), $this->JENIS_MAPEL->RequiredErrorMessage));
			}
		}
		if ($this->TIPE_MAPEL->Required) {
			if (!$this->TIPE_MAPEL->IsDetailKey && $this->TIPE_MAPEL->FormValue != NULL && $this->TIPE_MAPEL->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->TIPE_MAPEL->caption(), $this->TIPE_MAPEL->RequiredErrorMessage));
			}
		}
		if ($this->JUMLAH_PERTEMUAN->Required) {
			if (!$this->JUMLAH_PERTEMUAN->IsDetailKey && $this->JUMLAH_PERTEMUAN->FormValue != NULL && $this->JUMLAH_PERTEMUAN->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->JUMLAH_PERTEMUAN->caption(), $this->JUMLAH_PERTEMUAN->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->JUMLAH_PERTEMUAN->FormValue)) {
			AddMessage($FormError, $this->JUMLAH_PERTEMUAN->errorMessage());
		}
		if ($this->DURASI_MAPEL->Required) {
			if (!$this->DURASI_MAPEL->IsDetailKey && $this->DURASI_MAPEL->FormValue != NULL && $this->DURASI_MAPEL->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->DURASI_MAPEL->caption(), $this->DURASI_MAPEL->RequiredErrorMessage));
			}
		}
		if (!CheckTime($this->DURASI_MAPEL->FormValue)) {
			AddMessage($FormError, $this->DURASI_MAPEL->errorMessage());
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($FormError, $formCustomError);
		}
		return $validateForm;
	}

	// Update record based on key values
	protected function editRow()
	{
		global $Security, $Language;
		$oldKeyFilter = $this->getRecordFilter();
		$filter = $this->applyUserIDFilters($oldKeyFilter);
		$conn = $this->getConnection();
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE)
			return FALSE;
		if ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
			$editRow = FALSE; // Update Failed
		} else {

			// Save old values
			$rsold = &$rs->fields;
			$this->loadDbValues($rsold);
			$rsnew = [];

			// KODE_MAPEL
			$this->KODE_MAPEL->setDbValueDef($rsnew, $this->KODE_MAPEL->CurrentValue, "", $this->KODE_MAPEL->ReadOnly);

			// NAMA_MAPEL
			$this->NAMA_MAPEL->setDbValueDef($rsnew, $this->NAMA_MAPEL->CurrentValue, NULL, $this->NAMA_MAPEL->ReadOnly);

			// BIDANG_MAPEL
			$this->BIDANG_MAPEL->setDbValueDef($rsnew, $this->BIDANG_MAPEL->CurrentValue, NULL, $this->BIDANG_MAPEL->ReadOnly);

			// JENIS_MAPEL
			$this->JENIS_MAPEL->setDbValueDef($rsnew, $this->JENIS_MAPEL->CurrentValue, NULL, $this->JENIS_MAPEL->ReadOnly);

			// TIPE_MAPEL
			$this->TIPE_MAPEL->setDbValueDef($rsnew, $this->TIPE_MAPEL->CurrentValue, NULL, $this->TIPE_MAPEL->ReadOnly);

			// JUMLAH_PERTEMUAN
			$this->JUMLAH_PERTEMUAN->setDbValueDef($rsnew, $this->JUMLAH_PERTEMUAN->CurrentValue, NULL, $this->JUMLAH_PERTEMUAN->ReadOnly);

			// DURASI_MAPEL
			$this->DURASI_MAPEL->setDbValueDef($rsnew, $this->DURASI_MAPEL->CurrentValue, NULL, $this->DURASI_MAPEL->ReadOnly);

			// Call Row Updating event
			$updateRow = $this->Row_Updating($rsold, $rsnew);

			// Check for duplicate key when key changed
			if ($updateRow) {
				$newKeyFilter = $this->getRecordFilter($rsnew);
				if ($newKeyFilter != $oldKeyFilter) {
					$rsChk = $this->loadRs($newKeyFilter);
					if ($rsChk && !$rsChk->EOF) {
						$keyErrMsg = str_replace("%f", $newKeyFilter, $Language->phrase("DupKey"));
						$this->setFailureMessage($keyErrMsg);
						$rsChk->close();
						$updateRow = FALSE;
					}
				}
			}
			if ($updateRow) {
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				if (count($rsnew) > 0)
					$editRow = $this->update($rsnew, "", $rsold);
				else
					$editRow = TRUE; // No field to update
				$conn->raiseErrorFn = "";
				if ($editRow) {
				}
			} else {
				if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

					// Use the message, do nothing
				} elseif ($this->CancelMessage != "") {
					$this->setFailureMessage($this->CancelMessage);
					$this->CancelMessage = "";
				} else {
					$this->setFailureMessage($Language->phrase("UpdateCancelled"));
				}
				$editRow = FALSE;
			}
		}

		// Call Row_Updated event
		if ($editRow)
			$this->Row_Updated($rsold, $rsnew);
		$rs->close();

		// Clean upload path if any
		if ($editRow) {
		}

		// Write JSON for API request
		if (IsApi() && $editRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $editRow;
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("mata_pelajaranlist.php"), "", $this->TableVar, TRUE);
		$pageId = "edit";
		$Breadcrumb->add("edit", $pageId, $url);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Set up starting record parameters
	public function setupStartRecord()
	{
		if ($this->DisplayRecords == 0)
			return;
		if ($this->isPageRequest()) { // Validate request
			$startRec = Get(Config("TABLE_START_REC"));
			$pageNo = Get(Config("TABLE_PAGE_NO"));
			if ($pageNo !== NULL) { // Check for "pageno" parameter first
				if (is_numeric($pageNo)) {
					$this->StartRecord = ($pageNo - 1) * $this->DisplayRecords + 1;
					if ($this->StartRecord <= 0) {
						$this->StartRecord = 1;
					} elseif ($this->StartRecord >= (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1) {
						$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1;
					}
					$this->setStartRecordNumber($this->StartRecord);
				}
			} elseif ($startRec !== NULL) { // Check for "start" parameter
				$this->StartRecord = $startRec;
				$this->setStartRecordNumber($this->StartRecord);
			}
		}
		$this->StartRecord = $this->getStartRecordNumber();

		// Check if correct start record counter
		if (!is_numeric($this->StartRecord) || $this->StartRecord == "") { // Avoid invalid start record counter
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->StartRecord > $this->TotalRecords) { // Avoid starting record > total records
			$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to last page first record
			$this->setStartRecordNumber($this->StartRecord);
		} elseif (($this->StartRecord - 1) % $this->DisplayRecords != 0) {
			$this->StartRecord = (int)(($this->StartRecord - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to page boundary
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}
} // End class
?>