<?php
namespace PHPMaker2020\project1;

/**
 * Page class
 */
class murid_add extends murid
{

	// Page ID
	public $PageID = "add";

	// Project ID
	public $ProjectID = "{6B4A168D-AFB7-4B2A-A9A9-04A7731AE34A}";

	// Table name
	public $TableName = 'murid';

	// Page object name
	public $PageObjName = "murid_add";

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = TRUE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (murid)
		if (!isset($GLOBALS["murid"]) || get_class($GLOBALS["murid"]) == PROJECT_NAMESPACE . "murid") {
			$GLOBALS["murid"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["murid"];
		}

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'add');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'murid');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $murid;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($murid);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();

			// Handle modal response
			if ($this->IsModal) { // Show as modal
				$row = ["url" => $url, "modal" => "1"];
				$pageName = GetPageName($url);
				if ($pageName != $this->getListUrl()) { // Not List page
					$row["caption"] = $this->getModalCaption($pageName);
					if ($pageName == "muridview.php")
						$row["view"] = "1";
				} else { // List page should not be shown as modal => error
					$row["error"] = $this->getFailureMessage();
					$this->clearFailureMessage();
				}
				WriteJson($row);
			} else {
				SaveDebugMessage();
				AddHeader("Location", $url);
			}
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["mimeType" => ContentType($val), "url" => $url];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$row[$fldname] = ["mimeType" => MimeContentType($val), "url" => FullUrl($fld->hrefPath() . $val)];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => FullUrl($fld->hrefPath() . $file)];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['NO_INDUK'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!$this->setupApiRequest())
			return FALSE;

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		if (!$Security->isLoggedIn()) // Logged in
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Get("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API request
	public function setupApiRequest()
	{
		global $Security;

		// Check security for API request
		If (ValidApiRequest()) {
			return TRUE;
		}
		return FALSE;
	}
	public $FormClassName = "ew-horizontal ew-form ew-add-form";
	public $IsModal = FALSE;
	public $IsMobileOrModal = FALSE;
	public $DbMasterFilter = "";
	public $DbDetailFilter = "";
	public $StartRecord;
	public $Priv = 0;
	public $OldRecordset;
	public $CopyRecord;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SkipHeaderFooter;

		// Is modal
		$this->IsModal = (Param("modal") == "1");

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (!$this->setupApiRequest()) {
			$Security = new AdvancedSecurity();
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if (!$Security->canAdd()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("muridlist.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}

		// Create form object
		$CurrentForm = new HttpForm();
		$this->CurrentAction = Param("action"); // Set up current action
		$this->NO_INDUK->setVisibility();
		$this->NAMA_MURID->setVisibility();
		$this->JEN_KEL->setVisibility();
		$this->AGAMA_MURID->setVisibility();
		$this->ALAMAT_RUMAH->setVisibility();
		$this->TEMPATLAHIR->setVisibility();
		$this->TGL_LAHIR->setVisibility();
		$this->NOHP->setVisibility();
		$this->NOWA->setVisibility();
		$this->IDTELEGRAM->setVisibility();
		$this->IDLINE->setVisibility();
		$this->IDFACEBOOK->setVisibility();
		$this->IDINSTAGRAM->setVisibility();
		$this->IDTWITTER->setVisibility();
		$this->IDYOUTUBE->setVisibility();
		$this->_EMAIL->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		// Check modal

		if ($this->IsModal)
			$SkipHeaderFooter = TRUE;
		$this->IsMobileOrModal = IsMobile() || $this->IsModal;
		$this->FormClassName = "ew-form ew-add-form ew-horizontal";
		$postBack = FALSE;

		// Set up current action
		if (IsApi()) {
			$this->CurrentAction = "insert"; // Add record directly
			$postBack = TRUE;
		} elseif (Post("action") !== NULL) {
			$this->CurrentAction = Post("action"); // Get form action
			$postBack = TRUE;
		} else { // Not post back

			// Load key values from QueryString
			$this->CopyRecord = TRUE;
			if (Get("NO_INDUK") !== NULL) {
				$this->NO_INDUK->setQueryStringValue(Get("NO_INDUK"));
				$this->setKey("NO_INDUK", $this->NO_INDUK->CurrentValue); // Set up key
			} else {
				$this->setKey("NO_INDUK", ""); // Clear key
				$this->CopyRecord = FALSE;
			}
			if ($this->CopyRecord) {
				$this->CurrentAction = "copy"; // Copy record
			} else {
				$this->CurrentAction = "show"; // Display blank record
			}
		}

		// Load old record / default values
		$loaded = $this->loadOldRecord();

		// Load form values
		if ($postBack) {
			$this->loadFormValues(); // Load form values
		}

		// Validate form if post back
		if ($postBack) {
			if (!$this->validateForm()) {
				$this->EventCancelled = TRUE; // Event cancelled
				$this->restoreFormValues(); // Restore form values
				$this->setFailureMessage($FormError);
				if (IsApi()) {
					$this->terminate();
					return;
				} else {
					$this->CurrentAction = "show"; // Form error, reset action
				}
			}
		}

		// Perform current action
		switch ($this->CurrentAction) {
			case "copy": // Copy an existing record
				if (!$loaded) { // Record not loaded
					if ($this->getFailureMessage() == "")
						$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
					$this->terminate("muridlist.php"); // No matching record, return to list
				}
				break;
			case "insert": // Add new record
				$this->SendEmail = TRUE; // Send email on add success
				if ($this->addRow($this->OldRecordset)) { // Add successful
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->phrase("AddSuccess")); // Set up success message
					$returnUrl = $this->getReturnUrl();
					if (GetPageName($returnUrl) == "muridlist.php")
						$returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
					elseif (GetPageName($returnUrl) == "muridview.php")
						$returnUrl = $this->getViewUrl(); // View page, return to View page with keyurl directly
					if (IsApi()) { // Return to caller
						$this->terminate(TRUE);
						return;
					} else {
						$this->terminate($returnUrl);
					}
				} elseif (IsApi()) { // API request, return
					$this->terminate();
					return;
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->restoreFormValues(); // Add failed, restore form values
				}
		}

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Render row based on row type
		$this->RowType = ROWTYPE_ADD; // Render add type

		// Render row
		$this->resetAttributes();
		$this->renderRow();
	}

	// Get upload files
	protected function getUploadFiles()
	{
		global $CurrentForm, $Language;
	}

	// Load default values
	protected function loadDefaultValues()
	{
		$this->NO_INDUK->CurrentValue = NULL;
		$this->NO_INDUK->OldValue = $this->NO_INDUK->CurrentValue;
		$this->NAMA_MURID->CurrentValue = NULL;
		$this->NAMA_MURID->OldValue = $this->NAMA_MURID->CurrentValue;
		$this->JEN_KEL->CurrentValue = NULL;
		$this->JEN_KEL->OldValue = $this->JEN_KEL->CurrentValue;
		$this->AGAMA_MURID->CurrentValue = NULL;
		$this->AGAMA_MURID->OldValue = $this->AGAMA_MURID->CurrentValue;
		$this->ALAMAT_RUMAH->CurrentValue = NULL;
		$this->ALAMAT_RUMAH->OldValue = $this->ALAMAT_RUMAH->CurrentValue;
		$this->TEMPATLAHIR->CurrentValue = NULL;
		$this->TEMPATLAHIR->OldValue = $this->TEMPATLAHIR->CurrentValue;
		$this->TGL_LAHIR->CurrentValue = NULL;
		$this->TGL_LAHIR->OldValue = $this->TGL_LAHIR->CurrentValue;
		$this->NOHP->CurrentValue = NULL;
		$this->NOHP->OldValue = $this->NOHP->CurrentValue;
		$this->NOWA->CurrentValue = NULL;
		$this->NOWA->OldValue = $this->NOWA->CurrentValue;
		$this->IDTELEGRAM->CurrentValue = NULL;
		$this->IDTELEGRAM->OldValue = $this->IDTELEGRAM->CurrentValue;
		$this->IDLINE->CurrentValue = NULL;
		$this->IDLINE->OldValue = $this->IDLINE->CurrentValue;
		$this->IDFACEBOOK->CurrentValue = NULL;
		$this->IDFACEBOOK->OldValue = $this->IDFACEBOOK->CurrentValue;
		$this->IDINSTAGRAM->CurrentValue = NULL;
		$this->IDINSTAGRAM->OldValue = $this->IDINSTAGRAM->CurrentValue;
		$this->IDTWITTER->CurrentValue = NULL;
		$this->IDTWITTER->OldValue = $this->IDTWITTER->CurrentValue;
		$this->IDYOUTUBE->CurrentValue = NULL;
		$this->IDYOUTUBE->OldValue = $this->IDYOUTUBE->CurrentValue;
		$this->_EMAIL->CurrentValue = NULL;
		$this->_EMAIL->OldValue = $this->_EMAIL->CurrentValue;
	}

	// Load form values
	protected function loadFormValues()
	{

		// Load from form
		global $CurrentForm;

		// Check field name 'NO_INDUK' first before field var 'x_NO_INDUK'
		$val = $CurrentForm->hasValue("NO_INDUK") ? $CurrentForm->getValue("NO_INDUK") : $CurrentForm->getValue("x_NO_INDUK");
		if (!$this->NO_INDUK->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->NO_INDUK->Visible = FALSE; // Disable update for API request
			else
				$this->NO_INDUK->setFormValue($val);
		}

		// Check field name 'NAMA_MURID' first before field var 'x_NAMA_MURID'
		$val = $CurrentForm->hasValue("NAMA_MURID") ? $CurrentForm->getValue("NAMA_MURID") : $CurrentForm->getValue("x_NAMA_MURID");
		if (!$this->NAMA_MURID->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->NAMA_MURID->Visible = FALSE; // Disable update for API request
			else
				$this->NAMA_MURID->setFormValue($val);
		}

		// Check field name 'JEN_KEL' first before field var 'x_JEN_KEL'
		$val = $CurrentForm->hasValue("JEN_KEL") ? $CurrentForm->getValue("JEN_KEL") : $CurrentForm->getValue("x_JEN_KEL");
		if (!$this->JEN_KEL->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->JEN_KEL->Visible = FALSE; // Disable update for API request
			else
				$this->JEN_KEL->setFormValue($val);
		}

		// Check field name 'AGAMA_MURID' first before field var 'x_AGAMA_MURID'
		$val = $CurrentForm->hasValue("AGAMA_MURID") ? $CurrentForm->getValue("AGAMA_MURID") : $CurrentForm->getValue("x_AGAMA_MURID");
		if (!$this->AGAMA_MURID->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->AGAMA_MURID->Visible = FALSE; // Disable update for API request
			else
				$this->AGAMA_MURID->setFormValue($val);
		}

		// Check field name 'ALAMAT_RUMAH' first before field var 'x_ALAMAT_RUMAH'
		$val = $CurrentForm->hasValue("ALAMAT_RUMAH") ? $CurrentForm->getValue("ALAMAT_RUMAH") : $CurrentForm->getValue("x_ALAMAT_RUMAH");
		if (!$this->ALAMAT_RUMAH->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->ALAMAT_RUMAH->Visible = FALSE; // Disable update for API request
			else
				$this->ALAMAT_RUMAH->setFormValue($val);
		}

		// Check field name 'TEMPATLAHIR' first before field var 'x_TEMPATLAHIR'
		$val = $CurrentForm->hasValue("TEMPATLAHIR") ? $CurrentForm->getValue("TEMPATLAHIR") : $CurrentForm->getValue("x_TEMPATLAHIR");
		if (!$this->TEMPATLAHIR->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->TEMPATLAHIR->Visible = FALSE; // Disable update for API request
			else
				$this->TEMPATLAHIR->setFormValue($val);
		}

		// Check field name 'TGL_LAHIR' first before field var 'x_TGL_LAHIR'
		$val = $CurrentForm->hasValue("TGL_LAHIR") ? $CurrentForm->getValue("TGL_LAHIR") : $CurrentForm->getValue("x_TGL_LAHIR");
		if (!$this->TGL_LAHIR->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->TGL_LAHIR->Visible = FALSE; // Disable update for API request
			else
				$this->TGL_LAHIR->setFormValue($val);
			$this->TGL_LAHIR->CurrentValue = UnFormatDateTime($this->TGL_LAHIR->CurrentValue, 0);
		}

		// Check field name 'NOHP' first before field var 'x_NOHP'
		$val = $CurrentForm->hasValue("NOHP") ? $CurrentForm->getValue("NOHP") : $CurrentForm->getValue("x_NOHP");
		if (!$this->NOHP->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->NOHP->Visible = FALSE; // Disable update for API request
			else
				$this->NOHP->setFormValue($val);
		}

		// Check field name 'NOWA' first before field var 'x_NOWA'
		$val = $CurrentForm->hasValue("NOWA") ? $CurrentForm->getValue("NOWA") : $CurrentForm->getValue("x_NOWA");
		if (!$this->NOWA->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->NOWA->Visible = FALSE; // Disable update for API request
			else
				$this->NOWA->setFormValue($val);
		}

		// Check field name 'IDTELEGRAM' first before field var 'x_IDTELEGRAM'
		$val = $CurrentForm->hasValue("IDTELEGRAM") ? $CurrentForm->getValue("IDTELEGRAM") : $CurrentForm->getValue("x_IDTELEGRAM");
		if (!$this->IDTELEGRAM->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->IDTELEGRAM->Visible = FALSE; // Disable update for API request
			else
				$this->IDTELEGRAM->setFormValue($val);
		}

		// Check field name 'IDLINE' first before field var 'x_IDLINE'
		$val = $CurrentForm->hasValue("IDLINE") ? $CurrentForm->getValue("IDLINE") : $CurrentForm->getValue("x_IDLINE");
		if (!$this->IDLINE->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->IDLINE->Visible = FALSE; // Disable update for API request
			else
				$this->IDLINE->setFormValue($val);
		}

		// Check field name 'IDFACEBOOK' first before field var 'x_IDFACEBOOK'
		$val = $CurrentForm->hasValue("IDFACEBOOK") ? $CurrentForm->getValue("IDFACEBOOK") : $CurrentForm->getValue("x_IDFACEBOOK");
		if (!$this->IDFACEBOOK->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->IDFACEBOOK->Visible = FALSE; // Disable update for API request
			else
				$this->IDFACEBOOK->setFormValue($val);
		}

		// Check field name 'IDINSTAGRAM' first before field var 'x_IDINSTAGRAM'
		$val = $CurrentForm->hasValue("IDINSTAGRAM") ? $CurrentForm->getValue("IDINSTAGRAM") : $CurrentForm->getValue("x_IDINSTAGRAM");
		if (!$this->IDINSTAGRAM->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->IDINSTAGRAM->Visible = FALSE; // Disable update for API request
			else
				$this->IDINSTAGRAM->setFormValue($val);
		}

		// Check field name 'IDTWITTER' first before field var 'x_IDTWITTER'
		$val = $CurrentForm->hasValue("IDTWITTER") ? $CurrentForm->getValue("IDTWITTER") : $CurrentForm->getValue("x_IDTWITTER");
		if (!$this->IDTWITTER->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->IDTWITTER->Visible = FALSE; // Disable update for API request
			else
				$this->IDTWITTER->setFormValue($val);
		}

		// Check field name 'IDYOUTUBE' first before field var 'x_IDYOUTUBE'
		$val = $CurrentForm->hasValue("IDYOUTUBE") ? $CurrentForm->getValue("IDYOUTUBE") : $CurrentForm->getValue("x_IDYOUTUBE");
		if (!$this->IDYOUTUBE->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->IDYOUTUBE->Visible = FALSE; // Disable update for API request
			else
				$this->IDYOUTUBE->setFormValue($val);
		}

		// Check field name 'EMAIL' first before field var 'x__EMAIL'
		$val = $CurrentForm->hasValue("EMAIL") ? $CurrentForm->getValue("EMAIL") : $CurrentForm->getValue("x__EMAIL");
		if (!$this->_EMAIL->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->_EMAIL->Visible = FALSE; // Disable update for API request
			else
				$this->_EMAIL->setFormValue($val);
		}
	}

	// Restore form values
	public function restoreFormValues()
	{
		global $CurrentForm;
		$this->NO_INDUK->CurrentValue = $this->NO_INDUK->FormValue;
		$this->NAMA_MURID->CurrentValue = $this->NAMA_MURID->FormValue;
		$this->JEN_KEL->CurrentValue = $this->JEN_KEL->FormValue;
		$this->AGAMA_MURID->CurrentValue = $this->AGAMA_MURID->FormValue;
		$this->ALAMAT_RUMAH->CurrentValue = $this->ALAMAT_RUMAH->FormValue;
		$this->TEMPATLAHIR->CurrentValue = $this->TEMPATLAHIR->FormValue;
		$this->TGL_LAHIR->CurrentValue = $this->TGL_LAHIR->FormValue;
		$this->TGL_LAHIR->CurrentValue = UnFormatDateTime($this->TGL_LAHIR->CurrentValue, 0);
		$this->NOHP->CurrentValue = $this->NOHP->FormValue;
		$this->NOWA->CurrentValue = $this->NOWA->FormValue;
		$this->IDTELEGRAM->CurrentValue = $this->IDTELEGRAM->FormValue;
		$this->IDLINE->CurrentValue = $this->IDLINE->FormValue;
		$this->IDFACEBOOK->CurrentValue = $this->IDFACEBOOK->FormValue;
		$this->IDINSTAGRAM->CurrentValue = $this->IDINSTAGRAM->FormValue;
		$this->IDTWITTER->CurrentValue = $this->IDTWITTER->FormValue;
		$this->IDYOUTUBE->CurrentValue = $this->IDYOUTUBE->FormValue;
		$this->_EMAIL->CurrentValue = $this->_EMAIL->FormValue;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->NO_INDUK->setDbValue($row['NO_INDUK']);
		$this->NAMA_MURID->setDbValue($row['NAMA_MURID']);
		$this->JEN_KEL->setDbValue($row['JEN_KEL']);
		$this->AGAMA_MURID->setDbValue($row['AGAMA_MURID']);
		$this->ALAMAT_RUMAH->setDbValue($row['ALAMAT_RUMAH']);
		$this->TEMPATLAHIR->setDbValue($row['TEMPATLAHIR']);
		$this->TGL_LAHIR->setDbValue($row['TGL_LAHIR']);
		$this->NOHP->setDbValue($row['NOHP']);
		$this->NOWA->setDbValue($row['NOWA']);
		$this->IDTELEGRAM->setDbValue($row['IDTELEGRAM']);
		$this->IDLINE->setDbValue($row['IDLINE']);
		$this->IDFACEBOOK->setDbValue($row['IDFACEBOOK']);
		$this->IDINSTAGRAM->setDbValue($row['IDINSTAGRAM']);
		$this->IDTWITTER->setDbValue($row['IDTWITTER']);
		$this->IDYOUTUBE->setDbValue($row['IDYOUTUBE']);
		$this->_EMAIL->setDbValue($row['EMAIL']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$this->loadDefaultValues();
		$row = [];
		$row['NO_INDUK'] = $this->NO_INDUK->CurrentValue;
		$row['NAMA_MURID'] = $this->NAMA_MURID->CurrentValue;
		$row['JEN_KEL'] = $this->JEN_KEL->CurrentValue;
		$row['AGAMA_MURID'] = $this->AGAMA_MURID->CurrentValue;
		$row['ALAMAT_RUMAH'] = $this->ALAMAT_RUMAH->CurrentValue;
		$row['TEMPATLAHIR'] = $this->TEMPATLAHIR->CurrentValue;
		$row['TGL_LAHIR'] = $this->TGL_LAHIR->CurrentValue;
		$row['NOHP'] = $this->NOHP->CurrentValue;
		$row['NOWA'] = $this->NOWA->CurrentValue;
		$row['IDTELEGRAM'] = $this->IDTELEGRAM->CurrentValue;
		$row['IDLINE'] = $this->IDLINE->CurrentValue;
		$row['IDFACEBOOK'] = $this->IDFACEBOOK->CurrentValue;
		$row['IDINSTAGRAM'] = $this->IDINSTAGRAM->CurrentValue;
		$row['IDTWITTER'] = $this->IDTWITTER->CurrentValue;
		$row['IDYOUTUBE'] = $this->IDYOUTUBE->CurrentValue;
		$row['EMAIL'] = $this->_EMAIL->CurrentValue;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("NO_INDUK")) != "")
			$this->NO_INDUK->OldValue = $this->getKey("NO_INDUK"); // NO_INDUK
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Call Row_Rendering event

		$this->Row_Rendering();

		// Common render codes for all row types
		// NO_INDUK
		// NAMA_MURID
		// JEN_KEL
		// AGAMA_MURID
		// ALAMAT_RUMAH
		// TEMPATLAHIR
		// TGL_LAHIR
		// NOHP
		// NOWA
		// IDTELEGRAM
		// IDLINE
		// IDFACEBOOK
		// IDINSTAGRAM
		// IDTWITTER
		// IDYOUTUBE
		// EMAIL

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// NO_INDUK
			$this->NO_INDUK->ViewValue = $this->NO_INDUK->CurrentValue;
			$this->NO_INDUK->ViewCustomAttributes = "";

			// NAMA_MURID
			$this->NAMA_MURID->ViewValue = $this->NAMA_MURID->CurrentValue;
			$this->NAMA_MURID->ViewCustomAttributes = "";

			// JEN_KEL
			$this->JEN_KEL->ViewValue = $this->JEN_KEL->CurrentValue;
			$this->JEN_KEL->ViewCustomAttributes = "";

			// AGAMA_MURID
			$this->AGAMA_MURID->ViewValue = $this->AGAMA_MURID->CurrentValue;
			$this->AGAMA_MURID->ViewCustomAttributes = "";

			// ALAMAT_RUMAH
			$this->ALAMAT_RUMAH->ViewValue = $this->ALAMAT_RUMAH->CurrentValue;
			$this->ALAMAT_RUMAH->ViewCustomAttributes = "";

			// TEMPATLAHIR
			$this->TEMPATLAHIR->ViewValue = $this->TEMPATLAHIR->CurrentValue;
			$this->TEMPATLAHIR->ViewCustomAttributes = "";

			// TGL_LAHIR
			$this->TGL_LAHIR->ViewValue = $this->TGL_LAHIR->CurrentValue;
			$this->TGL_LAHIR->ViewValue = FormatDateTime($this->TGL_LAHIR->ViewValue, 0);
			$this->TGL_LAHIR->ViewCustomAttributes = "";

			// NOHP
			$this->NOHP->ViewValue = $this->NOHP->CurrentValue;
			$this->NOHP->ViewCustomAttributes = "";

			// NOWA
			$this->NOWA->ViewValue = $this->NOWA->CurrentValue;
			$this->NOWA->ViewCustomAttributes = "";

			// IDTELEGRAM
			$this->IDTELEGRAM->ViewValue = $this->IDTELEGRAM->CurrentValue;
			$this->IDTELEGRAM->ViewCustomAttributes = "";

			// IDLINE
			$this->IDLINE->ViewValue = $this->IDLINE->CurrentValue;
			$this->IDLINE->ViewCustomAttributes = "";

			// IDFACEBOOK
			$this->IDFACEBOOK->ViewValue = $this->IDFACEBOOK->CurrentValue;
			$this->IDFACEBOOK->ViewCustomAttributes = "";

			// IDINSTAGRAM
			$this->IDINSTAGRAM->ViewValue = $this->IDINSTAGRAM->CurrentValue;
			$this->IDINSTAGRAM->ViewCustomAttributes = "";

			// IDTWITTER
			$this->IDTWITTER->ViewValue = $this->IDTWITTER->CurrentValue;
			$this->IDTWITTER->ViewCustomAttributes = "";

			// IDYOUTUBE
			$this->IDYOUTUBE->ViewValue = $this->IDYOUTUBE->CurrentValue;
			$this->IDYOUTUBE->ViewCustomAttributes = "";

			// EMAIL
			$this->_EMAIL->ViewValue = $this->_EMAIL->CurrentValue;
			$this->_EMAIL->ViewCustomAttributes = "";

			// NO_INDUK
			$this->NO_INDUK->LinkCustomAttributes = "";
			$this->NO_INDUK->HrefValue = "";
			$this->NO_INDUK->TooltipValue = "";

			// NAMA_MURID
			$this->NAMA_MURID->LinkCustomAttributes = "";
			$this->NAMA_MURID->HrefValue = "";
			$this->NAMA_MURID->TooltipValue = "";

			// JEN_KEL
			$this->JEN_KEL->LinkCustomAttributes = "";
			$this->JEN_KEL->HrefValue = "";
			$this->JEN_KEL->TooltipValue = "";

			// AGAMA_MURID
			$this->AGAMA_MURID->LinkCustomAttributes = "";
			$this->AGAMA_MURID->HrefValue = "";
			$this->AGAMA_MURID->TooltipValue = "";

			// ALAMAT_RUMAH
			$this->ALAMAT_RUMAH->LinkCustomAttributes = "";
			$this->ALAMAT_RUMAH->HrefValue = "";
			$this->ALAMAT_RUMAH->TooltipValue = "";

			// TEMPATLAHIR
			$this->TEMPATLAHIR->LinkCustomAttributes = "";
			$this->TEMPATLAHIR->HrefValue = "";
			$this->TEMPATLAHIR->TooltipValue = "";

			// TGL_LAHIR
			$this->TGL_LAHIR->LinkCustomAttributes = "";
			$this->TGL_LAHIR->HrefValue = "";
			$this->TGL_LAHIR->TooltipValue = "";

			// NOHP
			$this->NOHP->LinkCustomAttributes = "";
			$this->NOHP->HrefValue = "";
			$this->NOHP->TooltipValue = "";

			// NOWA
			$this->NOWA->LinkCustomAttributes = "";
			$this->NOWA->HrefValue = "";
			$this->NOWA->TooltipValue = "";

			// IDTELEGRAM
			$this->IDTELEGRAM->LinkCustomAttributes = "";
			$this->IDTELEGRAM->HrefValue = "";
			$this->IDTELEGRAM->TooltipValue = "";

			// IDLINE
			$this->IDLINE->LinkCustomAttributes = "";
			$this->IDLINE->HrefValue = "";
			$this->IDLINE->TooltipValue = "";

			// IDFACEBOOK
			$this->IDFACEBOOK->LinkCustomAttributes = "";
			$this->IDFACEBOOK->HrefValue = "";
			$this->IDFACEBOOK->TooltipValue = "";

			// IDINSTAGRAM
			$this->IDINSTAGRAM->LinkCustomAttributes = "";
			$this->IDINSTAGRAM->HrefValue = "";
			$this->IDINSTAGRAM->TooltipValue = "";

			// IDTWITTER
			$this->IDTWITTER->LinkCustomAttributes = "";
			$this->IDTWITTER->HrefValue = "";
			$this->IDTWITTER->TooltipValue = "";

			// IDYOUTUBE
			$this->IDYOUTUBE->LinkCustomAttributes = "";
			$this->IDYOUTUBE->HrefValue = "";
			$this->IDYOUTUBE->TooltipValue = "";

			// EMAIL
			$this->_EMAIL->LinkCustomAttributes = "";
			$this->_EMAIL->HrefValue = "";
			$this->_EMAIL->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_ADD) { // Add row

			// NO_INDUK
			$this->NO_INDUK->EditAttrs["class"] = "form-control";
			$this->NO_INDUK->EditCustomAttributes = "";
			if (!$this->NO_INDUK->Raw)
				$this->NO_INDUK->CurrentValue = HtmlDecode($this->NO_INDUK->CurrentValue);
			$this->NO_INDUK->EditValue = HtmlEncode($this->NO_INDUK->CurrentValue);
			$this->NO_INDUK->PlaceHolder = RemoveHtml($this->NO_INDUK->caption());

			// NAMA_MURID
			$this->NAMA_MURID->EditAttrs["class"] = "form-control";
			$this->NAMA_MURID->EditCustomAttributes = "";
			if (!$this->NAMA_MURID->Raw)
				$this->NAMA_MURID->CurrentValue = HtmlDecode($this->NAMA_MURID->CurrentValue);
			$this->NAMA_MURID->EditValue = HtmlEncode($this->NAMA_MURID->CurrentValue);
			$this->NAMA_MURID->PlaceHolder = RemoveHtml($this->NAMA_MURID->caption());

			// JEN_KEL
			$this->JEN_KEL->EditAttrs["class"] = "form-control";
			$this->JEN_KEL->EditCustomAttributes = "";
			if (!$this->JEN_KEL->Raw)
				$this->JEN_KEL->CurrentValue = HtmlDecode($this->JEN_KEL->CurrentValue);
			$this->JEN_KEL->EditValue = HtmlEncode($this->JEN_KEL->CurrentValue);
			$this->JEN_KEL->PlaceHolder = RemoveHtml($this->JEN_KEL->caption());

			// AGAMA_MURID
			$this->AGAMA_MURID->EditAttrs["class"] = "form-control";
			$this->AGAMA_MURID->EditCustomAttributes = "";
			if (!$this->AGAMA_MURID->Raw)
				$this->AGAMA_MURID->CurrentValue = HtmlDecode($this->AGAMA_MURID->CurrentValue);
			$this->AGAMA_MURID->EditValue = HtmlEncode($this->AGAMA_MURID->CurrentValue);
			$this->AGAMA_MURID->PlaceHolder = RemoveHtml($this->AGAMA_MURID->caption());

			// ALAMAT_RUMAH
			$this->ALAMAT_RUMAH->EditAttrs["class"] = "form-control";
			$this->ALAMAT_RUMAH->EditCustomAttributes = "";
			if (!$this->ALAMAT_RUMAH->Raw)
				$this->ALAMAT_RUMAH->CurrentValue = HtmlDecode($this->ALAMAT_RUMAH->CurrentValue);
			$this->ALAMAT_RUMAH->EditValue = HtmlEncode($this->ALAMAT_RUMAH->CurrentValue);
			$this->ALAMAT_RUMAH->PlaceHolder = RemoveHtml($this->ALAMAT_RUMAH->caption());

			// TEMPATLAHIR
			$this->TEMPATLAHIR->EditAttrs["class"] = "form-control";
			$this->TEMPATLAHIR->EditCustomAttributes = "";
			if (!$this->TEMPATLAHIR->Raw)
				$this->TEMPATLAHIR->CurrentValue = HtmlDecode($this->TEMPATLAHIR->CurrentValue);
			$this->TEMPATLAHIR->EditValue = HtmlEncode($this->TEMPATLAHIR->CurrentValue);
			$this->TEMPATLAHIR->PlaceHolder = RemoveHtml($this->TEMPATLAHIR->caption());

			// TGL_LAHIR
			$this->TGL_LAHIR->EditAttrs["class"] = "form-control";
			$this->TGL_LAHIR->EditCustomAttributes = "";
			$this->TGL_LAHIR->EditValue = HtmlEncode(FormatDateTime($this->TGL_LAHIR->CurrentValue, 8));
			$this->TGL_LAHIR->PlaceHolder = RemoveHtml($this->TGL_LAHIR->caption());

			// NOHP
			$this->NOHP->EditAttrs["class"] = "form-control";
			$this->NOHP->EditCustomAttributes = "";
			if (!$this->NOHP->Raw)
				$this->NOHP->CurrentValue = HtmlDecode($this->NOHP->CurrentValue);
			$this->NOHP->EditValue = HtmlEncode($this->NOHP->CurrentValue);
			$this->NOHP->PlaceHolder = RemoveHtml($this->NOHP->caption());

			// NOWA
			$this->NOWA->EditAttrs["class"] = "form-control";
			$this->NOWA->EditCustomAttributes = "";
			if (!$this->NOWA->Raw)
				$this->NOWA->CurrentValue = HtmlDecode($this->NOWA->CurrentValue);
			$this->NOWA->EditValue = HtmlEncode($this->NOWA->CurrentValue);
			$this->NOWA->PlaceHolder = RemoveHtml($this->NOWA->caption());

			// IDTELEGRAM
			$this->IDTELEGRAM->EditAttrs["class"] = "form-control";
			$this->IDTELEGRAM->EditCustomAttributes = "";
			if (!$this->IDTELEGRAM->Raw)
				$this->IDTELEGRAM->CurrentValue = HtmlDecode($this->IDTELEGRAM->CurrentValue);
			$this->IDTELEGRAM->EditValue = HtmlEncode($this->IDTELEGRAM->CurrentValue);
			$this->IDTELEGRAM->PlaceHolder = RemoveHtml($this->IDTELEGRAM->caption());

			// IDLINE
			$this->IDLINE->EditAttrs["class"] = "form-control";
			$this->IDLINE->EditCustomAttributes = "";
			if (!$this->IDLINE->Raw)
				$this->IDLINE->CurrentValue = HtmlDecode($this->IDLINE->CurrentValue);
			$this->IDLINE->EditValue = HtmlEncode($this->IDLINE->CurrentValue);
			$this->IDLINE->PlaceHolder = RemoveHtml($this->IDLINE->caption());

			// IDFACEBOOK
			$this->IDFACEBOOK->EditAttrs["class"] = "form-control";
			$this->IDFACEBOOK->EditCustomAttributes = "";
			if (!$this->IDFACEBOOK->Raw)
				$this->IDFACEBOOK->CurrentValue = HtmlDecode($this->IDFACEBOOK->CurrentValue);
			$this->IDFACEBOOK->EditValue = HtmlEncode($this->IDFACEBOOK->CurrentValue);
			$this->IDFACEBOOK->PlaceHolder = RemoveHtml($this->IDFACEBOOK->caption());

			// IDINSTAGRAM
			$this->IDINSTAGRAM->EditAttrs["class"] = "form-control";
			$this->IDINSTAGRAM->EditCustomAttributes = "";
			if (!$this->IDINSTAGRAM->Raw)
				$this->IDINSTAGRAM->CurrentValue = HtmlDecode($this->IDINSTAGRAM->CurrentValue);
			$this->IDINSTAGRAM->EditValue = HtmlEncode($this->IDINSTAGRAM->CurrentValue);
			$this->IDINSTAGRAM->PlaceHolder = RemoveHtml($this->IDINSTAGRAM->caption());

			// IDTWITTER
			$this->IDTWITTER->EditAttrs["class"] = "form-control";
			$this->IDTWITTER->EditCustomAttributes = "";
			if (!$this->IDTWITTER->Raw)
				$this->IDTWITTER->CurrentValue = HtmlDecode($this->IDTWITTER->CurrentValue);
			$this->IDTWITTER->EditValue = HtmlEncode($this->IDTWITTER->CurrentValue);
			$this->IDTWITTER->PlaceHolder = RemoveHtml($this->IDTWITTER->caption());

			// IDYOUTUBE
			$this->IDYOUTUBE->EditAttrs["class"] = "form-control";
			$this->IDYOUTUBE->EditCustomAttributes = "";
			if (!$this->IDYOUTUBE->Raw)
				$this->IDYOUTUBE->CurrentValue = HtmlDecode($this->IDYOUTUBE->CurrentValue);
			$this->IDYOUTUBE->EditValue = HtmlEncode($this->IDYOUTUBE->CurrentValue);
			$this->IDYOUTUBE->PlaceHolder = RemoveHtml($this->IDYOUTUBE->caption());

			// EMAIL
			$this->_EMAIL->EditAttrs["class"] = "form-control";
			$this->_EMAIL->EditCustomAttributes = "";
			if (!$this->_EMAIL->Raw)
				$this->_EMAIL->CurrentValue = HtmlDecode($this->_EMAIL->CurrentValue);
			$this->_EMAIL->EditValue = HtmlEncode($this->_EMAIL->CurrentValue);
			$this->_EMAIL->PlaceHolder = RemoveHtml($this->_EMAIL->caption());

			// Add refer script
			// NO_INDUK

			$this->NO_INDUK->LinkCustomAttributes = "";
			$this->NO_INDUK->HrefValue = "";

			// NAMA_MURID
			$this->NAMA_MURID->LinkCustomAttributes = "";
			$this->NAMA_MURID->HrefValue = "";

			// JEN_KEL
			$this->JEN_KEL->LinkCustomAttributes = "";
			$this->JEN_KEL->HrefValue = "";

			// AGAMA_MURID
			$this->AGAMA_MURID->LinkCustomAttributes = "";
			$this->AGAMA_MURID->HrefValue = "";

			// ALAMAT_RUMAH
			$this->ALAMAT_RUMAH->LinkCustomAttributes = "";
			$this->ALAMAT_RUMAH->HrefValue = "";

			// TEMPATLAHIR
			$this->TEMPATLAHIR->LinkCustomAttributes = "";
			$this->TEMPATLAHIR->HrefValue = "";

			// TGL_LAHIR
			$this->TGL_LAHIR->LinkCustomAttributes = "";
			$this->TGL_LAHIR->HrefValue = "";

			// NOHP
			$this->NOHP->LinkCustomAttributes = "";
			$this->NOHP->HrefValue = "";

			// NOWA
			$this->NOWA->LinkCustomAttributes = "";
			$this->NOWA->HrefValue = "";

			// IDTELEGRAM
			$this->IDTELEGRAM->LinkCustomAttributes = "";
			$this->IDTELEGRAM->HrefValue = "";

			// IDLINE
			$this->IDLINE->LinkCustomAttributes = "";
			$this->IDLINE->HrefValue = "";

			// IDFACEBOOK
			$this->IDFACEBOOK->LinkCustomAttributes = "";
			$this->IDFACEBOOK->HrefValue = "";

			// IDINSTAGRAM
			$this->IDINSTAGRAM->LinkCustomAttributes = "";
			$this->IDINSTAGRAM->HrefValue = "";

			// IDTWITTER
			$this->IDTWITTER->LinkCustomAttributes = "";
			$this->IDTWITTER->HrefValue = "";

			// IDYOUTUBE
			$this->IDYOUTUBE->LinkCustomAttributes = "";
			$this->IDYOUTUBE->HrefValue = "";

			// EMAIL
			$this->_EMAIL->LinkCustomAttributes = "";
			$this->_EMAIL->HrefValue = "";
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	protected function validateForm()
	{
		global $Language, $FormError;

		// Initialize form error message
		$FormError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return ($FormError == "");
		if ($this->NO_INDUK->Required) {
			if (!$this->NO_INDUK->IsDetailKey && $this->NO_INDUK->FormValue != NULL && $this->NO_INDUK->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->NO_INDUK->caption(), $this->NO_INDUK->RequiredErrorMessage));
			}
		}
		if ($this->NAMA_MURID->Required) {
			if (!$this->NAMA_MURID->IsDetailKey && $this->NAMA_MURID->FormValue != NULL && $this->NAMA_MURID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->NAMA_MURID->caption(), $this->NAMA_MURID->RequiredErrorMessage));
			}
		}
		if ($this->JEN_KEL->Required) {
			if (!$this->JEN_KEL->IsDetailKey && $this->JEN_KEL->FormValue != NULL && $this->JEN_KEL->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->JEN_KEL->caption(), $this->JEN_KEL->RequiredErrorMessage));
			}
		}
		if ($this->AGAMA_MURID->Required) {
			if (!$this->AGAMA_MURID->IsDetailKey && $this->AGAMA_MURID->FormValue != NULL && $this->AGAMA_MURID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->AGAMA_MURID->caption(), $this->AGAMA_MURID->RequiredErrorMessage));
			}
		}
		if ($this->ALAMAT_RUMAH->Required) {
			if (!$this->ALAMAT_RUMAH->IsDetailKey && $this->ALAMAT_RUMAH->FormValue != NULL && $this->ALAMAT_RUMAH->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ALAMAT_RUMAH->caption(), $this->ALAMAT_RUMAH->RequiredErrorMessage));
			}
		}
		if ($this->TEMPATLAHIR->Required) {
			if (!$this->TEMPATLAHIR->IsDetailKey && $this->TEMPATLAHIR->FormValue != NULL && $this->TEMPATLAHIR->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->TEMPATLAHIR->caption(), $this->TEMPATLAHIR->RequiredErrorMessage));
			}
		}
		if ($this->TGL_LAHIR->Required) {
			if (!$this->TGL_LAHIR->IsDetailKey && $this->TGL_LAHIR->FormValue != NULL && $this->TGL_LAHIR->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->TGL_LAHIR->caption(), $this->TGL_LAHIR->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->TGL_LAHIR->FormValue)) {
			AddMessage($FormError, $this->TGL_LAHIR->errorMessage());
		}
		if ($this->NOHP->Required) {
			if (!$this->NOHP->IsDetailKey && $this->NOHP->FormValue != NULL && $this->NOHP->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->NOHP->caption(), $this->NOHP->RequiredErrorMessage));
			}
		}
		if ($this->NOWA->Required) {
			if (!$this->NOWA->IsDetailKey && $this->NOWA->FormValue != NULL && $this->NOWA->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->NOWA->caption(), $this->NOWA->RequiredErrorMessage));
			}
		}
		if ($this->IDTELEGRAM->Required) {
			if (!$this->IDTELEGRAM->IsDetailKey && $this->IDTELEGRAM->FormValue != NULL && $this->IDTELEGRAM->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->IDTELEGRAM->caption(), $this->IDTELEGRAM->RequiredErrorMessage));
			}
		}
		if ($this->IDLINE->Required) {
			if (!$this->IDLINE->IsDetailKey && $this->IDLINE->FormValue != NULL && $this->IDLINE->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->IDLINE->caption(), $this->IDLINE->RequiredErrorMessage));
			}
		}
		if ($this->IDFACEBOOK->Required) {
			if (!$this->IDFACEBOOK->IsDetailKey && $this->IDFACEBOOK->FormValue != NULL && $this->IDFACEBOOK->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->IDFACEBOOK->caption(), $this->IDFACEBOOK->RequiredErrorMessage));
			}
		}
		if ($this->IDINSTAGRAM->Required) {
			if (!$this->IDINSTAGRAM->IsDetailKey && $this->IDINSTAGRAM->FormValue != NULL && $this->IDINSTAGRAM->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->IDINSTAGRAM->caption(), $this->IDINSTAGRAM->RequiredErrorMessage));
			}
		}
		if ($this->IDTWITTER->Required) {
			if (!$this->IDTWITTER->IsDetailKey && $this->IDTWITTER->FormValue != NULL && $this->IDTWITTER->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->IDTWITTER->caption(), $this->IDTWITTER->RequiredErrorMessage));
			}
		}
		if ($this->IDYOUTUBE->Required) {
			if (!$this->IDYOUTUBE->IsDetailKey && $this->IDYOUTUBE->FormValue != NULL && $this->IDYOUTUBE->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->IDYOUTUBE->caption(), $this->IDYOUTUBE->RequiredErrorMessage));
			}
		}
		if ($this->_EMAIL->Required) {
			if (!$this->_EMAIL->IsDetailKey && $this->_EMAIL->FormValue != NULL && $this->_EMAIL->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->_EMAIL->caption(), $this->_EMAIL->RequiredErrorMessage));
			}
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($FormError, $formCustomError);
		}
		return $validateForm;
	}

	// Add record
	protected function addRow($rsold = NULL)
	{
		global $Language, $Security;
		$conn = $this->getConnection();

		// Load db values from rsold
		$this->loadDbValues($rsold);
		if ($rsold) {
		}
		$rsnew = [];

		// NO_INDUK
		$this->NO_INDUK->setDbValueDef($rsnew, $this->NO_INDUK->CurrentValue, "", FALSE);

		// NAMA_MURID
		$this->NAMA_MURID->setDbValueDef($rsnew, $this->NAMA_MURID->CurrentValue, "", FALSE);

		// JEN_KEL
		$this->JEN_KEL->setDbValueDef($rsnew, $this->JEN_KEL->CurrentValue, NULL, FALSE);

		// AGAMA_MURID
		$this->AGAMA_MURID->setDbValueDef($rsnew, $this->AGAMA_MURID->CurrentValue, NULL, FALSE);

		// ALAMAT_RUMAH
		$this->ALAMAT_RUMAH->setDbValueDef($rsnew, $this->ALAMAT_RUMAH->CurrentValue, NULL, FALSE);

		// TEMPATLAHIR
		$this->TEMPATLAHIR->setDbValueDef($rsnew, $this->TEMPATLAHIR->CurrentValue, NULL, FALSE);

		// TGL_LAHIR
		$this->TGL_LAHIR->setDbValueDef($rsnew, UnFormatDateTime($this->TGL_LAHIR->CurrentValue, 0), NULL, FALSE);

		// NOHP
		$this->NOHP->setDbValueDef($rsnew, $this->NOHP->CurrentValue, NULL, FALSE);

		// NOWA
		$this->NOWA->setDbValueDef($rsnew, $this->NOWA->CurrentValue, NULL, FALSE);

		// IDTELEGRAM
		$this->IDTELEGRAM->setDbValueDef($rsnew, $this->IDTELEGRAM->CurrentValue, NULL, FALSE);

		// IDLINE
		$this->IDLINE->setDbValueDef($rsnew, $this->IDLINE->CurrentValue, NULL, FALSE);

		// IDFACEBOOK
		$this->IDFACEBOOK->setDbValueDef($rsnew, $this->IDFACEBOOK->CurrentValue, NULL, FALSE);

		// IDINSTAGRAM
		$this->IDINSTAGRAM->setDbValueDef($rsnew, $this->IDINSTAGRAM->CurrentValue, NULL, FALSE);

		// IDTWITTER
		$this->IDTWITTER->setDbValueDef($rsnew, $this->IDTWITTER->CurrentValue, NULL, FALSE);

		// IDYOUTUBE
		$this->IDYOUTUBE->setDbValueDef($rsnew, $this->IDYOUTUBE->CurrentValue, NULL, FALSE);

		// EMAIL
		$this->_EMAIL->setDbValueDef($rsnew, $this->_EMAIL->CurrentValue, NULL, FALSE);

		// Call Row Inserting event
		$rs = ($rsold) ? $rsold->fields : NULL;
		$insertRow = $this->Row_Inserting($rs, $rsnew);

		// Check if key value entered
		if ($insertRow && $this->ValidateKey && strval($rsnew['NO_INDUK']) == "") {
			$this->setFailureMessage($Language->phrase("InvalidKeyValue"));
			$insertRow = FALSE;
		}

		// Check for duplicate key
		if ($insertRow && $this->ValidateKey) {
			$filter = $this->getRecordFilter($rsnew);
			$rsChk = $this->loadRs($filter);
			if ($rsChk && !$rsChk->EOF) {
				$keyErrMsg = str_replace("%f", $filter, $Language->phrase("DupKey"));
				$this->setFailureMessage($keyErrMsg);
				$rsChk->close();
				$insertRow = FALSE;
			}
		}
		if ($insertRow) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			$addRow = $this->insert($rsnew);
			$conn->raiseErrorFn = "";
			if ($addRow) {
			}
		} else {
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("InsertCancelled"));
			}
			$addRow = FALSE;
		}
		if ($addRow) {

			// Call Row Inserted event
			$rs = ($rsold) ? $rsold->fields : NULL;
			$this->Row_Inserted($rs, $rsnew);
		}

		// Clean upload path if any
		if ($addRow) {
		}

		// Write JSON for API request
		if (IsApi() && $addRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $addRow;
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("muridlist.php"), "", $this->TableVar, TRUE);
		$pageId = ($this->isCopy()) ? "Copy" : "Add";
		$Breadcrumb->add("add", $pageId, $url);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}
} // End class
?>