<?php
namespace PHPMaker2020\project1;

/**
 * Page class
 */
class guru_pengajar_add extends guru_pengajar
{

	// Page ID
	public $PageID = "add";

	// Project ID
	public $ProjectID = "{6B4A168D-AFB7-4B2A-A9A9-04A7731AE34A}";

	// Table name
	public $TableName = 'guru_pengajar';

	// Page object name
	public $PageObjName = "guru_pengajar_add";

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = TRUE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (guru_pengajar)
		if (!isset($GLOBALS["guru_pengajar"]) || get_class($GLOBALS["guru_pengajar"]) == PROJECT_NAMESPACE . "guru_pengajar") {
			$GLOBALS["guru_pengajar"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["guru_pengajar"];
		}

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'add');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'guru_pengajar');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $guru_pengajar;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($guru_pengajar);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();

			// Handle modal response
			if ($this->IsModal) { // Show as modal
				$row = ["url" => $url, "modal" => "1"];
				$pageName = GetPageName($url);
				if ($pageName != $this->getListUrl()) { // Not List page
					$row["caption"] = $this->getModalCaption($pageName);
					if ($pageName == "guru_pengajarview.php")
						$row["view"] = "1";
				} else { // List page should not be shown as modal => error
					$row["error"] = $this->getFailureMessage();
					$this->clearFailureMessage();
				}
				WriteJson($row);
			} else {
				SaveDebugMessage();
				AddHeader("Location", $url);
			}
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["mimeType" => ContentType($val), "url" => $url];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$row[$fldname] = ["mimeType" => MimeContentType($val), "url" => FullUrl($fld->hrefPath() . $val)];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => FullUrl($fld->hrefPath() . $file)];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['ID_GURU'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!$this->setupApiRequest())
			return FALSE;

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		if (!$Security->isLoggedIn()) // Logged in
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Get("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API request
	public function setupApiRequest()
	{
		global $Security;

		// Check security for API request
		If (ValidApiRequest()) {
			return TRUE;
		}
		return FALSE;
	}
	public $FormClassName = "ew-horizontal ew-form ew-add-form";
	public $IsModal = FALSE;
	public $IsMobileOrModal = FALSE;
	public $DbMasterFilter = "";
	public $DbDetailFilter = "";
	public $StartRecord;
	public $Priv = 0;
	public $OldRecordset;
	public $CopyRecord;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SkipHeaderFooter;

		// Is modal
		$this->IsModal = (Param("modal") == "1");

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (!$this->setupApiRequest()) {
			$Security = new AdvancedSecurity();
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if (!$Security->canAdd()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("guru_pengajarlist.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}

		// Create form object
		$CurrentForm = new HttpForm();
		$this->CurrentAction = Param("action"); // Set up current action
		$this->ID_GURU->setVisibility();
		$this->NAMA_GURU->setVisibility();
		$this->GELAR_DEPAN->setVisibility();
		$this->GELAR_BELAKANG->setVisibility();
		$this->JENIS_KELAMIN->setVisibility();
		$this->AGAMA->setVisibility();
		$this->ALAMAT_TINGGAL->setVisibility();
		$this->NO_HP->setVisibility();
		$this->NO_WA->setVisibility();
		$this->ID_TELEGRAM->setVisibility();
		$this->ID_LINE->setVisibility();
		$this->ID_FACEBOOK->setVisibility();
		$this->ID_INSTAGRAM->setVisibility();
		$this->ID_TWITTER->setVisibility();
		$this->ID_YOUTUBE->setVisibility();
		$this->EMAIL_GURU->setVisibility();
		$this->TEMPAT_LAHIR->setVisibility();
		$this->TANGGAL_LAHIR->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		// Check modal

		if ($this->IsModal)
			$SkipHeaderFooter = TRUE;
		$this->IsMobileOrModal = IsMobile() || $this->IsModal;
		$this->FormClassName = "ew-form ew-add-form ew-horizontal";
		$postBack = FALSE;

		// Set up current action
		if (IsApi()) {
			$this->CurrentAction = "insert"; // Add record directly
			$postBack = TRUE;
		} elseif (Post("action") !== NULL) {
			$this->CurrentAction = Post("action"); // Get form action
			$postBack = TRUE;
		} else { // Not post back

			// Load key values from QueryString
			$this->CopyRecord = TRUE;
			if (Get("ID_GURU") !== NULL) {
				$this->ID_GURU->setQueryStringValue(Get("ID_GURU"));
				$this->setKey("ID_GURU", $this->ID_GURU->CurrentValue); // Set up key
			} else {
				$this->setKey("ID_GURU", ""); // Clear key
				$this->CopyRecord = FALSE;
			}
			if ($this->CopyRecord) {
				$this->CurrentAction = "copy"; // Copy record
			} else {
				$this->CurrentAction = "show"; // Display blank record
			}
		}

		// Load old record / default values
		$loaded = $this->loadOldRecord();

		// Load form values
		if ($postBack) {
			$this->loadFormValues(); // Load form values
		}

		// Validate form if post back
		if ($postBack) {
			if (!$this->validateForm()) {
				$this->EventCancelled = TRUE; // Event cancelled
				$this->restoreFormValues(); // Restore form values
				$this->setFailureMessage($FormError);
				if (IsApi()) {
					$this->terminate();
					return;
				} else {
					$this->CurrentAction = "show"; // Form error, reset action
				}
			}
		}

		// Perform current action
		switch ($this->CurrentAction) {
			case "copy": // Copy an existing record
				if (!$loaded) { // Record not loaded
					if ($this->getFailureMessage() == "")
						$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
					$this->terminate("guru_pengajarlist.php"); // No matching record, return to list
				}
				break;
			case "insert": // Add new record
				$this->SendEmail = TRUE; // Send email on add success
				if ($this->addRow($this->OldRecordset)) { // Add successful
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->phrase("AddSuccess")); // Set up success message
					$returnUrl = $this->getReturnUrl();
					if (GetPageName($returnUrl) == "guru_pengajarlist.php")
						$returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
					elseif (GetPageName($returnUrl) == "guru_pengajarview.php")
						$returnUrl = $this->getViewUrl(); // View page, return to View page with keyurl directly
					if (IsApi()) { // Return to caller
						$this->terminate(TRUE);
						return;
					} else {
						$this->terminate($returnUrl);
					}
				} elseif (IsApi()) { // API request, return
					$this->terminate();
					return;
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->restoreFormValues(); // Add failed, restore form values
				}
		}

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Render row based on row type
		$this->RowType = ROWTYPE_ADD; // Render add type

		// Render row
		$this->resetAttributes();
		$this->renderRow();
	}

	// Get upload files
	protected function getUploadFiles()
	{
		global $CurrentForm, $Language;
	}

	// Load default values
	protected function loadDefaultValues()
	{
		$this->ID_GURU->CurrentValue = NULL;
		$this->ID_GURU->OldValue = $this->ID_GURU->CurrentValue;
		$this->NAMA_GURU->CurrentValue = NULL;
		$this->NAMA_GURU->OldValue = $this->NAMA_GURU->CurrentValue;
		$this->GELAR_DEPAN->CurrentValue = NULL;
		$this->GELAR_DEPAN->OldValue = $this->GELAR_DEPAN->CurrentValue;
		$this->GELAR_BELAKANG->CurrentValue = NULL;
		$this->GELAR_BELAKANG->OldValue = $this->GELAR_BELAKANG->CurrentValue;
		$this->JENIS_KELAMIN->CurrentValue = NULL;
		$this->JENIS_KELAMIN->OldValue = $this->JENIS_KELAMIN->CurrentValue;
		$this->AGAMA->CurrentValue = NULL;
		$this->AGAMA->OldValue = $this->AGAMA->CurrentValue;
		$this->ALAMAT_TINGGAL->CurrentValue = NULL;
		$this->ALAMAT_TINGGAL->OldValue = $this->ALAMAT_TINGGAL->CurrentValue;
		$this->NO_HP->CurrentValue = NULL;
		$this->NO_HP->OldValue = $this->NO_HP->CurrentValue;
		$this->NO_WA->CurrentValue = NULL;
		$this->NO_WA->OldValue = $this->NO_WA->CurrentValue;
		$this->ID_TELEGRAM->CurrentValue = NULL;
		$this->ID_TELEGRAM->OldValue = $this->ID_TELEGRAM->CurrentValue;
		$this->ID_LINE->CurrentValue = NULL;
		$this->ID_LINE->OldValue = $this->ID_LINE->CurrentValue;
		$this->ID_FACEBOOK->CurrentValue = NULL;
		$this->ID_FACEBOOK->OldValue = $this->ID_FACEBOOK->CurrentValue;
		$this->ID_INSTAGRAM->CurrentValue = NULL;
		$this->ID_INSTAGRAM->OldValue = $this->ID_INSTAGRAM->CurrentValue;
		$this->ID_TWITTER->CurrentValue = NULL;
		$this->ID_TWITTER->OldValue = $this->ID_TWITTER->CurrentValue;
		$this->ID_YOUTUBE->CurrentValue = NULL;
		$this->ID_YOUTUBE->OldValue = $this->ID_YOUTUBE->CurrentValue;
		$this->EMAIL_GURU->CurrentValue = NULL;
		$this->EMAIL_GURU->OldValue = $this->EMAIL_GURU->CurrentValue;
		$this->TEMPAT_LAHIR->CurrentValue = NULL;
		$this->TEMPAT_LAHIR->OldValue = $this->TEMPAT_LAHIR->CurrentValue;
		$this->TANGGAL_LAHIR->CurrentValue = NULL;
		$this->TANGGAL_LAHIR->OldValue = $this->TANGGAL_LAHIR->CurrentValue;
	}

	// Load form values
	protected function loadFormValues()
	{

		// Load from form
		global $CurrentForm;

		// Check field name 'ID_GURU' first before field var 'x_ID_GURU'
		$val = $CurrentForm->hasValue("ID_GURU") ? $CurrentForm->getValue("ID_GURU") : $CurrentForm->getValue("x_ID_GURU");
		if (!$this->ID_GURU->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->ID_GURU->Visible = FALSE; // Disable update for API request
			else
				$this->ID_GURU->setFormValue($val);
		}

		// Check field name 'NAMA_GURU' first before field var 'x_NAMA_GURU'
		$val = $CurrentForm->hasValue("NAMA_GURU") ? $CurrentForm->getValue("NAMA_GURU") : $CurrentForm->getValue("x_NAMA_GURU");
		if (!$this->NAMA_GURU->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->NAMA_GURU->Visible = FALSE; // Disable update for API request
			else
				$this->NAMA_GURU->setFormValue($val);
		}

		// Check field name 'GELAR_DEPAN' first before field var 'x_GELAR_DEPAN'
		$val = $CurrentForm->hasValue("GELAR_DEPAN") ? $CurrentForm->getValue("GELAR_DEPAN") : $CurrentForm->getValue("x_GELAR_DEPAN");
		if (!$this->GELAR_DEPAN->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->GELAR_DEPAN->Visible = FALSE; // Disable update for API request
			else
				$this->GELAR_DEPAN->setFormValue($val);
		}

		// Check field name 'GELAR_BELAKANG' first before field var 'x_GELAR_BELAKANG'
		$val = $CurrentForm->hasValue("GELAR_BELAKANG") ? $CurrentForm->getValue("GELAR_BELAKANG") : $CurrentForm->getValue("x_GELAR_BELAKANG");
		if (!$this->GELAR_BELAKANG->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->GELAR_BELAKANG->Visible = FALSE; // Disable update for API request
			else
				$this->GELAR_BELAKANG->setFormValue($val);
		}

		// Check field name 'JENIS_KELAMIN' first before field var 'x_JENIS_KELAMIN'
		$val = $CurrentForm->hasValue("JENIS_KELAMIN") ? $CurrentForm->getValue("JENIS_KELAMIN") : $CurrentForm->getValue("x_JENIS_KELAMIN");
		if (!$this->JENIS_KELAMIN->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->JENIS_KELAMIN->Visible = FALSE; // Disable update for API request
			else
				$this->JENIS_KELAMIN->setFormValue($val);
		}

		// Check field name 'AGAMA' first before field var 'x_AGAMA'
		$val = $CurrentForm->hasValue("AGAMA") ? $CurrentForm->getValue("AGAMA") : $CurrentForm->getValue("x_AGAMA");
		if (!$this->AGAMA->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->AGAMA->Visible = FALSE; // Disable update for API request
			else
				$this->AGAMA->setFormValue($val);
		}

		// Check field name 'ALAMAT_TINGGAL' first before field var 'x_ALAMAT_TINGGAL'
		$val = $CurrentForm->hasValue("ALAMAT_TINGGAL") ? $CurrentForm->getValue("ALAMAT_TINGGAL") : $CurrentForm->getValue("x_ALAMAT_TINGGAL");
		if (!$this->ALAMAT_TINGGAL->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->ALAMAT_TINGGAL->Visible = FALSE; // Disable update for API request
			else
				$this->ALAMAT_TINGGAL->setFormValue($val);
		}

		// Check field name 'NO_HP' first before field var 'x_NO_HP'
		$val = $CurrentForm->hasValue("NO_HP") ? $CurrentForm->getValue("NO_HP") : $CurrentForm->getValue("x_NO_HP");
		if (!$this->NO_HP->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->NO_HP->Visible = FALSE; // Disable update for API request
			else
				$this->NO_HP->setFormValue($val);
		}

		// Check field name 'NO_WA' first before field var 'x_NO_WA'
		$val = $CurrentForm->hasValue("NO_WA") ? $CurrentForm->getValue("NO_WA") : $CurrentForm->getValue("x_NO_WA");
		if (!$this->NO_WA->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->NO_WA->Visible = FALSE; // Disable update for API request
			else
				$this->NO_WA->setFormValue($val);
		}

		// Check field name 'ID_TELEGRAM' first before field var 'x_ID_TELEGRAM'
		$val = $CurrentForm->hasValue("ID_TELEGRAM") ? $CurrentForm->getValue("ID_TELEGRAM") : $CurrentForm->getValue("x_ID_TELEGRAM");
		if (!$this->ID_TELEGRAM->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->ID_TELEGRAM->Visible = FALSE; // Disable update for API request
			else
				$this->ID_TELEGRAM->setFormValue($val);
		}

		// Check field name 'ID_LINE' first before field var 'x_ID_LINE'
		$val = $CurrentForm->hasValue("ID_LINE") ? $CurrentForm->getValue("ID_LINE") : $CurrentForm->getValue("x_ID_LINE");
		if (!$this->ID_LINE->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->ID_LINE->Visible = FALSE; // Disable update for API request
			else
				$this->ID_LINE->setFormValue($val);
		}

		// Check field name 'ID_FACEBOOK' first before field var 'x_ID_FACEBOOK'
		$val = $CurrentForm->hasValue("ID_FACEBOOK") ? $CurrentForm->getValue("ID_FACEBOOK") : $CurrentForm->getValue("x_ID_FACEBOOK");
		if (!$this->ID_FACEBOOK->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->ID_FACEBOOK->Visible = FALSE; // Disable update for API request
			else
				$this->ID_FACEBOOK->setFormValue($val);
		}

		// Check field name 'ID_INSTAGRAM' first before field var 'x_ID_INSTAGRAM'
		$val = $CurrentForm->hasValue("ID_INSTAGRAM") ? $CurrentForm->getValue("ID_INSTAGRAM") : $CurrentForm->getValue("x_ID_INSTAGRAM");
		if (!$this->ID_INSTAGRAM->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->ID_INSTAGRAM->Visible = FALSE; // Disable update for API request
			else
				$this->ID_INSTAGRAM->setFormValue($val);
		}

		// Check field name 'ID_TWITTER' first before field var 'x_ID_TWITTER'
		$val = $CurrentForm->hasValue("ID_TWITTER") ? $CurrentForm->getValue("ID_TWITTER") : $CurrentForm->getValue("x_ID_TWITTER");
		if (!$this->ID_TWITTER->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->ID_TWITTER->Visible = FALSE; // Disable update for API request
			else
				$this->ID_TWITTER->setFormValue($val);
		}

		// Check field name 'ID_YOUTUBE' first before field var 'x_ID_YOUTUBE'
		$val = $CurrentForm->hasValue("ID_YOUTUBE") ? $CurrentForm->getValue("ID_YOUTUBE") : $CurrentForm->getValue("x_ID_YOUTUBE");
		if (!$this->ID_YOUTUBE->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->ID_YOUTUBE->Visible = FALSE; // Disable update for API request
			else
				$this->ID_YOUTUBE->setFormValue($val);
		}

		// Check field name 'EMAIL_GURU' first before field var 'x_EMAIL_GURU'
		$val = $CurrentForm->hasValue("EMAIL_GURU") ? $CurrentForm->getValue("EMAIL_GURU") : $CurrentForm->getValue("x_EMAIL_GURU");
		if (!$this->EMAIL_GURU->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->EMAIL_GURU->Visible = FALSE; // Disable update for API request
			else
				$this->EMAIL_GURU->setFormValue($val);
		}

		// Check field name 'TEMPAT_LAHIR' first before field var 'x_TEMPAT_LAHIR'
		$val = $CurrentForm->hasValue("TEMPAT_LAHIR") ? $CurrentForm->getValue("TEMPAT_LAHIR") : $CurrentForm->getValue("x_TEMPAT_LAHIR");
		if (!$this->TEMPAT_LAHIR->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->TEMPAT_LAHIR->Visible = FALSE; // Disable update for API request
			else
				$this->TEMPAT_LAHIR->setFormValue($val);
		}

		// Check field name 'TANGGAL_LAHIR' first before field var 'x_TANGGAL_LAHIR'
		$val = $CurrentForm->hasValue("TANGGAL_LAHIR") ? $CurrentForm->getValue("TANGGAL_LAHIR") : $CurrentForm->getValue("x_TANGGAL_LAHIR");
		if (!$this->TANGGAL_LAHIR->IsDetailKey) {
			if (IsApi() && $val == NULL)
				$this->TANGGAL_LAHIR->Visible = FALSE; // Disable update for API request
			else
				$this->TANGGAL_LAHIR->setFormValue($val);
			$this->TANGGAL_LAHIR->CurrentValue = UnFormatDateTime($this->TANGGAL_LAHIR->CurrentValue, 0);
		}
	}

	// Restore form values
	public function restoreFormValues()
	{
		global $CurrentForm;
		$this->ID_GURU->CurrentValue = $this->ID_GURU->FormValue;
		$this->NAMA_GURU->CurrentValue = $this->NAMA_GURU->FormValue;
		$this->GELAR_DEPAN->CurrentValue = $this->GELAR_DEPAN->FormValue;
		$this->GELAR_BELAKANG->CurrentValue = $this->GELAR_BELAKANG->FormValue;
		$this->JENIS_KELAMIN->CurrentValue = $this->JENIS_KELAMIN->FormValue;
		$this->AGAMA->CurrentValue = $this->AGAMA->FormValue;
		$this->ALAMAT_TINGGAL->CurrentValue = $this->ALAMAT_TINGGAL->FormValue;
		$this->NO_HP->CurrentValue = $this->NO_HP->FormValue;
		$this->NO_WA->CurrentValue = $this->NO_WA->FormValue;
		$this->ID_TELEGRAM->CurrentValue = $this->ID_TELEGRAM->FormValue;
		$this->ID_LINE->CurrentValue = $this->ID_LINE->FormValue;
		$this->ID_FACEBOOK->CurrentValue = $this->ID_FACEBOOK->FormValue;
		$this->ID_INSTAGRAM->CurrentValue = $this->ID_INSTAGRAM->FormValue;
		$this->ID_TWITTER->CurrentValue = $this->ID_TWITTER->FormValue;
		$this->ID_YOUTUBE->CurrentValue = $this->ID_YOUTUBE->FormValue;
		$this->EMAIL_GURU->CurrentValue = $this->EMAIL_GURU->FormValue;
		$this->TEMPAT_LAHIR->CurrentValue = $this->TEMPAT_LAHIR->FormValue;
		$this->TANGGAL_LAHIR->CurrentValue = $this->TANGGAL_LAHIR->FormValue;
		$this->TANGGAL_LAHIR->CurrentValue = UnFormatDateTime($this->TANGGAL_LAHIR->CurrentValue, 0);
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->ID_GURU->setDbValue($row['ID_GURU']);
		$this->NAMA_GURU->setDbValue($row['NAMA_GURU']);
		$this->GELAR_DEPAN->setDbValue($row['GELAR_DEPAN']);
		$this->GELAR_BELAKANG->setDbValue($row['GELAR_BELAKANG']);
		$this->JENIS_KELAMIN->setDbValue($row['JENIS_KELAMIN']);
		$this->AGAMA->setDbValue($row['AGAMA']);
		$this->ALAMAT_TINGGAL->setDbValue($row['ALAMAT_TINGGAL']);
		$this->NO_HP->setDbValue($row['NO_HP']);
		$this->NO_WA->setDbValue($row['NO_WA']);
		$this->ID_TELEGRAM->setDbValue($row['ID_TELEGRAM']);
		$this->ID_LINE->setDbValue($row['ID_LINE']);
		$this->ID_FACEBOOK->setDbValue($row['ID_FACEBOOK']);
		$this->ID_INSTAGRAM->setDbValue($row['ID_INSTAGRAM']);
		$this->ID_TWITTER->setDbValue($row['ID_TWITTER']);
		$this->ID_YOUTUBE->setDbValue($row['ID_YOUTUBE']);
		$this->EMAIL_GURU->setDbValue($row['EMAIL_GURU']);
		$this->TEMPAT_LAHIR->setDbValue($row['TEMPAT_LAHIR']);
		$this->TANGGAL_LAHIR->setDbValue($row['TANGGAL_LAHIR']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$this->loadDefaultValues();
		$row = [];
		$row['ID_GURU'] = $this->ID_GURU->CurrentValue;
		$row['NAMA_GURU'] = $this->NAMA_GURU->CurrentValue;
		$row['GELAR_DEPAN'] = $this->GELAR_DEPAN->CurrentValue;
		$row['GELAR_BELAKANG'] = $this->GELAR_BELAKANG->CurrentValue;
		$row['JENIS_KELAMIN'] = $this->JENIS_KELAMIN->CurrentValue;
		$row['AGAMA'] = $this->AGAMA->CurrentValue;
		$row['ALAMAT_TINGGAL'] = $this->ALAMAT_TINGGAL->CurrentValue;
		$row['NO_HP'] = $this->NO_HP->CurrentValue;
		$row['NO_WA'] = $this->NO_WA->CurrentValue;
		$row['ID_TELEGRAM'] = $this->ID_TELEGRAM->CurrentValue;
		$row['ID_LINE'] = $this->ID_LINE->CurrentValue;
		$row['ID_FACEBOOK'] = $this->ID_FACEBOOK->CurrentValue;
		$row['ID_INSTAGRAM'] = $this->ID_INSTAGRAM->CurrentValue;
		$row['ID_TWITTER'] = $this->ID_TWITTER->CurrentValue;
		$row['ID_YOUTUBE'] = $this->ID_YOUTUBE->CurrentValue;
		$row['EMAIL_GURU'] = $this->EMAIL_GURU->CurrentValue;
		$row['TEMPAT_LAHIR'] = $this->TEMPAT_LAHIR->CurrentValue;
		$row['TANGGAL_LAHIR'] = $this->TANGGAL_LAHIR->CurrentValue;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("ID_GURU")) != "")
			$this->ID_GURU->OldValue = $this->getKey("ID_GURU"); // ID_GURU
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Call Row_Rendering event

		$this->Row_Rendering();

		// Common render codes for all row types
		// ID_GURU
		// NAMA_GURU
		// GELAR_DEPAN
		// GELAR_BELAKANG
		// JENIS_KELAMIN
		// AGAMA
		// ALAMAT_TINGGAL
		// NO_HP
		// NO_WA
		// ID_TELEGRAM
		// ID_LINE
		// ID_FACEBOOK
		// ID_INSTAGRAM
		// ID_TWITTER
		// ID_YOUTUBE
		// EMAIL_GURU
		// TEMPAT_LAHIR
		// TANGGAL_LAHIR

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// ID_GURU
			$this->ID_GURU->ViewValue = $this->ID_GURU->CurrentValue;
			$this->ID_GURU->ViewCustomAttributes = "";

			// NAMA_GURU
			$this->NAMA_GURU->ViewValue = $this->NAMA_GURU->CurrentValue;
			$this->NAMA_GURU->ViewCustomAttributes = "";

			// GELAR_DEPAN
			$this->GELAR_DEPAN->ViewValue = $this->GELAR_DEPAN->CurrentValue;
			$this->GELAR_DEPAN->ViewCustomAttributes = "";

			// GELAR_BELAKANG
			$this->GELAR_BELAKANG->ViewValue = $this->GELAR_BELAKANG->CurrentValue;
			$this->GELAR_BELAKANG->ViewCustomAttributes = "";

			// JENIS_KELAMIN
			$this->JENIS_KELAMIN->ViewValue = $this->JENIS_KELAMIN->CurrentValue;
			$this->JENIS_KELAMIN->ViewCustomAttributes = "";

			// AGAMA
			$this->AGAMA->ViewValue = $this->AGAMA->CurrentValue;
			$this->AGAMA->ViewCustomAttributes = "";

			// ALAMAT_TINGGAL
			$this->ALAMAT_TINGGAL->ViewValue = $this->ALAMAT_TINGGAL->CurrentValue;
			$this->ALAMAT_TINGGAL->ViewCustomAttributes = "";

			// NO_HP
			$this->NO_HP->ViewValue = $this->NO_HP->CurrentValue;
			$this->NO_HP->ViewCustomAttributes = "";

			// NO_WA
			$this->NO_WA->ViewValue = $this->NO_WA->CurrentValue;
			$this->NO_WA->ViewCustomAttributes = "";

			// ID_TELEGRAM
			$this->ID_TELEGRAM->ViewValue = $this->ID_TELEGRAM->CurrentValue;
			$this->ID_TELEGRAM->ViewCustomAttributes = "";

			// ID_LINE
			$this->ID_LINE->ViewValue = $this->ID_LINE->CurrentValue;
			$this->ID_LINE->ViewCustomAttributes = "";

			// ID_FACEBOOK
			$this->ID_FACEBOOK->ViewValue = $this->ID_FACEBOOK->CurrentValue;
			$this->ID_FACEBOOK->ViewCustomAttributes = "";

			// ID_INSTAGRAM
			$this->ID_INSTAGRAM->ViewValue = $this->ID_INSTAGRAM->CurrentValue;
			$this->ID_INSTAGRAM->ViewCustomAttributes = "";

			// ID_TWITTER
			$this->ID_TWITTER->ViewValue = $this->ID_TWITTER->CurrentValue;
			$this->ID_TWITTER->ViewCustomAttributes = "";

			// ID_YOUTUBE
			$this->ID_YOUTUBE->ViewValue = $this->ID_YOUTUBE->CurrentValue;
			$this->ID_YOUTUBE->ViewCustomAttributes = "";

			// EMAIL_GURU
			$this->EMAIL_GURU->ViewValue = $this->EMAIL_GURU->CurrentValue;
			$this->EMAIL_GURU->ViewCustomAttributes = "";

			// TEMPAT_LAHIR
			$this->TEMPAT_LAHIR->ViewValue = $this->TEMPAT_LAHIR->CurrentValue;
			$this->TEMPAT_LAHIR->ViewCustomAttributes = "";

			// TANGGAL_LAHIR
			$this->TANGGAL_LAHIR->ViewValue = $this->TANGGAL_LAHIR->CurrentValue;
			$this->TANGGAL_LAHIR->ViewValue = FormatDateTime($this->TANGGAL_LAHIR->ViewValue, 0);
			$this->TANGGAL_LAHIR->ViewCustomAttributes = "";

			// ID_GURU
			$this->ID_GURU->LinkCustomAttributes = "";
			$this->ID_GURU->HrefValue = "";
			$this->ID_GURU->TooltipValue = "";

			// NAMA_GURU
			$this->NAMA_GURU->LinkCustomAttributes = "";
			$this->NAMA_GURU->HrefValue = "";
			$this->NAMA_GURU->TooltipValue = "";

			// GELAR_DEPAN
			$this->GELAR_DEPAN->LinkCustomAttributes = "";
			$this->GELAR_DEPAN->HrefValue = "";
			$this->GELAR_DEPAN->TooltipValue = "";

			// GELAR_BELAKANG
			$this->GELAR_BELAKANG->LinkCustomAttributes = "";
			$this->GELAR_BELAKANG->HrefValue = "";
			$this->GELAR_BELAKANG->TooltipValue = "";

			// JENIS_KELAMIN
			$this->JENIS_KELAMIN->LinkCustomAttributes = "";
			$this->JENIS_KELAMIN->HrefValue = "";
			$this->JENIS_KELAMIN->TooltipValue = "";

			// AGAMA
			$this->AGAMA->LinkCustomAttributes = "";
			$this->AGAMA->HrefValue = "";
			$this->AGAMA->TooltipValue = "";

			// ALAMAT_TINGGAL
			$this->ALAMAT_TINGGAL->LinkCustomAttributes = "";
			$this->ALAMAT_TINGGAL->HrefValue = "";
			$this->ALAMAT_TINGGAL->TooltipValue = "";

			// NO_HP
			$this->NO_HP->LinkCustomAttributes = "";
			$this->NO_HP->HrefValue = "";
			$this->NO_HP->TooltipValue = "";

			// NO_WA
			$this->NO_WA->LinkCustomAttributes = "";
			$this->NO_WA->HrefValue = "";
			$this->NO_WA->TooltipValue = "";

			// ID_TELEGRAM
			$this->ID_TELEGRAM->LinkCustomAttributes = "";
			$this->ID_TELEGRAM->HrefValue = "";
			$this->ID_TELEGRAM->TooltipValue = "";

			// ID_LINE
			$this->ID_LINE->LinkCustomAttributes = "";
			$this->ID_LINE->HrefValue = "";
			$this->ID_LINE->TooltipValue = "";

			// ID_FACEBOOK
			$this->ID_FACEBOOK->LinkCustomAttributes = "";
			$this->ID_FACEBOOK->HrefValue = "";
			$this->ID_FACEBOOK->TooltipValue = "";

			// ID_INSTAGRAM
			$this->ID_INSTAGRAM->LinkCustomAttributes = "";
			$this->ID_INSTAGRAM->HrefValue = "";
			$this->ID_INSTAGRAM->TooltipValue = "";

			// ID_TWITTER
			$this->ID_TWITTER->LinkCustomAttributes = "";
			$this->ID_TWITTER->HrefValue = "";
			$this->ID_TWITTER->TooltipValue = "";

			// ID_YOUTUBE
			$this->ID_YOUTUBE->LinkCustomAttributes = "";
			$this->ID_YOUTUBE->HrefValue = "";
			$this->ID_YOUTUBE->TooltipValue = "";

			// EMAIL_GURU
			$this->EMAIL_GURU->LinkCustomAttributes = "";
			$this->EMAIL_GURU->HrefValue = "";
			$this->EMAIL_GURU->TooltipValue = "";

			// TEMPAT_LAHIR
			$this->TEMPAT_LAHIR->LinkCustomAttributes = "";
			$this->TEMPAT_LAHIR->HrefValue = "";
			$this->TEMPAT_LAHIR->TooltipValue = "";

			// TANGGAL_LAHIR
			$this->TANGGAL_LAHIR->LinkCustomAttributes = "";
			$this->TANGGAL_LAHIR->HrefValue = "";
			$this->TANGGAL_LAHIR->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_ADD) { // Add row

			// ID_GURU
			$this->ID_GURU->EditAttrs["class"] = "form-control";
			$this->ID_GURU->EditCustomAttributes = "";
			if (!$this->ID_GURU->Raw)
				$this->ID_GURU->CurrentValue = HtmlDecode($this->ID_GURU->CurrentValue);
			$this->ID_GURU->EditValue = HtmlEncode($this->ID_GURU->CurrentValue);
			$this->ID_GURU->PlaceHolder = RemoveHtml($this->ID_GURU->caption());

			// NAMA_GURU
			$this->NAMA_GURU->EditAttrs["class"] = "form-control";
			$this->NAMA_GURU->EditCustomAttributes = "";
			if (!$this->NAMA_GURU->Raw)
				$this->NAMA_GURU->CurrentValue = HtmlDecode($this->NAMA_GURU->CurrentValue);
			$this->NAMA_GURU->EditValue = HtmlEncode($this->NAMA_GURU->CurrentValue);
			$this->NAMA_GURU->PlaceHolder = RemoveHtml($this->NAMA_GURU->caption());

			// GELAR_DEPAN
			$this->GELAR_DEPAN->EditAttrs["class"] = "form-control";
			$this->GELAR_DEPAN->EditCustomAttributes = "";
			if (!$this->GELAR_DEPAN->Raw)
				$this->GELAR_DEPAN->CurrentValue = HtmlDecode($this->GELAR_DEPAN->CurrentValue);
			$this->GELAR_DEPAN->EditValue = HtmlEncode($this->GELAR_DEPAN->CurrentValue);
			$this->GELAR_DEPAN->PlaceHolder = RemoveHtml($this->GELAR_DEPAN->caption());

			// GELAR_BELAKANG
			$this->GELAR_BELAKANG->EditAttrs["class"] = "form-control";
			$this->GELAR_BELAKANG->EditCustomAttributes = "";
			if (!$this->GELAR_BELAKANG->Raw)
				$this->GELAR_BELAKANG->CurrentValue = HtmlDecode($this->GELAR_BELAKANG->CurrentValue);
			$this->GELAR_BELAKANG->EditValue = HtmlEncode($this->GELAR_BELAKANG->CurrentValue);
			$this->GELAR_BELAKANG->PlaceHolder = RemoveHtml($this->GELAR_BELAKANG->caption());

			// JENIS_KELAMIN
			$this->JENIS_KELAMIN->EditAttrs["class"] = "form-control";
			$this->JENIS_KELAMIN->EditCustomAttributes = "";
			if (!$this->JENIS_KELAMIN->Raw)
				$this->JENIS_KELAMIN->CurrentValue = HtmlDecode($this->JENIS_KELAMIN->CurrentValue);
			$this->JENIS_KELAMIN->EditValue = HtmlEncode($this->JENIS_KELAMIN->CurrentValue);
			$this->JENIS_KELAMIN->PlaceHolder = RemoveHtml($this->JENIS_KELAMIN->caption());

			// AGAMA
			$this->AGAMA->EditAttrs["class"] = "form-control";
			$this->AGAMA->EditCustomAttributes = "";
			if (!$this->AGAMA->Raw)
				$this->AGAMA->CurrentValue = HtmlDecode($this->AGAMA->CurrentValue);
			$this->AGAMA->EditValue = HtmlEncode($this->AGAMA->CurrentValue);
			$this->AGAMA->PlaceHolder = RemoveHtml($this->AGAMA->caption());

			// ALAMAT_TINGGAL
			$this->ALAMAT_TINGGAL->EditAttrs["class"] = "form-control";
			$this->ALAMAT_TINGGAL->EditCustomAttributes = "";
			if (!$this->ALAMAT_TINGGAL->Raw)
				$this->ALAMAT_TINGGAL->CurrentValue = HtmlDecode($this->ALAMAT_TINGGAL->CurrentValue);
			$this->ALAMAT_TINGGAL->EditValue = HtmlEncode($this->ALAMAT_TINGGAL->CurrentValue);
			$this->ALAMAT_TINGGAL->PlaceHolder = RemoveHtml($this->ALAMAT_TINGGAL->caption());

			// NO_HP
			$this->NO_HP->EditAttrs["class"] = "form-control";
			$this->NO_HP->EditCustomAttributes = "";
			if (!$this->NO_HP->Raw)
				$this->NO_HP->CurrentValue = HtmlDecode($this->NO_HP->CurrentValue);
			$this->NO_HP->EditValue = HtmlEncode($this->NO_HP->CurrentValue);
			$this->NO_HP->PlaceHolder = RemoveHtml($this->NO_HP->caption());

			// NO_WA
			$this->NO_WA->EditAttrs["class"] = "form-control";
			$this->NO_WA->EditCustomAttributes = "";
			if (!$this->NO_WA->Raw)
				$this->NO_WA->CurrentValue = HtmlDecode($this->NO_WA->CurrentValue);
			$this->NO_WA->EditValue = HtmlEncode($this->NO_WA->CurrentValue);
			$this->NO_WA->PlaceHolder = RemoveHtml($this->NO_WA->caption());

			// ID_TELEGRAM
			$this->ID_TELEGRAM->EditAttrs["class"] = "form-control";
			$this->ID_TELEGRAM->EditCustomAttributes = "";
			if (!$this->ID_TELEGRAM->Raw)
				$this->ID_TELEGRAM->CurrentValue = HtmlDecode($this->ID_TELEGRAM->CurrentValue);
			$this->ID_TELEGRAM->EditValue = HtmlEncode($this->ID_TELEGRAM->CurrentValue);
			$this->ID_TELEGRAM->PlaceHolder = RemoveHtml($this->ID_TELEGRAM->caption());

			// ID_LINE
			$this->ID_LINE->EditAttrs["class"] = "form-control";
			$this->ID_LINE->EditCustomAttributes = "";
			if (!$this->ID_LINE->Raw)
				$this->ID_LINE->CurrentValue = HtmlDecode($this->ID_LINE->CurrentValue);
			$this->ID_LINE->EditValue = HtmlEncode($this->ID_LINE->CurrentValue);
			$this->ID_LINE->PlaceHolder = RemoveHtml($this->ID_LINE->caption());

			// ID_FACEBOOK
			$this->ID_FACEBOOK->EditAttrs["class"] = "form-control";
			$this->ID_FACEBOOK->EditCustomAttributes = "";
			if (!$this->ID_FACEBOOK->Raw)
				$this->ID_FACEBOOK->CurrentValue = HtmlDecode($this->ID_FACEBOOK->CurrentValue);
			$this->ID_FACEBOOK->EditValue = HtmlEncode($this->ID_FACEBOOK->CurrentValue);
			$this->ID_FACEBOOK->PlaceHolder = RemoveHtml($this->ID_FACEBOOK->caption());

			// ID_INSTAGRAM
			$this->ID_INSTAGRAM->EditAttrs["class"] = "form-control";
			$this->ID_INSTAGRAM->EditCustomAttributes = "";
			if (!$this->ID_INSTAGRAM->Raw)
				$this->ID_INSTAGRAM->CurrentValue = HtmlDecode($this->ID_INSTAGRAM->CurrentValue);
			$this->ID_INSTAGRAM->EditValue = HtmlEncode($this->ID_INSTAGRAM->CurrentValue);
			$this->ID_INSTAGRAM->PlaceHolder = RemoveHtml($this->ID_INSTAGRAM->caption());

			// ID_TWITTER
			$this->ID_TWITTER->EditAttrs["class"] = "form-control";
			$this->ID_TWITTER->EditCustomAttributes = "";
			if (!$this->ID_TWITTER->Raw)
				$this->ID_TWITTER->CurrentValue = HtmlDecode($this->ID_TWITTER->CurrentValue);
			$this->ID_TWITTER->EditValue = HtmlEncode($this->ID_TWITTER->CurrentValue);
			$this->ID_TWITTER->PlaceHolder = RemoveHtml($this->ID_TWITTER->caption());

			// ID_YOUTUBE
			$this->ID_YOUTUBE->EditAttrs["class"] = "form-control";
			$this->ID_YOUTUBE->EditCustomAttributes = "";
			if (!$this->ID_YOUTUBE->Raw)
				$this->ID_YOUTUBE->CurrentValue = HtmlDecode($this->ID_YOUTUBE->CurrentValue);
			$this->ID_YOUTUBE->EditValue = HtmlEncode($this->ID_YOUTUBE->CurrentValue);
			$this->ID_YOUTUBE->PlaceHolder = RemoveHtml($this->ID_YOUTUBE->caption());

			// EMAIL_GURU
			$this->EMAIL_GURU->EditAttrs["class"] = "form-control";
			$this->EMAIL_GURU->EditCustomAttributes = "";
			if (!$this->EMAIL_GURU->Raw)
				$this->EMAIL_GURU->CurrentValue = HtmlDecode($this->EMAIL_GURU->CurrentValue);
			$this->EMAIL_GURU->EditValue = HtmlEncode($this->EMAIL_GURU->CurrentValue);
			$this->EMAIL_GURU->PlaceHolder = RemoveHtml($this->EMAIL_GURU->caption());

			// TEMPAT_LAHIR
			$this->TEMPAT_LAHIR->EditAttrs["class"] = "form-control";
			$this->TEMPAT_LAHIR->EditCustomAttributes = "";
			if (!$this->TEMPAT_LAHIR->Raw)
				$this->TEMPAT_LAHIR->CurrentValue = HtmlDecode($this->TEMPAT_LAHIR->CurrentValue);
			$this->TEMPAT_LAHIR->EditValue = HtmlEncode($this->TEMPAT_LAHIR->CurrentValue);
			$this->TEMPAT_LAHIR->PlaceHolder = RemoveHtml($this->TEMPAT_LAHIR->caption());

			// TANGGAL_LAHIR
			$this->TANGGAL_LAHIR->EditAttrs["class"] = "form-control";
			$this->TANGGAL_LAHIR->EditCustomAttributes = "";
			$this->TANGGAL_LAHIR->EditValue = HtmlEncode(FormatDateTime($this->TANGGAL_LAHIR->CurrentValue, 8));
			$this->TANGGAL_LAHIR->PlaceHolder = RemoveHtml($this->TANGGAL_LAHIR->caption());

			// Add refer script
			// ID_GURU

			$this->ID_GURU->LinkCustomAttributes = "";
			$this->ID_GURU->HrefValue = "";

			// NAMA_GURU
			$this->NAMA_GURU->LinkCustomAttributes = "";
			$this->NAMA_GURU->HrefValue = "";

			// GELAR_DEPAN
			$this->GELAR_DEPAN->LinkCustomAttributes = "";
			$this->GELAR_DEPAN->HrefValue = "";

			// GELAR_BELAKANG
			$this->GELAR_BELAKANG->LinkCustomAttributes = "";
			$this->GELAR_BELAKANG->HrefValue = "";

			// JENIS_KELAMIN
			$this->JENIS_KELAMIN->LinkCustomAttributes = "";
			$this->JENIS_KELAMIN->HrefValue = "";

			// AGAMA
			$this->AGAMA->LinkCustomAttributes = "";
			$this->AGAMA->HrefValue = "";

			// ALAMAT_TINGGAL
			$this->ALAMAT_TINGGAL->LinkCustomAttributes = "";
			$this->ALAMAT_TINGGAL->HrefValue = "";

			// NO_HP
			$this->NO_HP->LinkCustomAttributes = "";
			$this->NO_HP->HrefValue = "";

			// NO_WA
			$this->NO_WA->LinkCustomAttributes = "";
			$this->NO_WA->HrefValue = "";

			// ID_TELEGRAM
			$this->ID_TELEGRAM->LinkCustomAttributes = "";
			$this->ID_TELEGRAM->HrefValue = "";

			// ID_LINE
			$this->ID_LINE->LinkCustomAttributes = "";
			$this->ID_LINE->HrefValue = "";

			// ID_FACEBOOK
			$this->ID_FACEBOOK->LinkCustomAttributes = "";
			$this->ID_FACEBOOK->HrefValue = "";

			// ID_INSTAGRAM
			$this->ID_INSTAGRAM->LinkCustomAttributes = "";
			$this->ID_INSTAGRAM->HrefValue = "";

			// ID_TWITTER
			$this->ID_TWITTER->LinkCustomAttributes = "";
			$this->ID_TWITTER->HrefValue = "";

			// ID_YOUTUBE
			$this->ID_YOUTUBE->LinkCustomAttributes = "";
			$this->ID_YOUTUBE->HrefValue = "";

			// EMAIL_GURU
			$this->EMAIL_GURU->LinkCustomAttributes = "";
			$this->EMAIL_GURU->HrefValue = "";

			// TEMPAT_LAHIR
			$this->TEMPAT_LAHIR->LinkCustomAttributes = "";
			$this->TEMPAT_LAHIR->HrefValue = "";

			// TANGGAL_LAHIR
			$this->TANGGAL_LAHIR->LinkCustomAttributes = "";
			$this->TANGGAL_LAHIR->HrefValue = "";
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	protected function validateForm()
	{
		global $Language, $FormError;

		// Initialize form error message
		$FormError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return ($FormError == "");
		if ($this->ID_GURU->Required) {
			if (!$this->ID_GURU->IsDetailKey && $this->ID_GURU->FormValue != NULL && $this->ID_GURU->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ID_GURU->caption(), $this->ID_GURU->RequiredErrorMessage));
			}
		}
		if ($this->NAMA_GURU->Required) {
			if (!$this->NAMA_GURU->IsDetailKey && $this->NAMA_GURU->FormValue != NULL && $this->NAMA_GURU->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->NAMA_GURU->caption(), $this->NAMA_GURU->RequiredErrorMessage));
			}
		}
		if ($this->GELAR_DEPAN->Required) {
			if (!$this->GELAR_DEPAN->IsDetailKey && $this->GELAR_DEPAN->FormValue != NULL && $this->GELAR_DEPAN->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->GELAR_DEPAN->caption(), $this->GELAR_DEPAN->RequiredErrorMessage));
			}
		}
		if ($this->GELAR_BELAKANG->Required) {
			if (!$this->GELAR_BELAKANG->IsDetailKey && $this->GELAR_BELAKANG->FormValue != NULL && $this->GELAR_BELAKANG->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->GELAR_BELAKANG->caption(), $this->GELAR_BELAKANG->RequiredErrorMessage));
			}
		}
		if ($this->JENIS_KELAMIN->Required) {
			if (!$this->JENIS_KELAMIN->IsDetailKey && $this->JENIS_KELAMIN->FormValue != NULL && $this->JENIS_KELAMIN->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->JENIS_KELAMIN->caption(), $this->JENIS_KELAMIN->RequiredErrorMessage));
			}
		}
		if ($this->AGAMA->Required) {
			if (!$this->AGAMA->IsDetailKey && $this->AGAMA->FormValue != NULL && $this->AGAMA->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->AGAMA->caption(), $this->AGAMA->RequiredErrorMessage));
			}
		}
		if ($this->ALAMAT_TINGGAL->Required) {
			if (!$this->ALAMAT_TINGGAL->IsDetailKey && $this->ALAMAT_TINGGAL->FormValue != NULL && $this->ALAMAT_TINGGAL->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ALAMAT_TINGGAL->caption(), $this->ALAMAT_TINGGAL->RequiredErrorMessage));
			}
		}
		if ($this->NO_HP->Required) {
			if (!$this->NO_HP->IsDetailKey && $this->NO_HP->FormValue != NULL && $this->NO_HP->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->NO_HP->caption(), $this->NO_HP->RequiredErrorMessage));
			}
		}
		if ($this->NO_WA->Required) {
			if (!$this->NO_WA->IsDetailKey && $this->NO_WA->FormValue != NULL && $this->NO_WA->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->NO_WA->caption(), $this->NO_WA->RequiredErrorMessage));
			}
		}
		if ($this->ID_TELEGRAM->Required) {
			if (!$this->ID_TELEGRAM->IsDetailKey && $this->ID_TELEGRAM->FormValue != NULL && $this->ID_TELEGRAM->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ID_TELEGRAM->caption(), $this->ID_TELEGRAM->RequiredErrorMessage));
			}
		}
		if ($this->ID_LINE->Required) {
			if (!$this->ID_LINE->IsDetailKey && $this->ID_LINE->FormValue != NULL && $this->ID_LINE->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ID_LINE->caption(), $this->ID_LINE->RequiredErrorMessage));
			}
		}
		if ($this->ID_FACEBOOK->Required) {
			if (!$this->ID_FACEBOOK->IsDetailKey && $this->ID_FACEBOOK->FormValue != NULL && $this->ID_FACEBOOK->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ID_FACEBOOK->caption(), $this->ID_FACEBOOK->RequiredErrorMessage));
			}
		}
		if ($this->ID_INSTAGRAM->Required) {
			if (!$this->ID_INSTAGRAM->IsDetailKey && $this->ID_INSTAGRAM->FormValue != NULL && $this->ID_INSTAGRAM->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ID_INSTAGRAM->caption(), $this->ID_INSTAGRAM->RequiredErrorMessage));
			}
		}
		if ($this->ID_TWITTER->Required) {
			if (!$this->ID_TWITTER->IsDetailKey && $this->ID_TWITTER->FormValue != NULL && $this->ID_TWITTER->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ID_TWITTER->caption(), $this->ID_TWITTER->RequiredErrorMessage));
			}
		}
		if ($this->ID_YOUTUBE->Required) {
			if (!$this->ID_YOUTUBE->IsDetailKey && $this->ID_YOUTUBE->FormValue != NULL && $this->ID_YOUTUBE->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ID_YOUTUBE->caption(), $this->ID_YOUTUBE->RequiredErrorMessage));
			}
		}
		if ($this->EMAIL_GURU->Required) {
			if (!$this->EMAIL_GURU->IsDetailKey && $this->EMAIL_GURU->FormValue != NULL && $this->EMAIL_GURU->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->EMAIL_GURU->caption(), $this->EMAIL_GURU->RequiredErrorMessage));
			}
		}
		if ($this->TEMPAT_LAHIR->Required) {
			if (!$this->TEMPAT_LAHIR->IsDetailKey && $this->TEMPAT_LAHIR->FormValue != NULL && $this->TEMPAT_LAHIR->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->TEMPAT_LAHIR->caption(), $this->TEMPAT_LAHIR->RequiredErrorMessage));
			}
		}
		if ($this->TANGGAL_LAHIR->Required) {
			if (!$this->TANGGAL_LAHIR->IsDetailKey && $this->TANGGAL_LAHIR->FormValue != NULL && $this->TANGGAL_LAHIR->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->TANGGAL_LAHIR->caption(), $this->TANGGAL_LAHIR->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->TANGGAL_LAHIR->FormValue)) {
			AddMessage($FormError, $this->TANGGAL_LAHIR->errorMessage());
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($FormError, $formCustomError);
		}
		return $validateForm;
	}

	// Add record
	protected function addRow($rsold = NULL)
	{
		global $Language, $Security;
		$conn = $this->getConnection();

		// Load db values from rsold
		$this->loadDbValues($rsold);
		if ($rsold) {
		}
		$rsnew = [];

		// ID_GURU
		$this->ID_GURU->setDbValueDef($rsnew, $this->ID_GURU->CurrentValue, "", FALSE);

		// NAMA_GURU
		$this->NAMA_GURU->setDbValueDef($rsnew, $this->NAMA_GURU->CurrentValue, "", FALSE);

		// GELAR_DEPAN
		$this->GELAR_DEPAN->setDbValueDef($rsnew, $this->GELAR_DEPAN->CurrentValue, NULL, FALSE);

		// GELAR_BELAKANG
		$this->GELAR_BELAKANG->setDbValueDef($rsnew, $this->GELAR_BELAKANG->CurrentValue, NULL, FALSE);

		// JENIS_KELAMIN
		$this->JENIS_KELAMIN->setDbValueDef($rsnew, $this->JENIS_KELAMIN->CurrentValue, NULL, FALSE);

		// AGAMA
		$this->AGAMA->setDbValueDef($rsnew, $this->AGAMA->CurrentValue, NULL, FALSE);

		// ALAMAT_TINGGAL
		$this->ALAMAT_TINGGAL->setDbValueDef($rsnew, $this->ALAMAT_TINGGAL->CurrentValue, NULL, FALSE);

		// NO_HP
		$this->NO_HP->setDbValueDef($rsnew, $this->NO_HP->CurrentValue, NULL, FALSE);

		// NO_WA
		$this->NO_WA->setDbValueDef($rsnew, $this->NO_WA->CurrentValue, NULL, FALSE);

		// ID_TELEGRAM
		$this->ID_TELEGRAM->setDbValueDef($rsnew, $this->ID_TELEGRAM->CurrentValue, NULL, FALSE);

		// ID_LINE
		$this->ID_LINE->setDbValueDef($rsnew, $this->ID_LINE->CurrentValue, NULL, FALSE);

		// ID_FACEBOOK
		$this->ID_FACEBOOK->setDbValueDef($rsnew, $this->ID_FACEBOOK->CurrentValue, NULL, FALSE);

		// ID_INSTAGRAM
		$this->ID_INSTAGRAM->setDbValueDef($rsnew, $this->ID_INSTAGRAM->CurrentValue, NULL, FALSE);

		// ID_TWITTER
		$this->ID_TWITTER->setDbValueDef($rsnew, $this->ID_TWITTER->CurrentValue, NULL, FALSE);

		// ID_YOUTUBE
		$this->ID_YOUTUBE->setDbValueDef($rsnew, $this->ID_YOUTUBE->CurrentValue, NULL, FALSE);

		// EMAIL_GURU
		$this->EMAIL_GURU->setDbValueDef($rsnew, $this->EMAIL_GURU->CurrentValue, NULL, FALSE);

		// TEMPAT_LAHIR
		$this->TEMPAT_LAHIR->setDbValueDef($rsnew, $this->TEMPAT_LAHIR->CurrentValue, NULL, FALSE);

		// TANGGAL_LAHIR
		$this->TANGGAL_LAHIR->setDbValueDef($rsnew, UnFormatDateTime($this->TANGGAL_LAHIR->CurrentValue, 0), NULL, FALSE);

		// Call Row Inserting event
		$rs = ($rsold) ? $rsold->fields : NULL;
		$insertRow = $this->Row_Inserting($rs, $rsnew);

		// Check if key value entered
		if ($insertRow && $this->ValidateKey && strval($rsnew['ID_GURU']) == "") {
			$this->setFailureMessage($Language->phrase("InvalidKeyValue"));
			$insertRow = FALSE;
		}

		// Check for duplicate key
		if ($insertRow && $this->ValidateKey) {
			$filter = $this->getRecordFilter($rsnew);
			$rsChk = $this->loadRs($filter);
			if ($rsChk && !$rsChk->EOF) {
				$keyErrMsg = str_replace("%f", $filter, $Language->phrase("DupKey"));
				$this->setFailureMessage($keyErrMsg);
				$rsChk->close();
				$insertRow = FALSE;
			}
		}
		if ($insertRow) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			$addRow = $this->insert($rsnew);
			$conn->raiseErrorFn = "";
			if ($addRow) {
			}
		} else {
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("InsertCancelled"));
			}
			$addRow = FALSE;
		}
		if ($addRow) {

			// Call Row Inserted event
			$rs = ($rsold) ? $rsold->fields : NULL;
			$this->Row_Inserted($rs, $rsnew);
		}

		// Clean upload path if any
		if ($addRow) {
		}

		// Write JSON for API request
		if (IsApi() && $addRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $addRow;
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("guru_pengajarlist.php"), "", $this->TableVar, TRUE);
		$pageId = ($this->isCopy()) ? "Copy" : "Add";
		$Breadcrumb->add("add", $pageId, $url);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}
} // End class
?>