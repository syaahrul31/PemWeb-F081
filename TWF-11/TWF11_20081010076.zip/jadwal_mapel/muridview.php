<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$murid_view = new murid_view();

// Run the page
$murid_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$murid_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$murid_view->isExport()) { ?>
<script>
var fmuridview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fmuridview = currentForm = new ew.Form("fmuridview", "view");
	loadjs.done("fmuridview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$murid_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $murid_view->ExportOptions->render("body") ?>
<?php $murid_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $murid_view->showPageHeader(); ?>
<?php
$murid_view->showMessage();
?>
<form name="fmuridview" id="fmuridview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="murid">
<input type="hidden" name="modal" value="<?php echo (int)$murid_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($murid_view->NO_INDUK->Visible) { // NO_INDUK ?>
	<tr id="r_NO_INDUK">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_NO_INDUK"><?php echo $murid_view->NO_INDUK->caption() ?></span></td>
		<td data-name="NO_INDUK" <?php echo $murid_view->NO_INDUK->cellAttributes() ?>>
<span id="el_murid_NO_INDUK">
<span<?php echo $murid_view->NO_INDUK->viewAttributes() ?>><?php echo $murid_view->NO_INDUK->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->NAMA_MURID->Visible) { // NAMA_MURID ?>
	<tr id="r_NAMA_MURID">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_NAMA_MURID"><?php echo $murid_view->NAMA_MURID->caption() ?></span></td>
		<td data-name="NAMA_MURID" <?php echo $murid_view->NAMA_MURID->cellAttributes() ?>>
<span id="el_murid_NAMA_MURID">
<span<?php echo $murid_view->NAMA_MURID->viewAttributes() ?>><?php echo $murid_view->NAMA_MURID->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->JEN_KEL->Visible) { // JEN_KEL ?>
	<tr id="r_JEN_KEL">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_JEN_KEL"><?php echo $murid_view->JEN_KEL->caption() ?></span></td>
		<td data-name="JEN_KEL" <?php echo $murid_view->JEN_KEL->cellAttributes() ?>>
<span id="el_murid_JEN_KEL">
<span<?php echo $murid_view->JEN_KEL->viewAttributes() ?>><?php echo $murid_view->JEN_KEL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->AGAMA_MURID->Visible) { // AGAMA_MURID ?>
	<tr id="r_AGAMA_MURID">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_AGAMA_MURID"><?php echo $murid_view->AGAMA_MURID->caption() ?></span></td>
		<td data-name="AGAMA_MURID" <?php echo $murid_view->AGAMA_MURID->cellAttributes() ?>>
<span id="el_murid_AGAMA_MURID">
<span<?php echo $murid_view->AGAMA_MURID->viewAttributes() ?>><?php echo $murid_view->AGAMA_MURID->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->ALAMAT_RUMAH->Visible) { // ALAMAT_RUMAH ?>
	<tr id="r_ALAMAT_RUMAH">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_ALAMAT_RUMAH"><?php echo $murid_view->ALAMAT_RUMAH->caption() ?></span></td>
		<td data-name="ALAMAT_RUMAH" <?php echo $murid_view->ALAMAT_RUMAH->cellAttributes() ?>>
<span id="el_murid_ALAMAT_RUMAH">
<span<?php echo $murid_view->ALAMAT_RUMAH->viewAttributes() ?>><?php echo $murid_view->ALAMAT_RUMAH->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->TEMPATLAHIR->Visible) { // TEMPATLAHIR ?>
	<tr id="r_TEMPATLAHIR">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_TEMPATLAHIR"><?php echo $murid_view->TEMPATLAHIR->caption() ?></span></td>
		<td data-name="TEMPATLAHIR" <?php echo $murid_view->TEMPATLAHIR->cellAttributes() ?>>
<span id="el_murid_TEMPATLAHIR">
<span<?php echo $murid_view->TEMPATLAHIR->viewAttributes() ?>><?php echo $murid_view->TEMPATLAHIR->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->TGL_LAHIR->Visible) { // TGL_LAHIR ?>
	<tr id="r_TGL_LAHIR">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_TGL_LAHIR"><?php echo $murid_view->TGL_LAHIR->caption() ?></span></td>
		<td data-name="TGL_LAHIR" <?php echo $murid_view->TGL_LAHIR->cellAttributes() ?>>
<span id="el_murid_TGL_LAHIR">
<span<?php echo $murid_view->TGL_LAHIR->viewAttributes() ?>><?php echo $murid_view->TGL_LAHIR->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->NOHP->Visible) { // NOHP ?>
	<tr id="r_NOHP">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_NOHP"><?php echo $murid_view->NOHP->caption() ?></span></td>
		<td data-name="NOHP" <?php echo $murid_view->NOHP->cellAttributes() ?>>
<span id="el_murid_NOHP">
<span<?php echo $murid_view->NOHP->viewAttributes() ?>><?php echo $murid_view->NOHP->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->NOWA->Visible) { // NOWA ?>
	<tr id="r_NOWA">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_NOWA"><?php echo $murid_view->NOWA->caption() ?></span></td>
		<td data-name="NOWA" <?php echo $murid_view->NOWA->cellAttributes() ?>>
<span id="el_murid_NOWA">
<span<?php echo $murid_view->NOWA->viewAttributes() ?>><?php echo $murid_view->NOWA->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->IDTELEGRAM->Visible) { // IDTELEGRAM ?>
	<tr id="r_IDTELEGRAM">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_IDTELEGRAM"><?php echo $murid_view->IDTELEGRAM->caption() ?></span></td>
		<td data-name="IDTELEGRAM" <?php echo $murid_view->IDTELEGRAM->cellAttributes() ?>>
<span id="el_murid_IDTELEGRAM">
<span<?php echo $murid_view->IDTELEGRAM->viewAttributes() ?>><?php echo $murid_view->IDTELEGRAM->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->IDLINE->Visible) { // IDLINE ?>
	<tr id="r_IDLINE">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_IDLINE"><?php echo $murid_view->IDLINE->caption() ?></span></td>
		<td data-name="IDLINE" <?php echo $murid_view->IDLINE->cellAttributes() ?>>
<span id="el_murid_IDLINE">
<span<?php echo $murid_view->IDLINE->viewAttributes() ?>><?php echo $murid_view->IDLINE->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->IDFACEBOOK->Visible) { // IDFACEBOOK ?>
	<tr id="r_IDFACEBOOK">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_IDFACEBOOK"><?php echo $murid_view->IDFACEBOOK->caption() ?></span></td>
		<td data-name="IDFACEBOOK" <?php echo $murid_view->IDFACEBOOK->cellAttributes() ?>>
<span id="el_murid_IDFACEBOOK">
<span<?php echo $murid_view->IDFACEBOOK->viewAttributes() ?>><?php echo $murid_view->IDFACEBOOK->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->IDINSTAGRAM->Visible) { // IDINSTAGRAM ?>
	<tr id="r_IDINSTAGRAM">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_IDINSTAGRAM"><?php echo $murid_view->IDINSTAGRAM->caption() ?></span></td>
		<td data-name="IDINSTAGRAM" <?php echo $murid_view->IDINSTAGRAM->cellAttributes() ?>>
<span id="el_murid_IDINSTAGRAM">
<span<?php echo $murid_view->IDINSTAGRAM->viewAttributes() ?>><?php echo $murid_view->IDINSTAGRAM->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->IDTWITTER->Visible) { // IDTWITTER ?>
	<tr id="r_IDTWITTER">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_IDTWITTER"><?php echo $murid_view->IDTWITTER->caption() ?></span></td>
		<td data-name="IDTWITTER" <?php echo $murid_view->IDTWITTER->cellAttributes() ?>>
<span id="el_murid_IDTWITTER">
<span<?php echo $murid_view->IDTWITTER->viewAttributes() ?>><?php echo $murid_view->IDTWITTER->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->IDYOUTUBE->Visible) { // IDYOUTUBE ?>
	<tr id="r_IDYOUTUBE">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid_IDYOUTUBE"><?php echo $murid_view->IDYOUTUBE->caption() ?></span></td>
		<td data-name="IDYOUTUBE" <?php echo $murid_view->IDYOUTUBE->cellAttributes() ?>>
<span id="el_murid_IDYOUTUBE">
<span<?php echo $murid_view->IDYOUTUBE->viewAttributes() ?>><?php echo $murid_view->IDYOUTUBE->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($murid_view->_EMAIL->Visible) { // EMAIL ?>
	<tr id="r__EMAIL">
		<td class="<?php echo $murid_view->TableLeftColumnClass ?>"><span id="elh_murid__EMAIL"><?php echo $murid_view->_EMAIL->caption() ?></span></td>
		<td data-name="_EMAIL" <?php echo $murid_view->_EMAIL->cellAttributes() ?>>
<span id="el_murid__EMAIL">
<span<?php echo $murid_view->_EMAIL->viewAttributes() ?>><?php echo $murid_view->_EMAIL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$murid_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$murid_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$murid_view->terminate();
?>