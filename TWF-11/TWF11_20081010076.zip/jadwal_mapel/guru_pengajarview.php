<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$guru_pengajar_view = new guru_pengajar_view();

// Run the page
$guru_pengajar_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$guru_pengajar_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$guru_pengajar_view->isExport()) { ?>
<script>
var fguru_pengajarview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fguru_pengajarview = currentForm = new ew.Form("fguru_pengajarview", "view");
	loadjs.done("fguru_pengajarview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$guru_pengajar_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $guru_pengajar_view->ExportOptions->render("body") ?>
<?php $guru_pengajar_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $guru_pengajar_view->showPageHeader(); ?>
<?php
$guru_pengajar_view->showMessage();
?>
<form name="fguru_pengajarview" id="fguru_pengajarview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="guru_pengajar">
<input type="hidden" name="modal" value="<?php echo (int)$guru_pengajar_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($guru_pengajar_view->ID_GURU->Visible) { // ID_GURU ?>
	<tr id="r_ID_GURU">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_ID_GURU"><?php echo $guru_pengajar_view->ID_GURU->caption() ?></span></td>
		<td data-name="ID_GURU" <?php echo $guru_pengajar_view->ID_GURU->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_GURU">
<span<?php echo $guru_pengajar_view->ID_GURU->viewAttributes() ?>><?php echo $guru_pengajar_view->ID_GURU->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->NAMA_GURU->Visible) { // NAMA_GURU ?>
	<tr id="r_NAMA_GURU">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_NAMA_GURU"><?php echo $guru_pengajar_view->NAMA_GURU->caption() ?></span></td>
		<td data-name="NAMA_GURU" <?php echo $guru_pengajar_view->NAMA_GURU->cellAttributes() ?>>
<span id="el_guru_pengajar_NAMA_GURU">
<span<?php echo $guru_pengajar_view->NAMA_GURU->viewAttributes() ?>><?php echo $guru_pengajar_view->NAMA_GURU->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->GELAR_DEPAN->Visible) { // GELAR_DEPAN ?>
	<tr id="r_GELAR_DEPAN">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_GELAR_DEPAN"><?php echo $guru_pengajar_view->GELAR_DEPAN->caption() ?></span></td>
		<td data-name="GELAR_DEPAN" <?php echo $guru_pengajar_view->GELAR_DEPAN->cellAttributes() ?>>
<span id="el_guru_pengajar_GELAR_DEPAN">
<span<?php echo $guru_pengajar_view->GELAR_DEPAN->viewAttributes() ?>><?php echo $guru_pengajar_view->GELAR_DEPAN->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->GELAR_BELAKANG->Visible) { // GELAR_BELAKANG ?>
	<tr id="r_GELAR_BELAKANG">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_GELAR_BELAKANG"><?php echo $guru_pengajar_view->GELAR_BELAKANG->caption() ?></span></td>
		<td data-name="GELAR_BELAKANG" <?php echo $guru_pengajar_view->GELAR_BELAKANG->cellAttributes() ?>>
<span id="el_guru_pengajar_GELAR_BELAKANG">
<span<?php echo $guru_pengajar_view->GELAR_BELAKANG->viewAttributes() ?>><?php echo $guru_pengajar_view->GELAR_BELAKANG->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->JENIS_KELAMIN->Visible) { // JENIS_KELAMIN ?>
	<tr id="r_JENIS_KELAMIN">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_JENIS_KELAMIN"><?php echo $guru_pengajar_view->JENIS_KELAMIN->caption() ?></span></td>
		<td data-name="JENIS_KELAMIN" <?php echo $guru_pengajar_view->JENIS_KELAMIN->cellAttributes() ?>>
<span id="el_guru_pengajar_JENIS_KELAMIN">
<span<?php echo $guru_pengajar_view->JENIS_KELAMIN->viewAttributes() ?>><?php echo $guru_pengajar_view->JENIS_KELAMIN->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->AGAMA->Visible) { // AGAMA ?>
	<tr id="r_AGAMA">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_AGAMA"><?php echo $guru_pengajar_view->AGAMA->caption() ?></span></td>
		<td data-name="AGAMA" <?php echo $guru_pengajar_view->AGAMA->cellAttributes() ?>>
<span id="el_guru_pengajar_AGAMA">
<span<?php echo $guru_pengajar_view->AGAMA->viewAttributes() ?>><?php echo $guru_pengajar_view->AGAMA->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->ALAMAT_TINGGAL->Visible) { // ALAMAT_TINGGAL ?>
	<tr id="r_ALAMAT_TINGGAL">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_ALAMAT_TINGGAL"><?php echo $guru_pengajar_view->ALAMAT_TINGGAL->caption() ?></span></td>
		<td data-name="ALAMAT_TINGGAL" <?php echo $guru_pengajar_view->ALAMAT_TINGGAL->cellAttributes() ?>>
<span id="el_guru_pengajar_ALAMAT_TINGGAL">
<span<?php echo $guru_pengajar_view->ALAMAT_TINGGAL->viewAttributes() ?>><?php echo $guru_pengajar_view->ALAMAT_TINGGAL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->NO_HP->Visible) { // NO_HP ?>
	<tr id="r_NO_HP">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_NO_HP"><?php echo $guru_pengajar_view->NO_HP->caption() ?></span></td>
		<td data-name="NO_HP" <?php echo $guru_pengajar_view->NO_HP->cellAttributes() ?>>
<span id="el_guru_pengajar_NO_HP">
<span<?php echo $guru_pengajar_view->NO_HP->viewAttributes() ?>><?php echo $guru_pengajar_view->NO_HP->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->NO_WA->Visible) { // NO_WA ?>
	<tr id="r_NO_WA">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_NO_WA"><?php echo $guru_pengajar_view->NO_WA->caption() ?></span></td>
		<td data-name="NO_WA" <?php echo $guru_pengajar_view->NO_WA->cellAttributes() ?>>
<span id="el_guru_pengajar_NO_WA">
<span<?php echo $guru_pengajar_view->NO_WA->viewAttributes() ?>><?php echo $guru_pengajar_view->NO_WA->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->ID_TELEGRAM->Visible) { // ID_TELEGRAM ?>
	<tr id="r_ID_TELEGRAM">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_ID_TELEGRAM"><?php echo $guru_pengajar_view->ID_TELEGRAM->caption() ?></span></td>
		<td data-name="ID_TELEGRAM" <?php echo $guru_pengajar_view->ID_TELEGRAM->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_TELEGRAM">
<span<?php echo $guru_pengajar_view->ID_TELEGRAM->viewAttributes() ?>><?php echo $guru_pengajar_view->ID_TELEGRAM->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->ID_LINE->Visible) { // ID_LINE ?>
	<tr id="r_ID_LINE">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_ID_LINE"><?php echo $guru_pengajar_view->ID_LINE->caption() ?></span></td>
		<td data-name="ID_LINE" <?php echo $guru_pengajar_view->ID_LINE->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_LINE">
<span<?php echo $guru_pengajar_view->ID_LINE->viewAttributes() ?>><?php echo $guru_pengajar_view->ID_LINE->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->ID_FACEBOOK->Visible) { // ID_FACEBOOK ?>
	<tr id="r_ID_FACEBOOK">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_ID_FACEBOOK"><?php echo $guru_pengajar_view->ID_FACEBOOK->caption() ?></span></td>
		<td data-name="ID_FACEBOOK" <?php echo $guru_pengajar_view->ID_FACEBOOK->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_FACEBOOK">
<span<?php echo $guru_pengajar_view->ID_FACEBOOK->viewAttributes() ?>><?php echo $guru_pengajar_view->ID_FACEBOOK->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->ID_INSTAGRAM->Visible) { // ID_INSTAGRAM ?>
	<tr id="r_ID_INSTAGRAM">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_ID_INSTAGRAM"><?php echo $guru_pengajar_view->ID_INSTAGRAM->caption() ?></span></td>
		<td data-name="ID_INSTAGRAM" <?php echo $guru_pengajar_view->ID_INSTAGRAM->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_INSTAGRAM">
<span<?php echo $guru_pengajar_view->ID_INSTAGRAM->viewAttributes() ?>><?php echo $guru_pengajar_view->ID_INSTAGRAM->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->ID_TWITTER->Visible) { // ID_TWITTER ?>
	<tr id="r_ID_TWITTER">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_ID_TWITTER"><?php echo $guru_pengajar_view->ID_TWITTER->caption() ?></span></td>
		<td data-name="ID_TWITTER" <?php echo $guru_pengajar_view->ID_TWITTER->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_TWITTER">
<span<?php echo $guru_pengajar_view->ID_TWITTER->viewAttributes() ?>><?php echo $guru_pengajar_view->ID_TWITTER->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->ID_YOUTUBE->Visible) { // ID_YOUTUBE ?>
	<tr id="r_ID_YOUTUBE">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_ID_YOUTUBE"><?php echo $guru_pengajar_view->ID_YOUTUBE->caption() ?></span></td>
		<td data-name="ID_YOUTUBE" <?php echo $guru_pengajar_view->ID_YOUTUBE->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_YOUTUBE">
<span<?php echo $guru_pengajar_view->ID_YOUTUBE->viewAttributes() ?>><?php echo $guru_pengajar_view->ID_YOUTUBE->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->EMAIL_GURU->Visible) { // EMAIL_GURU ?>
	<tr id="r_EMAIL_GURU">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_EMAIL_GURU"><?php echo $guru_pengajar_view->EMAIL_GURU->caption() ?></span></td>
		<td data-name="EMAIL_GURU" <?php echo $guru_pengajar_view->EMAIL_GURU->cellAttributes() ?>>
<span id="el_guru_pengajar_EMAIL_GURU">
<span<?php echo $guru_pengajar_view->EMAIL_GURU->viewAttributes() ?>><?php echo $guru_pengajar_view->EMAIL_GURU->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->TEMPAT_LAHIR->Visible) { // TEMPAT_LAHIR ?>
	<tr id="r_TEMPAT_LAHIR">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_TEMPAT_LAHIR"><?php echo $guru_pengajar_view->TEMPAT_LAHIR->caption() ?></span></td>
		<td data-name="TEMPAT_LAHIR" <?php echo $guru_pengajar_view->TEMPAT_LAHIR->cellAttributes() ?>>
<span id="el_guru_pengajar_TEMPAT_LAHIR">
<span<?php echo $guru_pengajar_view->TEMPAT_LAHIR->viewAttributes() ?>><?php echo $guru_pengajar_view->TEMPAT_LAHIR->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($guru_pengajar_view->TANGGAL_LAHIR->Visible) { // TANGGAL_LAHIR ?>
	<tr id="r_TANGGAL_LAHIR">
		<td class="<?php echo $guru_pengajar_view->TableLeftColumnClass ?>"><span id="elh_guru_pengajar_TANGGAL_LAHIR"><?php echo $guru_pengajar_view->TANGGAL_LAHIR->caption() ?></span></td>
		<td data-name="TANGGAL_LAHIR" <?php echo $guru_pengajar_view->TANGGAL_LAHIR->cellAttributes() ?>>
<span id="el_guru_pengajar_TANGGAL_LAHIR">
<span<?php echo $guru_pengajar_view->TANGGAL_LAHIR->viewAttributes() ?>><?php echo $guru_pengajar_view->TANGGAL_LAHIR->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$guru_pengajar_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$guru_pengajar_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$guru_pengajar_view->terminate();
?>