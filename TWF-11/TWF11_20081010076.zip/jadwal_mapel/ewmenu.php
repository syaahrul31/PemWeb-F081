<?php
namespace PHPMaker2020\project1;

// Menu Language
if ($Language && function_exists(PROJECT_NAMESPACE . "Config") && $Language->LanguageFolder == Config("LANGUAGE_FOLDER")) {
	$MenuRelativePath = "";
	$MenuLanguage = &$Language;
} else { // Compat reports
	$LANGUAGE_FOLDER = "../lang/";
	$MenuRelativePath = "../";
	$MenuLanguage = new Language();
}

// Navbar menu
$topMenu = new Menu("navbar", TRUE, TRUE);
echo $topMenu->toScript();

// Sidebar menu
$sideMenu = new Menu("menu", TRUE, FALSE);
$sideMenu->addMenuItem(1, "mi_guru_pengajar", $MenuLanguage->MenuPhrase("1", "MenuText"), $MenuRelativePath . "guru_pengajarlist.php", -1, "", IsLoggedIn() || AllowListMenu('{6B4A168D-AFB7-4B2A-A9A9-04A7731AE34A}guru_pengajar'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(2, "mi_jadwal_pelajaran", $MenuLanguage->MenuPhrase("2", "MenuText"), $MenuRelativePath . "jadwal_pelajaranlist.php", -1, "", IsLoggedIn() || AllowListMenu('{6B4A168D-AFB7-4B2A-A9A9-04A7731AE34A}jadwal_pelajaran'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(3, "mi_mata_pelajaran", $MenuLanguage->MenuPhrase("3", "MenuText"), $MenuRelativePath . "mata_pelajaranlist.php", -1, "", IsLoggedIn() || AllowListMenu('{6B4A168D-AFB7-4B2A-A9A9-04A7731AE34A}mata_pelajaran'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(4, "mi_murid", $MenuLanguage->MenuPhrase("4", "MenuText"), $MenuRelativePath . "muridlist.php", -1, "", IsLoggedIn() || AllowListMenu('{6B4A168D-AFB7-4B2A-A9A9-04A7731AE34A}murid'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(5, "mi_ruang_kelas", $MenuLanguage->MenuPhrase("5", "MenuText"), $MenuRelativePath . "ruang_kelaslist.php", -1, "", IsLoggedIn() || AllowListMenu('{6B4A168D-AFB7-4B2A-A9A9-04A7731AE34A}ruang_kelas'), FALSE, FALSE, "", "", FALSE);
echo $sideMenu->toScript();
?>