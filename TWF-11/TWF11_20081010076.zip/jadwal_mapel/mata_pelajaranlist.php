<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$mata_pelajaran_list = new mata_pelajaran_list();

// Run the page
$mata_pelajaran_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$mata_pelajaran_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$mata_pelajaran_list->isExport()) { ?>
<script>
var fmata_pelajaranlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fmata_pelajaranlist = currentForm = new ew.Form("fmata_pelajaranlist", "list");
	fmata_pelajaranlist.formKeyCountName = '<?php echo $mata_pelajaran_list->FormKeyCountName ?>';
	loadjs.done("fmata_pelajaranlist");
});
var fmata_pelajaranlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fmata_pelajaranlistsrch = currentSearchForm = new ew.Form("fmata_pelajaranlistsrch");

	// Dynamic selection lists
	// Filters

	fmata_pelajaranlistsrch.filterList = <?php echo $mata_pelajaran_list->getFilterList() ?>;
	loadjs.done("fmata_pelajaranlistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$mata_pelajaran_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($mata_pelajaran_list->TotalRecords > 0 && $mata_pelajaran_list->ExportOptions->visible()) { ?>
<?php $mata_pelajaran_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($mata_pelajaran_list->ImportOptions->visible()) { ?>
<?php $mata_pelajaran_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($mata_pelajaran_list->SearchOptions->visible()) { ?>
<?php $mata_pelajaran_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($mata_pelajaran_list->FilterOptions->visible()) { ?>
<?php $mata_pelajaran_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$mata_pelajaran_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$mata_pelajaran_list->isExport() && !$mata_pelajaran->CurrentAction) { ?>
<form name="fmata_pelajaranlistsrch" id="fmata_pelajaranlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fmata_pelajaranlistsrch-search-panel" class="<?php echo $mata_pelajaran_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="mata_pelajaran">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $mata_pelajaran_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($mata_pelajaran_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($mata_pelajaran_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $mata_pelajaran_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($mata_pelajaran_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($mata_pelajaran_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($mata_pelajaran_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($mata_pelajaran_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $mata_pelajaran_list->showPageHeader(); ?>
<?php
$mata_pelajaran_list->showMessage();
?>
<?php if ($mata_pelajaran_list->TotalRecords > 0 || $mata_pelajaran->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($mata_pelajaran_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> mata_pelajaran">
<form name="fmata_pelajaranlist" id="fmata_pelajaranlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="mata_pelajaran">
<div id="gmp_mata_pelajaran" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($mata_pelajaran_list->TotalRecords > 0 || $mata_pelajaran_list->isGridEdit()) { ?>
<table id="tbl_mata_pelajaranlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$mata_pelajaran->RowType = ROWTYPE_HEADER;

// Render list options
$mata_pelajaran_list->renderListOptions();

// Render list options (header, left)
$mata_pelajaran_list->ListOptions->render("header", "left");
?>
<?php if ($mata_pelajaran_list->KODE_MAPEL->Visible) { // KODE_MAPEL ?>
	<?php if ($mata_pelajaran_list->SortUrl($mata_pelajaran_list->KODE_MAPEL) == "") { ?>
		<th data-name="KODE_MAPEL" class="<?php echo $mata_pelajaran_list->KODE_MAPEL->headerCellClass() ?>"><div id="elh_mata_pelajaran_KODE_MAPEL" class="mata_pelajaran_KODE_MAPEL"><div class="ew-table-header-caption"><?php echo $mata_pelajaran_list->KODE_MAPEL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="KODE_MAPEL" class="<?php echo $mata_pelajaran_list->KODE_MAPEL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $mata_pelajaran_list->SortUrl($mata_pelajaran_list->KODE_MAPEL) ?>', 1);"><div id="elh_mata_pelajaran_KODE_MAPEL" class="mata_pelajaran_KODE_MAPEL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mata_pelajaran_list->KODE_MAPEL->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($mata_pelajaran_list->KODE_MAPEL->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mata_pelajaran_list->KODE_MAPEL->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mata_pelajaran_list->NAMA_MAPEL->Visible) { // NAMA_MAPEL ?>
	<?php if ($mata_pelajaran_list->SortUrl($mata_pelajaran_list->NAMA_MAPEL) == "") { ?>
		<th data-name="NAMA_MAPEL" class="<?php echo $mata_pelajaran_list->NAMA_MAPEL->headerCellClass() ?>"><div id="elh_mata_pelajaran_NAMA_MAPEL" class="mata_pelajaran_NAMA_MAPEL"><div class="ew-table-header-caption"><?php echo $mata_pelajaran_list->NAMA_MAPEL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="NAMA_MAPEL" class="<?php echo $mata_pelajaran_list->NAMA_MAPEL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $mata_pelajaran_list->SortUrl($mata_pelajaran_list->NAMA_MAPEL) ?>', 1);"><div id="elh_mata_pelajaran_NAMA_MAPEL" class="mata_pelajaran_NAMA_MAPEL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mata_pelajaran_list->NAMA_MAPEL->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($mata_pelajaran_list->NAMA_MAPEL->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mata_pelajaran_list->NAMA_MAPEL->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mata_pelajaran_list->BIDANG_MAPEL->Visible) { // BIDANG_MAPEL ?>
	<?php if ($mata_pelajaran_list->SortUrl($mata_pelajaran_list->BIDANG_MAPEL) == "") { ?>
		<th data-name="BIDANG_MAPEL" class="<?php echo $mata_pelajaran_list->BIDANG_MAPEL->headerCellClass() ?>"><div id="elh_mata_pelajaran_BIDANG_MAPEL" class="mata_pelajaran_BIDANG_MAPEL"><div class="ew-table-header-caption"><?php echo $mata_pelajaran_list->BIDANG_MAPEL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="BIDANG_MAPEL" class="<?php echo $mata_pelajaran_list->BIDANG_MAPEL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $mata_pelajaran_list->SortUrl($mata_pelajaran_list->BIDANG_MAPEL) ?>', 1);"><div id="elh_mata_pelajaran_BIDANG_MAPEL" class="mata_pelajaran_BIDANG_MAPEL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mata_pelajaran_list->BIDANG_MAPEL->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($mata_pelajaran_list->BIDANG_MAPEL->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mata_pelajaran_list->BIDANG_MAPEL->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mata_pelajaran_list->JENIS_MAPEL->Visible) { // JENIS_MAPEL ?>
	<?php if ($mata_pelajaran_list->SortUrl($mata_pelajaran_list->JENIS_MAPEL) == "") { ?>
		<th data-name="JENIS_MAPEL" class="<?php echo $mata_pelajaran_list->JENIS_MAPEL->headerCellClass() ?>"><div id="elh_mata_pelajaran_JENIS_MAPEL" class="mata_pelajaran_JENIS_MAPEL"><div class="ew-table-header-caption"><?php echo $mata_pelajaran_list->JENIS_MAPEL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="JENIS_MAPEL" class="<?php echo $mata_pelajaran_list->JENIS_MAPEL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $mata_pelajaran_list->SortUrl($mata_pelajaran_list->JENIS_MAPEL) ?>', 1);"><div id="elh_mata_pelajaran_JENIS_MAPEL" class="mata_pelajaran_JENIS_MAPEL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mata_pelajaran_list->JENIS_MAPEL->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($mata_pelajaran_list->JENIS_MAPEL->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mata_pelajaran_list->JENIS_MAPEL->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mata_pelajaran_list->TIPE_MAPEL->Visible) { // TIPE_MAPEL ?>
	<?php if ($mata_pelajaran_list->SortUrl($mata_pelajaran_list->TIPE_MAPEL) == "") { ?>
		<th data-name="TIPE_MAPEL" class="<?php echo $mata_pelajaran_list->TIPE_MAPEL->headerCellClass() ?>"><div id="elh_mata_pelajaran_TIPE_MAPEL" class="mata_pelajaran_TIPE_MAPEL"><div class="ew-table-header-caption"><?php echo $mata_pelajaran_list->TIPE_MAPEL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TIPE_MAPEL" class="<?php echo $mata_pelajaran_list->TIPE_MAPEL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $mata_pelajaran_list->SortUrl($mata_pelajaran_list->TIPE_MAPEL) ?>', 1);"><div id="elh_mata_pelajaran_TIPE_MAPEL" class="mata_pelajaran_TIPE_MAPEL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mata_pelajaran_list->TIPE_MAPEL->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($mata_pelajaran_list->TIPE_MAPEL->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mata_pelajaran_list->TIPE_MAPEL->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mata_pelajaran_list->JUMLAH_PERTEMUAN->Visible) { // JUMLAH_PERTEMUAN ?>
	<?php if ($mata_pelajaran_list->SortUrl($mata_pelajaran_list->JUMLAH_PERTEMUAN) == "") { ?>
		<th data-name="JUMLAH_PERTEMUAN" class="<?php echo $mata_pelajaran_list->JUMLAH_PERTEMUAN->headerCellClass() ?>"><div id="elh_mata_pelajaran_JUMLAH_PERTEMUAN" class="mata_pelajaran_JUMLAH_PERTEMUAN"><div class="ew-table-header-caption"><?php echo $mata_pelajaran_list->JUMLAH_PERTEMUAN->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="JUMLAH_PERTEMUAN" class="<?php echo $mata_pelajaran_list->JUMLAH_PERTEMUAN->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $mata_pelajaran_list->SortUrl($mata_pelajaran_list->JUMLAH_PERTEMUAN) ?>', 1);"><div id="elh_mata_pelajaran_JUMLAH_PERTEMUAN" class="mata_pelajaran_JUMLAH_PERTEMUAN">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mata_pelajaran_list->JUMLAH_PERTEMUAN->caption() ?></span><span class="ew-table-header-sort"><?php if ($mata_pelajaran_list->JUMLAH_PERTEMUAN->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mata_pelajaran_list->JUMLAH_PERTEMUAN->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mata_pelajaran_list->DURASI_MAPEL->Visible) { // DURASI_MAPEL ?>
	<?php if ($mata_pelajaran_list->SortUrl($mata_pelajaran_list->DURASI_MAPEL) == "") { ?>
		<th data-name="DURASI_MAPEL" class="<?php echo $mata_pelajaran_list->DURASI_MAPEL->headerCellClass() ?>"><div id="elh_mata_pelajaran_DURASI_MAPEL" class="mata_pelajaran_DURASI_MAPEL"><div class="ew-table-header-caption"><?php echo $mata_pelajaran_list->DURASI_MAPEL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="DURASI_MAPEL" class="<?php echo $mata_pelajaran_list->DURASI_MAPEL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $mata_pelajaran_list->SortUrl($mata_pelajaran_list->DURASI_MAPEL) ?>', 1);"><div id="elh_mata_pelajaran_DURASI_MAPEL" class="mata_pelajaran_DURASI_MAPEL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mata_pelajaran_list->DURASI_MAPEL->caption() ?></span><span class="ew-table-header-sort"><?php if ($mata_pelajaran_list->DURASI_MAPEL->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mata_pelajaran_list->DURASI_MAPEL->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$mata_pelajaran_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($mata_pelajaran_list->ExportAll && $mata_pelajaran_list->isExport()) {
	$mata_pelajaran_list->StopRecord = $mata_pelajaran_list->TotalRecords;
} else {

	// Set the last record to display
	if ($mata_pelajaran_list->TotalRecords > $mata_pelajaran_list->StartRecord + $mata_pelajaran_list->DisplayRecords - 1)
		$mata_pelajaran_list->StopRecord = $mata_pelajaran_list->StartRecord + $mata_pelajaran_list->DisplayRecords - 1;
	else
		$mata_pelajaran_list->StopRecord = $mata_pelajaran_list->TotalRecords;
}
$mata_pelajaran_list->RecordCount = $mata_pelajaran_list->StartRecord - 1;
if ($mata_pelajaran_list->Recordset && !$mata_pelajaran_list->Recordset->EOF) {
	$mata_pelajaran_list->Recordset->moveFirst();
	$selectLimit = $mata_pelajaran_list->UseSelectLimit;
	if (!$selectLimit && $mata_pelajaran_list->StartRecord > 1)
		$mata_pelajaran_list->Recordset->move($mata_pelajaran_list->StartRecord - 1);
} elseif (!$mata_pelajaran->AllowAddDeleteRow && $mata_pelajaran_list->StopRecord == 0) {
	$mata_pelajaran_list->StopRecord = $mata_pelajaran->GridAddRowCount;
}

// Initialize aggregate
$mata_pelajaran->RowType = ROWTYPE_AGGREGATEINIT;
$mata_pelajaran->resetAttributes();
$mata_pelajaran_list->renderRow();
while ($mata_pelajaran_list->RecordCount < $mata_pelajaran_list->StopRecord) {
	$mata_pelajaran_list->RecordCount++;
	if ($mata_pelajaran_list->RecordCount >= $mata_pelajaran_list->StartRecord) {
		$mata_pelajaran_list->RowCount++;

		// Set up key count
		$mata_pelajaran_list->KeyCount = $mata_pelajaran_list->RowIndex;

		// Init row class and style
		$mata_pelajaran->resetAttributes();
		$mata_pelajaran->CssClass = "";
		if ($mata_pelajaran_list->isGridAdd()) {
		} else {
			$mata_pelajaran_list->loadRowValues($mata_pelajaran_list->Recordset); // Load row values
		}
		$mata_pelajaran->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$mata_pelajaran->RowAttrs->merge(["data-rowindex" => $mata_pelajaran_list->RowCount, "id" => "r" . $mata_pelajaran_list->RowCount . "_mata_pelajaran", "data-rowtype" => $mata_pelajaran->RowType]);

		// Render row
		$mata_pelajaran_list->renderRow();

		// Render list options
		$mata_pelajaran_list->renderListOptions();
?>
	<tr <?php echo $mata_pelajaran->rowAttributes() ?>>
<?php

// Render list options (body, left)
$mata_pelajaran_list->ListOptions->render("body", "left", $mata_pelajaran_list->RowCount);
?>
	<?php if ($mata_pelajaran_list->KODE_MAPEL->Visible) { // KODE_MAPEL ?>
		<td data-name="KODE_MAPEL" <?php echo $mata_pelajaran_list->KODE_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_list->RowCount ?>_mata_pelajaran_KODE_MAPEL">
<span<?php echo $mata_pelajaran_list->KODE_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_list->KODE_MAPEL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($mata_pelajaran_list->NAMA_MAPEL->Visible) { // NAMA_MAPEL ?>
		<td data-name="NAMA_MAPEL" <?php echo $mata_pelajaran_list->NAMA_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_list->RowCount ?>_mata_pelajaran_NAMA_MAPEL">
<span<?php echo $mata_pelajaran_list->NAMA_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_list->NAMA_MAPEL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($mata_pelajaran_list->BIDANG_MAPEL->Visible) { // BIDANG_MAPEL ?>
		<td data-name="BIDANG_MAPEL" <?php echo $mata_pelajaran_list->BIDANG_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_list->RowCount ?>_mata_pelajaran_BIDANG_MAPEL">
<span<?php echo $mata_pelajaran_list->BIDANG_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_list->BIDANG_MAPEL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($mata_pelajaran_list->JENIS_MAPEL->Visible) { // JENIS_MAPEL ?>
		<td data-name="JENIS_MAPEL" <?php echo $mata_pelajaran_list->JENIS_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_list->RowCount ?>_mata_pelajaran_JENIS_MAPEL">
<span<?php echo $mata_pelajaran_list->JENIS_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_list->JENIS_MAPEL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($mata_pelajaran_list->TIPE_MAPEL->Visible) { // TIPE_MAPEL ?>
		<td data-name="TIPE_MAPEL" <?php echo $mata_pelajaran_list->TIPE_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_list->RowCount ?>_mata_pelajaran_TIPE_MAPEL">
<span<?php echo $mata_pelajaran_list->TIPE_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_list->TIPE_MAPEL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($mata_pelajaran_list->JUMLAH_PERTEMUAN->Visible) { // JUMLAH_PERTEMUAN ?>
		<td data-name="JUMLAH_PERTEMUAN" <?php echo $mata_pelajaran_list->JUMLAH_PERTEMUAN->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_list->RowCount ?>_mata_pelajaran_JUMLAH_PERTEMUAN">
<span<?php echo $mata_pelajaran_list->JUMLAH_PERTEMUAN->viewAttributes() ?>><?php echo $mata_pelajaran_list->JUMLAH_PERTEMUAN->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($mata_pelajaran_list->DURASI_MAPEL->Visible) { // DURASI_MAPEL ?>
		<td data-name="DURASI_MAPEL" <?php echo $mata_pelajaran_list->DURASI_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_list->RowCount ?>_mata_pelajaran_DURASI_MAPEL">
<span<?php echo $mata_pelajaran_list->DURASI_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_list->DURASI_MAPEL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$mata_pelajaran_list->ListOptions->render("body", "right", $mata_pelajaran_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$mata_pelajaran_list->isGridAdd())
		$mata_pelajaran_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$mata_pelajaran->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($mata_pelajaran_list->Recordset)
	$mata_pelajaran_list->Recordset->Close();
?>
<?php if (!$mata_pelajaran_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$mata_pelajaran_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $mata_pelajaran_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $mata_pelajaran_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($mata_pelajaran_list->TotalRecords == 0 && !$mata_pelajaran->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $mata_pelajaran_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$mata_pelajaran_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$mata_pelajaran_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$mata_pelajaran_list->terminate();
?>