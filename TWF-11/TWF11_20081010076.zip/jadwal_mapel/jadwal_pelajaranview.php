<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$jadwal_pelajaran_view = new jadwal_pelajaran_view();

// Run the page
$jadwal_pelajaran_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$jadwal_pelajaran_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$jadwal_pelajaran_view->isExport()) { ?>
<script>
var fjadwal_pelajaranview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fjadwal_pelajaranview = currentForm = new ew.Form("fjadwal_pelajaranview", "view");
	loadjs.done("fjadwal_pelajaranview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$jadwal_pelajaran_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $jadwal_pelajaran_view->ExportOptions->render("body") ?>
<?php $jadwal_pelajaran_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $jadwal_pelajaran_view->showPageHeader(); ?>
<?php
$jadwal_pelajaran_view->showMessage();
?>
<form name="fjadwal_pelajaranview" id="fjadwal_pelajaranview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="jadwal_pelajaran">
<input type="hidden" name="modal" value="<?php echo (int)$jadwal_pelajaran_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($jadwal_pelajaran_view->IDJADWAL->Visible) { // IDJADWAL ?>
	<tr id="r_IDJADWAL">
		<td class="<?php echo $jadwal_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_jadwal_pelajaran_IDJADWAL"><?php echo $jadwal_pelajaran_view->IDJADWAL->caption() ?></span></td>
		<td data-name="IDJADWAL" <?php echo $jadwal_pelajaran_view->IDJADWAL->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_IDJADWAL">
<span<?php echo $jadwal_pelajaran_view->IDJADWAL->viewAttributes() ?>><?php echo $jadwal_pelajaran_view->IDJADWAL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($jadwal_pelajaran_view->ID_GURU->Visible) { // ID_GURU ?>
	<tr id="r_ID_GURU">
		<td class="<?php echo $jadwal_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_jadwal_pelajaran_ID_GURU"><?php echo $jadwal_pelajaran_view->ID_GURU->caption() ?></span></td>
		<td data-name="ID_GURU" <?php echo $jadwal_pelajaran_view->ID_GURU->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_ID_GURU">
<span<?php echo $jadwal_pelajaran_view->ID_GURU->viewAttributes() ?>><?php echo $jadwal_pelajaran_view->ID_GURU->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($jadwal_pelajaran_view->KODE_MAPEL->Visible) { // KODE_MAPEL ?>
	<tr id="r_KODE_MAPEL">
		<td class="<?php echo $jadwal_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_jadwal_pelajaran_KODE_MAPEL"><?php echo $jadwal_pelajaran_view->KODE_MAPEL->caption() ?></span></td>
		<td data-name="KODE_MAPEL" <?php echo $jadwal_pelajaran_view->KODE_MAPEL->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_KODE_MAPEL">
<span<?php echo $jadwal_pelajaran_view->KODE_MAPEL->viewAttributes() ?>><?php echo $jadwal_pelajaran_view->KODE_MAPEL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($jadwal_pelajaran_view->IDRUANG->Visible) { // IDRUANG ?>
	<tr id="r_IDRUANG">
		<td class="<?php echo $jadwal_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_jadwal_pelajaran_IDRUANG"><?php echo $jadwal_pelajaran_view->IDRUANG->caption() ?></span></td>
		<td data-name="IDRUANG" <?php echo $jadwal_pelajaran_view->IDRUANG->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_IDRUANG">
<span<?php echo $jadwal_pelajaran_view->IDRUANG->viewAttributes() ?>><?php echo $jadwal_pelajaran_view->IDRUANG->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($jadwal_pelajaran_view->NO_INDUK->Visible) { // NO_INDUK ?>
	<tr id="r_NO_INDUK">
		<td class="<?php echo $jadwal_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_jadwal_pelajaran_NO_INDUK"><?php echo $jadwal_pelajaran_view->NO_INDUK->caption() ?></span></td>
		<td data-name="NO_INDUK" <?php echo $jadwal_pelajaran_view->NO_INDUK->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_NO_INDUK">
<span<?php echo $jadwal_pelajaran_view->NO_INDUK->viewAttributes() ?>><?php echo $jadwal_pelajaran_view->NO_INDUK->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($jadwal_pelajaran_view->HARIJADWAL->Visible) { // HARIJADWAL ?>
	<tr id="r_HARIJADWAL">
		<td class="<?php echo $jadwal_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_jadwal_pelajaran_HARIJADWAL"><?php echo $jadwal_pelajaran_view->HARIJADWAL->caption() ?></span></td>
		<td data-name="HARIJADWAL" <?php echo $jadwal_pelajaran_view->HARIJADWAL->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_HARIJADWAL">
<span<?php echo $jadwal_pelajaran_view->HARIJADWAL->viewAttributes() ?>><?php echo $jadwal_pelajaran_view->HARIJADWAL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($jadwal_pelajaran_view->SESIJADWAL->Visible) { // SESIJADWAL ?>
	<tr id="r_SESIJADWAL">
		<td class="<?php echo $jadwal_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_jadwal_pelajaran_SESIJADWAL"><?php echo $jadwal_pelajaran_view->SESIJADWAL->caption() ?></span></td>
		<td data-name="SESIJADWAL" <?php echo $jadwal_pelajaran_view->SESIJADWAL->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_SESIJADWAL">
<span<?php echo $jadwal_pelajaran_view->SESIJADWAL->viewAttributes() ?>><?php echo $jadwal_pelajaran_view->SESIJADWAL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($jadwal_pelajaran_view->WAKTU_MULAI->Visible) { // WAKTU_MULAI ?>
	<tr id="r_WAKTU_MULAI">
		<td class="<?php echo $jadwal_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_jadwal_pelajaran_WAKTU_MULAI"><?php echo $jadwal_pelajaran_view->WAKTU_MULAI->caption() ?></span></td>
		<td data-name="WAKTU_MULAI" <?php echo $jadwal_pelajaran_view->WAKTU_MULAI->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_WAKTU_MULAI">
<span<?php echo $jadwal_pelajaran_view->WAKTU_MULAI->viewAttributes() ?>><?php echo $jadwal_pelajaran_view->WAKTU_MULAI->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($jadwal_pelajaran_view->WAKTU_SELESAI->Visible) { // WAKTU_SELESAI ?>
	<tr id="r_WAKTU_SELESAI">
		<td class="<?php echo $jadwal_pelajaran_view->TableLeftColumnClass ?>"><span id="elh_jadwal_pelajaran_WAKTU_SELESAI"><?php echo $jadwal_pelajaran_view->WAKTU_SELESAI->caption() ?></span></td>
		<td data-name="WAKTU_SELESAI" <?php echo $jadwal_pelajaran_view->WAKTU_SELESAI->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_WAKTU_SELESAI">
<span<?php echo $jadwal_pelajaran_view->WAKTU_SELESAI->viewAttributes() ?>><?php echo $jadwal_pelajaran_view->WAKTU_SELESAI->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$jadwal_pelajaran_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$jadwal_pelajaran_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$jadwal_pelajaran_view->terminate();
?>