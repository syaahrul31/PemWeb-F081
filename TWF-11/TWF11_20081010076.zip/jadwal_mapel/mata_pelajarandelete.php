<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$mata_pelajaran_delete = new mata_pelajaran_delete();

// Run the page
$mata_pelajaran_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$mata_pelajaran_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmata_pelajarandelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fmata_pelajarandelete = currentForm = new ew.Form("fmata_pelajarandelete", "delete");
	loadjs.done("fmata_pelajarandelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $mata_pelajaran_delete->showPageHeader(); ?>
<?php
$mata_pelajaran_delete->showMessage();
?>
<form name="fmata_pelajarandelete" id="fmata_pelajarandelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="mata_pelajaran">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($mata_pelajaran_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($mata_pelajaran_delete->KODE_MAPEL->Visible) { // KODE_MAPEL ?>
		<th class="<?php echo $mata_pelajaran_delete->KODE_MAPEL->headerCellClass() ?>"><span id="elh_mata_pelajaran_KODE_MAPEL" class="mata_pelajaran_KODE_MAPEL"><?php echo $mata_pelajaran_delete->KODE_MAPEL->caption() ?></span></th>
<?php } ?>
<?php if ($mata_pelajaran_delete->NAMA_MAPEL->Visible) { // NAMA_MAPEL ?>
		<th class="<?php echo $mata_pelajaran_delete->NAMA_MAPEL->headerCellClass() ?>"><span id="elh_mata_pelajaran_NAMA_MAPEL" class="mata_pelajaran_NAMA_MAPEL"><?php echo $mata_pelajaran_delete->NAMA_MAPEL->caption() ?></span></th>
<?php } ?>
<?php if ($mata_pelajaran_delete->BIDANG_MAPEL->Visible) { // BIDANG_MAPEL ?>
		<th class="<?php echo $mata_pelajaran_delete->BIDANG_MAPEL->headerCellClass() ?>"><span id="elh_mata_pelajaran_BIDANG_MAPEL" class="mata_pelajaran_BIDANG_MAPEL"><?php echo $mata_pelajaran_delete->BIDANG_MAPEL->caption() ?></span></th>
<?php } ?>
<?php if ($mata_pelajaran_delete->JENIS_MAPEL->Visible) { // JENIS_MAPEL ?>
		<th class="<?php echo $mata_pelajaran_delete->JENIS_MAPEL->headerCellClass() ?>"><span id="elh_mata_pelajaran_JENIS_MAPEL" class="mata_pelajaran_JENIS_MAPEL"><?php echo $mata_pelajaran_delete->JENIS_MAPEL->caption() ?></span></th>
<?php } ?>
<?php if ($mata_pelajaran_delete->TIPE_MAPEL->Visible) { // TIPE_MAPEL ?>
		<th class="<?php echo $mata_pelajaran_delete->TIPE_MAPEL->headerCellClass() ?>"><span id="elh_mata_pelajaran_TIPE_MAPEL" class="mata_pelajaran_TIPE_MAPEL"><?php echo $mata_pelajaran_delete->TIPE_MAPEL->caption() ?></span></th>
<?php } ?>
<?php if ($mata_pelajaran_delete->JUMLAH_PERTEMUAN->Visible) { // JUMLAH_PERTEMUAN ?>
		<th class="<?php echo $mata_pelajaran_delete->JUMLAH_PERTEMUAN->headerCellClass() ?>"><span id="elh_mata_pelajaran_JUMLAH_PERTEMUAN" class="mata_pelajaran_JUMLAH_PERTEMUAN"><?php echo $mata_pelajaran_delete->JUMLAH_PERTEMUAN->caption() ?></span></th>
<?php } ?>
<?php if ($mata_pelajaran_delete->DURASI_MAPEL->Visible) { // DURASI_MAPEL ?>
		<th class="<?php echo $mata_pelajaran_delete->DURASI_MAPEL->headerCellClass() ?>"><span id="elh_mata_pelajaran_DURASI_MAPEL" class="mata_pelajaran_DURASI_MAPEL"><?php echo $mata_pelajaran_delete->DURASI_MAPEL->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$mata_pelajaran_delete->RecordCount = 0;
$i = 0;
while (!$mata_pelajaran_delete->Recordset->EOF) {
	$mata_pelajaran_delete->RecordCount++;
	$mata_pelajaran_delete->RowCount++;

	// Set row properties
	$mata_pelajaran->resetAttributes();
	$mata_pelajaran->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$mata_pelajaran_delete->loadRowValues($mata_pelajaran_delete->Recordset);

	// Render row
	$mata_pelajaran_delete->renderRow();
?>
	<tr <?php echo $mata_pelajaran->rowAttributes() ?>>
<?php if ($mata_pelajaran_delete->KODE_MAPEL->Visible) { // KODE_MAPEL ?>
		<td <?php echo $mata_pelajaran_delete->KODE_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_delete->RowCount ?>_mata_pelajaran_KODE_MAPEL" class="mata_pelajaran_KODE_MAPEL">
<span<?php echo $mata_pelajaran_delete->KODE_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_delete->KODE_MAPEL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($mata_pelajaran_delete->NAMA_MAPEL->Visible) { // NAMA_MAPEL ?>
		<td <?php echo $mata_pelajaran_delete->NAMA_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_delete->RowCount ?>_mata_pelajaran_NAMA_MAPEL" class="mata_pelajaran_NAMA_MAPEL">
<span<?php echo $mata_pelajaran_delete->NAMA_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_delete->NAMA_MAPEL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($mata_pelajaran_delete->BIDANG_MAPEL->Visible) { // BIDANG_MAPEL ?>
		<td <?php echo $mata_pelajaran_delete->BIDANG_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_delete->RowCount ?>_mata_pelajaran_BIDANG_MAPEL" class="mata_pelajaran_BIDANG_MAPEL">
<span<?php echo $mata_pelajaran_delete->BIDANG_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_delete->BIDANG_MAPEL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($mata_pelajaran_delete->JENIS_MAPEL->Visible) { // JENIS_MAPEL ?>
		<td <?php echo $mata_pelajaran_delete->JENIS_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_delete->RowCount ?>_mata_pelajaran_JENIS_MAPEL" class="mata_pelajaran_JENIS_MAPEL">
<span<?php echo $mata_pelajaran_delete->JENIS_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_delete->JENIS_MAPEL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($mata_pelajaran_delete->TIPE_MAPEL->Visible) { // TIPE_MAPEL ?>
		<td <?php echo $mata_pelajaran_delete->TIPE_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_delete->RowCount ?>_mata_pelajaran_TIPE_MAPEL" class="mata_pelajaran_TIPE_MAPEL">
<span<?php echo $mata_pelajaran_delete->TIPE_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_delete->TIPE_MAPEL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($mata_pelajaran_delete->JUMLAH_PERTEMUAN->Visible) { // JUMLAH_PERTEMUAN ?>
		<td <?php echo $mata_pelajaran_delete->JUMLAH_PERTEMUAN->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_delete->RowCount ?>_mata_pelajaran_JUMLAH_PERTEMUAN" class="mata_pelajaran_JUMLAH_PERTEMUAN">
<span<?php echo $mata_pelajaran_delete->JUMLAH_PERTEMUAN->viewAttributes() ?>><?php echo $mata_pelajaran_delete->JUMLAH_PERTEMUAN->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($mata_pelajaran_delete->DURASI_MAPEL->Visible) { // DURASI_MAPEL ?>
		<td <?php echo $mata_pelajaran_delete->DURASI_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $mata_pelajaran_delete->RowCount ?>_mata_pelajaran_DURASI_MAPEL" class="mata_pelajaran_DURASI_MAPEL">
<span<?php echo $mata_pelajaran_delete->DURASI_MAPEL->viewAttributes() ?>><?php echo $mata_pelajaran_delete->DURASI_MAPEL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$mata_pelajaran_delete->Recordset->moveNext();
}
$mata_pelajaran_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $mata_pelajaran_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$mata_pelajaran_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$mata_pelajaran_delete->terminate();
?>