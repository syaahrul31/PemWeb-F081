<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$jadwal_pelajaran_list = new jadwal_pelajaran_list();

// Run the page
$jadwal_pelajaran_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$jadwal_pelajaran_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$jadwal_pelajaran_list->isExport()) { ?>
<script>
var fjadwal_pelajaranlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fjadwal_pelajaranlist = currentForm = new ew.Form("fjadwal_pelajaranlist", "list");
	fjadwal_pelajaranlist.formKeyCountName = '<?php echo $jadwal_pelajaran_list->FormKeyCountName ?>';
	loadjs.done("fjadwal_pelajaranlist");
});
var fjadwal_pelajaranlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fjadwal_pelajaranlistsrch = currentSearchForm = new ew.Form("fjadwal_pelajaranlistsrch");

	// Dynamic selection lists
	// Filters

	fjadwal_pelajaranlistsrch.filterList = <?php echo $jadwal_pelajaran_list->getFilterList() ?>;
	loadjs.done("fjadwal_pelajaranlistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$jadwal_pelajaran_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($jadwal_pelajaran_list->TotalRecords > 0 && $jadwal_pelajaran_list->ExportOptions->visible()) { ?>
<?php $jadwal_pelajaran_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($jadwal_pelajaran_list->ImportOptions->visible()) { ?>
<?php $jadwal_pelajaran_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($jadwal_pelajaran_list->SearchOptions->visible()) { ?>
<?php $jadwal_pelajaran_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($jadwal_pelajaran_list->FilterOptions->visible()) { ?>
<?php $jadwal_pelajaran_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$jadwal_pelajaran_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$jadwal_pelajaran_list->isExport() && !$jadwal_pelajaran->CurrentAction) { ?>
<form name="fjadwal_pelajaranlistsrch" id="fjadwal_pelajaranlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fjadwal_pelajaranlistsrch-search-panel" class="<?php echo $jadwal_pelajaran_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="jadwal_pelajaran">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $jadwal_pelajaran_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($jadwal_pelajaran_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($jadwal_pelajaran_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $jadwal_pelajaran_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($jadwal_pelajaran_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($jadwal_pelajaran_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($jadwal_pelajaran_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($jadwal_pelajaran_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $jadwal_pelajaran_list->showPageHeader(); ?>
<?php
$jadwal_pelajaran_list->showMessage();
?>
<?php if ($jadwal_pelajaran_list->TotalRecords > 0 || $jadwal_pelajaran->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($jadwal_pelajaran_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> jadwal_pelajaran">
<form name="fjadwal_pelajaranlist" id="fjadwal_pelajaranlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="jadwal_pelajaran">
<div id="gmp_jadwal_pelajaran" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($jadwal_pelajaran_list->TotalRecords > 0 || $jadwal_pelajaran_list->isGridEdit()) { ?>
<table id="tbl_jadwal_pelajaranlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$jadwal_pelajaran->RowType = ROWTYPE_HEADER;

// Render list options
$jadwal_pelajaran_list->renderListOptions();

// Render list options (header, left)
$jadwal_pelajaran_list->ListOptions->render("header", "left");
?>
<?php if ($jadwal_pelajaran_list->IDJADWAL->Visible) { // IDJADWAL ?>
	<?php if ($jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->IDJADWAL) == "") { ?>
		<th data-name="IDJADWAL" class="<?php echo $jadwal_pelajaran_list->IDJADWAL->headerCellClass() ?>"><div id="elh_jadwal_pelajaran_IDJADWAL" class="jadwal_pelajaran_IDJADWAL"><div class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->IDJADWAL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="IDJADWAL" class="<?php echo $jadwal_pelajaran_list->IDJADWAL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->IDJADWAL) ?>', 1);"><div id="elh_jadwal_pelajaran_IDJADWAL" class="jadwal_pelajaran_IDJADWAL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->IDJADWAL->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($jadwal_pelajaran_list->IDJADWAL->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($jadwal_pelajaran_list->IDJADWAL->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($jadwal_pelajaran_list->ID_GURU->Visible) { // ID_GURU ?>
	<?php if ($jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->ID_GURU) == "") { ?>
		<th data-name="ID_GURU" class="<?php echo $jadwal_pelajaran_list->ID_GURU->headerCellClass() ?>"><div id="elh_jadwal_pelajaran_ID_GURU" class="jadwal_pelajaran_ID_GURU"><div class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->ID_GURU->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ID_GURU" class="<?php echo $jadwal_pelajaran_list->ID_GURU->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->ID_GURU) ?>', 1);"><div id="elh_jadwal_pelajaran_ID_GURU" class="jadwal_pelajaran_ID_GURU">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->ID_GURU->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($jadwal_pelajaran_list->ID_GURU->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($jadwal_pelajaran_list->ID_GURU->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($jadwal_pelajaran_list->KODE_MAPEL->Visible) { // KODE_MAPEL ?>
	<?php if ($jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->KODE_MAPEL) == "") { ?>
		<th data-name="KODE_MAPEL" class="<?php echo $jadwal_pelajaran_list->KODE_MAPEL->headerCellClass() ?>"><div id="elh_jadwal_pelajaran_KODE_MAPEL" class="jadwal_pelajaran_KODE_MAPEL"><div class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->KODE_MAPEL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="KODE_MAPEL" class="<?php echo $jadwal_pelajaran_list->KODE_MAPEL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->KODE_MAPEL) ?>', 1);"><div id="elh_jadwal_pelajaran_KODE_MAPEL" class="jadwal_pelajaran_KODE_MAPEL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->KODE_MAPEL->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($jadwal_pelajaran_list->KODE_MAPEL->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($jadwal_pelajaran_list->KODE_MAPEL->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($jadwal_pelajaran_list->IDRUANG->Visible) { // IDRUANG ?>
	<?php if ($jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->IDRUANG) == "") { ?>
		<th data-name="IDRUANG" class="<?php echo $jadwal_pelajaran_list->IDRUANG->headerCellClass() ?>"><div id="elh_jadwal_pelajaran_IDRUANG" class="jadwal_pelajaran_IDRUANG"><div class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->IDRUANG->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="IDRUANG" class="<?php echo $jadwal_pelajaran_list->IDRUANG->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->IDRUANG) ?>', 1);"><div id="elh_jadwal_pelajaran_IDRUANG" class="jadwal_pelajaran_IDRUANG">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->IDRUANG->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($jadwal_pelajaran_list->IDRUANG->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($jadwal_pelajaran_list->IDRUANG->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($jadwal_pelajaran_list->NO_INDUK->Visible) { // NO_INDUK ?>
	<?php if ($jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->NO_INDUK) == "") { ?>
		<th data-name="NO_INDUK" class="<?php echo $jadwal_pelajaran_list->NO_INDUK->headerCellClass() ?>"><div id="elh_jadwal_pelajaran_NO_INDUK" class="jadwal_pelajaran_NO_INDUK"><div class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->NO_INDUK->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="NO_INDUK" class="<?php echo $jadwal_pelajaran_list->NO_INDUK->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->NO_INDUK) ?>', 1);"><div id="elh_jadwal_pelajaran_NO_INDUK" class="jadwal_pelajaran_NO_INDUK">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->NO_INDUK->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($jadwal_pelajaran_list->NO_INDUK->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($jadwal_pelajaran_list->NO_INDUK->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($jadwal_pelajaran_list->HARIJADWAL->Visible) { // HARIJADWAL ?>
	<?php if ($jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->HARIJADWAL) == "") { ?>
		<th data-name="HARIJADWAL" class="<?php echo $jadwal_pelajaran_list->HARIJADWAL->headerCellClass() ?>"><div id="elh_jadwal_pelajaran_HARIJADWAL" class="jadwal_pelajaran_HARIJADWAL"><div class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->HARIJADWAL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="HARIJADWAL" class="<?php echo $jadwal_pelajaran_list->HARIJADWAL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->HARIJADWAL) ?>', 1);"><div id="elh_jadwal_pelajaran_HARIJADWAL" class="jadwal_pelajaran_HARIJADWAL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->HARIJADWAL->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($jadwal_pelajaran_list->HARIJADWAL->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($jadwal_pelajaran_list->HARIJADWAL->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($jadwal_pelajaran_list->SESIJADWAL->Visible) { // SESIJADWAL ?>
	<?php if ($jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->SESIJADWAL) == "") { ?>
		<th data-name="SESIJADWAL" class="<?php echo $jadwal_pelajaran_list->SESIJADWAL->headerCellClass() ?>"><div id="elh_jadwal_pelajaran_SESIJADWAL" class="jadwal_pelajaran_SESIJADWAL"><div class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->SESIJADWAL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="SESIJADWAL" class="<?php echo $jadwal_pelajaran_list->SESIJADWAL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->SESIJADWAL) ?>', 1);"><div id="elh_jadwal_pelajaran_SESIJADWAL" class="jadwal_pelajaran_SESIJADWAL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->SESIJADWAL->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($jadwal_pelajaran_list->SESIJADWAL->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($jadwal_pelajaran_list->SESIJADWAL->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($jadwal_pelajaran_list->WAKTU_MULAI->Visible) { // WAKTU_MULAI ?>
	<?php if ($jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->WAKTU_MULAI) == "") { ?>
		<th data-name="WAKTU_MULAI" class="<?php echo $jadwal_pelajaran_list->WAKTU_MULAI->headerCellClass() ?>"><div id="elh_jadwal_pelajaran_WAKTU_MULAI" class="jadwal_pelajaran_WAKTU_MULAI"><div class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->WAKTU_MULAI->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="WAKTU_MULAI" class="<?php echo $jadwal_pelajaran_list->WAKTU_MULAI->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->WAKTU_MULAI) ?>', 1);"><div id="elh_jadwal_pelajaran_WAKTU_MULAI" class="jadwal_pelajaran_WAKTU_MULAI">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->WAKTU_MULAI->caption() ?></span><span class="ew-table-header-sort"><?php if ($jadwal_pelajaran_list->WAKTU_MULAI->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($jadwal_pelajaran_list->WAKTU_MULAI->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($jadwal_pelajaran_list->WAKTU_SELESAI->Visible) { // WAKTU_SELESAI ?>
	<?php if ($jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->WAKTU_SELESAI) == "") { ?>
		<th data-name="WAKTU_SELESAI" class="<?php echo $jadwal_pelajaran_list->WAKTU_SELESAI->headerCellClass() ?>"><div id="elh_jadwal_pelajaran_WAKTU_SELESAI" class="jadwal_pelajaran_WAKTU_SELESAI"><div class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->WAKTU_SELESAI->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="WAKTU_SELESAI" class="<?php echo $jadwal_pelajaran_list->WAKTU_SELESAI->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $jadwal_pelajaran_list->SortUrl($jadwal_pelajaran_list->WAKTU_SELESAI) ?>', 1);"><div id="elh_jadwal_pelajaran_WAKTU_SELESAI" class="jadwal_pelajaran_WAKTU_SELESAI">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $jadwal_pelajaran_list->WAKTU_SELESAI->caption() ?></span><span class="ew-table-header-sort"><?php if ($jadwal_pelajaran_list->WAKTU_SELESAI->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($jadwal_pelajaran_list->WAKTU_SELESAI->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$jadwal_pelajaran_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($jadwal_pelajaran_list->ExportAll && $jadwal_pelajaran_list->isExport()) {
	$jadwal_pelajaran_list->StopRecord = $jadwal_pelajaran_list->TotalRecords;
} else {

	// Set the last record to display
	if ($jadwal_pelajaran_list->TotalRecords > $jadwal_pelajaran_list->StartRecord + $jadwal_pelajaran_list->DisplayRecords - 1)
		$jadwal_pelajaran_list->StopRecord = $jadwal_pelajaran_list->StartRecord + $jadwal_pelajaran_list->DisplayRecords - 1;
	else
		$jadwal_pelajaran_list->StopRecord = $jadwal_pelajaran_list->TotalRecords;
}
$jadwal_pelajaran_list->RecordCount = $jadwal_pelajaran_list->StartRecord - 1;
if ($jadwal_pelajaran_list->Recordset && !$jadwal_pelajaran_list->Recordset->EOF) {
	$jadwal_pelajaran_list->Recordset->moveFirst();
	$selectLimit = $jadwal_pelajaran_list->UseSelectLimit;
	if (!$selectLimit && $jadwal_pelajaran_list->StartRecord > 1)
		$jadwal_pelajaran_list->Recordset->move($jadwal_pelajaran_list->StartRecord - 1);
} elseif (!$jadwal_pelajaran->AllowAddDeleteRow && $jadwal_pelajaran_list->StopRecord == 0) {
	$jadwal_pelajaran_list->StopRecord = $jadwal_pelajaran->GridAddRowCount;
}

// Initialize aggregate
$jadwal_pelajaran->RowType = ROWTYPE_AGGREGATEINIT;
$jadwal_pelajaran->resetAttributes();
$jadwal_pelajaran_list->renderRow();
while ($jadwal_pelajaran_list->RecordCount < $jadwal_pelajaran_list->StopRecord) {
	$jadwal_pelajaran_list->RecordCount++;
	if ($jadwal_pelajaran_list->RecordCount >= $jadwal_pelajaran_list->StartRecord) {
		$jadwal_pelajaran_list->RowCount++;

		// Set up key count
		$jadwal_pelajaran_list->KeyCount = $jadwal_pelajaran_list->RowIndex;

		// Init row class and style
		$jadwal_pelajaran->resetAttributes();
		$jadwal_pelajaran->CssClass = "";
		if ($jadwal_pelajaran_list->isGridAdd()) {
		} else {
			$jadwal_pelajaran_list->loadRowValues($jadwal_pelajaran_list->Recordset); // Load row values
		}
		$jadwal_pelajaran->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$jadwal_pelajaran->RowAttrs->merge(["data-rowindex" => $jadwal_pelajaran_list->RowCount, "id" => "r" . $jadwal_pelajaran_list->RowCount . "_jadwal_pelajaran", "data-rowtype" => $jadwal_pelajaran->RowType]);

		// Render row
		$jadwal_pelajaran_list->renderRow();

		// Render list options
		$jadwal_pelajaran_list->renderListOptions();
?>
	<tr <?php echo $jadwal_pelajaran->rowAttributes() ?>>
<?php

// Render list options (body, left)
$jadwal_pelajaran_list->ListOptions->render("body", "left", $jadwal_pelajaran_list->RowCount);
?>
	<?php if ($jadwal_pelajaran_list->IDJADWAL->Visible) { // IDJADWAL ?>
		<td data-name="IDJADWAL" <?php echo $jadwal_pelajaran_list->IDJADWAL->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_list->RowCount ?>_jadwal_pelajaran_IDJADWAL">
<span<?php echo $jadwal_pelajaran_list->IDJADWAL->viewAttributes() ?>><?php echo $jadwal_pelajaran_list->IDJADWAL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($jadwal_pelajaran_list->ID_GURU->Visible) { // ID_GURU ?>
		<td data-name="ID_GURU" <?php echo $jadwal_pelajaran_list->ID_GURU->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_list->RowCount ?>_jadwal_pelajaran_ID_GURU">
<span<?php echo $jadwal_pelajaran_list->ID_GURU->viewAttributes() ?>><?php echo $jadwal_pelajaran_list->ID_GURU->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($jadwal_pelajaran_list->KODE_MAPEL->Visible) { // KODE_MAPEL ?>
		<td data-name="KODE_MAPEL" <?php echo $jadwal_pelajaran_list->KODE_MAPEL->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_list->RowCount ?>_jadwal_pelajaran_KODE_MAPEL">
<span<?php echo $jadwal_pelajaran_list->KODE_MAPEL->viewAttributes() ?>><?php echo $jadwal_pelajaran_list->KODE_MAPEL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($jadwal_pelajaran_list->IDRUANG->Visible) { // IDRUANG ?>
		<td data-name="IDRUANG" <?php echo $jadwal_pelajaran_list->IDRUANG->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_list->RowCount ?>_jadwal_pelajaran_IDRUANG">
<span<?php echo $jadwal_pelajaran_list->IDRUANG->viewAttributes() ?>><?php echo $jadwal_pelajaran_list->IDRUANG->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($jadwal_pelajaran_list->NO_INDUK->Visible) { // NO_INDUK ?>
		<td data-name="NO_INDUK" <?php echo $jadwal_pelajaran_list->NO_INDUK->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_list->RowCount ?>_jadwal_pelajaran_NO_INDUK">
<span<?php echo $jadwal_pelajaran_list->NO_INDUK->viewAttributes() ?>><?php echo $jadwal_pelajaran_list->NO_INDUK->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($jadwal_pelajaran_list->HARIJADWAL->Visible) { // HARIJADWAL ?>
		<td data-name="HARIJADWAL" <?php echo $jadwal_pelajaran_list->HARIJADWAL->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_list->RowCount ?>_jadwal_pelajaran_HARIJADWAL">
<span<?php echo $jadwal_pelajaran_list->HARIJADWAL->viewAttributes() ?>><?php echo $jadwal_pelajaran_list->HARIJADWAL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($jadwal_pelajaran_list->SESIJADWAL->Visible) { // SESIJADWAL ?>
		<td data-name="SESIJADWAL" <?php echo $jadwal_pelajaran_list->SESIJADWAL->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_list->RowCount ?>_jadwal_pelajaran_SESIJADWAL">
<span<?php echo $jadwal_pelajaran_list->SESIJADWAL->viewAttributes() ?>><?php echo $jadwal_pelajaran_list->SESIJADWAL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($jadwal_pelajaran_list->WAKTU_MULAI->Visible) { // WAKTU_MULAI ?>
		<td data-name="WAKTU_MULAI" <?php echo $jadwal_pelajaran_list->WAKTU_MULAI->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_list->RowCount ?>_jadwal_pelajaran_WAKTU_MULAI">
<span<?php echo $jadwal_pelajaran_list->WAKTU_MULAI->viewAttributes() ?>><?php echo $jadwal_pelajaran_list->WAKTU_MULAI->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($jadwal_pelajaran_list->WAKTU_SELESAI->Visible) { // WAKTU_SELESAI ?>
		<td data-name="WAKTU_SELESAI" <?php echo $jadwal_pelajaran_list->WAKTU_SELESAI->cellAttributes() ?>>
<span id="el<?php echo $jadwal_pelajaran_list->RowCount ?>_jadwal_pelajaran_WAKTU_SELESAI">
<span<?php echo $jadwal_pelajaran_list->WAKTU_SELESAI->viewAttributes() ?>><?php echo $jadwal_pelajaran_list->WAKTU_SELESAI->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$jadwal_pelajaran_list->ListOptions->render("body", "right", $jadwal_pelajaran_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$jadwal_pelajaran_list->isGridAdd())
		$jadwal_pelajaran_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$jadwal_pelajaran->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($jadwal_pelajaran_list->Recordset)
	$jadwal_pelajaran_list->Recordset->Close();
?>
<?php if (!$jadwal_pelajaran_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$jadwal_pelajaran_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $jadwal_pelajaran_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $jadwal_pelajaran_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($jadwal_pelajaran_list->TotalRecords == 0 && !$jadwal_pelajaran->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $jadwal_pelajaran_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$jadwal_pelajaran_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$jadwal_pelajaran_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$jadwal_pelajaran_list->terminate();
?>