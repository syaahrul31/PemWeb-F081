<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$guru_pengajar_delete = new guru_pengajar_delete();

// Run the page
$guru_pengajar_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$guru_pengajar_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fguru_pengajardelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fguru_pengajardelete = currentForm = new ew.Form("fguru_pengajardelete", "delete");
	loadjs.done("fguru_pengajardelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $guru_pengajar_delete->showPageHeader(); ?>
<?php
$guru_pengajar_delete->showMessage();
?>
<form name="fguru_pengajardelete" id="fguru_pengajardelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="guru_pengajar">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($guru_pengajar_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($guru_pengajar_delete->ID_GURU->Visible) { // ID_GURU ?>
		<th class="<?php echo $guru_pengajar_delete->ID_GURU->headerCellClass() ?>"><span id="elh_guru_pengajar_ID_GURU" class="guru_pengajar_ID_GURU"><?php echo $guru_pengajar_delete->ID_GURU->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->NAMA_GURU->Visible) { // NAMA_GURU ?>
		<th class="<?php echo $guru_pengajar_delete->NAMA_GURU->headerCellClass() ?>"><span id="elh_guru_pengajar_NAMA_GURU" class="guru_pengajar_NAMA_GURU"><?php echo $guru_pengajar_delete->NAMA_GURU->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->GELAR_DEPAN->Visible) { // GELAR_DEPAN ?>
		<th class="<?php echo $guru_pengajar_delete->GELAR_DEPAN->headerCellClass() ?>"><span id="elh_guru_pengajar_GELAR_DEPAN" class="guru_pengajar_GELAR_DEPAN"><?php echo $guru_pengajar_delete->GELAR_DEPAN->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->GELAR_BELAKANG->Visible) { // GELAR_BELAKANG ?>
		<th class="<?php echo $guru_pengajar_delete->GELAR_BELAKANG->headerCellClass() ?>"><span id="elh_guru_pengajar_GELAR_BELAKANG" class="guru_pengajar_GELAR_BELAKANG"><?php echo $guru_pengajar_delete->GELAR_BELAKANG->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->JENIS_KELAMIN->Visible) { // JENIS_KELAMIN ?>
		<th class="<?php echo $guru_pengajar_delete->JENIS_KELAMIN->headerCellClass() ?>"><span id="elh_guru_pengajar_JENIS_KELAMIN" class="guru_pengajar_JENIS_KELAMIN"><?php echo $guru_pengajar_delete->JENIS_KELAMIN->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->AGAMA->Visible) { // AGAMA ?>
		<th class="<?php echo $guru_pengajar_delete->AGAMA->headerCellClass() ?>"><span id="elh_guru_pengajar_AGAMA" class="guru_pengajar_AGAMA"><?php echo $guru_pengajar_delete->AGAMA->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->ALAMAT_TINGGAL->Visible) { // ALAMAT_TINGGAL ?>
		<th class="<?php echo $guru_pengajar_delete->ALAMAT_TINGGAL->headerCellClass() ?>"><span id="elh_guru_pengajar_ALAMAT_TINGGAL" class="guru_pengajar_ALAMAT_TINGGAL"><?php echo $guru_pengajar_delete->ALAMAT_TINGGAL->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->NO_HP->Visible) { // NO_HP ?>
		<th class="<?php echo $guru_pengajar_delete->NO_HP->headerCellClass() ?>"><span id="elh_guru_pengajar_NO_HP" class="guru_pengajar_NO_HP"><?php echo $guru_pengajar_delete->NO_HP->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->NO_WA->Visible) { // NO_WA ?>
		<th class="<?php echo $guru_pengajar_delete->NO_WA->headerCellClass() ?>"><span id="elh_guru_pengajar_NO_WA" class="guru_pengajar_NO_WA"><?php echo $guru_pengajar_delete->NO_WA->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->ID_TELEGRAM->Visible) { // ID_TELEGRAM ?>
		<th class="<?php echo $guru_pengajar_delete->ID_TELEGRAM->headerCellClass() ?>"><span id="elh_guru_pengajar_ID_TELEGRAM" class="guru_pengajar_ID_TELEGRAM"><?php echo $guru_pengajar_delete->ID_TELEGRAM->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->ID_LINE->Visible) { // ID_LINE ?>
		<th class="<?php echo $guru_pengajar_delete->ID_LINE->headerCellClass() ?>"><span id="elh_guru_pengajar_ID_LINE" class="guru_pengajar_ID_LINE"><?php echo $guru_pengajar_delete->ID_LINE->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->ID_FACEBOOK->Visible) { // ID_FACEBOOK ?>
		<th class="<?php echo $guru_pengajar_delete->ID_FACEBOOK->headerCellClass() ?>"><span id="elh_guru_pengajar_ID_FACEBOOK" class="guru_pengajar_ID_FACEBOOK"><?php echo $guru_pengajar_delete->ID_FACEBOOK->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->ID_INSTAGRAM->Visible) { // ID_INSTAGRAM ?>
		<th class="<?php echo $guru_pengajar_delete->ID_INSTAGRAM->headerCellClass() ?>"><span id="elh_guru_pengajar_ID_INSTAGRAM" class="guru_pengajar_ID_INSTAGRAM"><?php echo $guru_pengajar_delete->ID_INSTAGRAM->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->ID_TWITTER->Visible) { // ID_TWITTER ?>
		<th class="<?php echo $guru_pengajar_delete->ID_TWITTER->headerCellClass() ?>"><span id="elh_guru_pengajar_ID_TWITTER" class="guru_pengajar_ID_TWITTER"><?php echo $guru_pengajar_delete->ID_TWITTER->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->ID_YOUTUBE->Visible) { // ID_YOUTUBE ?>
		<th class="<?php echo $guru_pengajar_delete->ID_YOUTUBE->headerCellClass() ?>"><span id="elh_guru_pengajar_ID_YOUTUBE" class="guru_pengajar_ID_YOUTUBE"><?php echo $guru_pengajar_delete->ID_YOUTUBE->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->EMAIL_GURU->Visible) { // EMAIL_GURU ?>
		<th class="<?php echo $guru_pengajar_delete->EMAIL_GURU->headerCellClass() ?>"><span id="elh_guru_pengajar_EMAIL_GURU" class="guru_pengajar_EMAIL_GURU"><?php echo $guru_pengajar_delete->EMAIL_GURU->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->TEMPAT_LAHIR->Visible) { // TEMPAT_LAHIR ?>
		<th class="<?php echo $guru_pengajar_delete->TEMPAT_LAHIR->headerCellClass() ?>"><span id="elh_guru_pengajar_TEMPAT_LAHIR" class="guru_pengajar_TEMPAT_LAHIR"><?php echo $guru_pengajar_delete->TEMPAT_LAHIR->caption() ?></span></th>
<?php } ?>
<?php if ($guru_pengajar_delete->TANGGAL_LAHIR->Visible) { // TANGGAL_LAHIR ?>
		<th class="<?php echo $guru_pengajar_delete->TANGGAL_LAHIR->headerCellClass() ?>"><span id="elh_guru_pengajar_TANGGAL_LAHIR" class="guru_pengajar_TANGGAL_LAHIR"><?php echo $guru_pengajar_delete->TANGGAL_LAHIR->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$guru_pengajar_delete->RecordCount = 0;
$i = 0;
while (!$guru_pengajar_delete->Recordset->EOF) {
	$guru_pengajar_delete->RecordCount++;
	$guru_pengajar_delete->RowCount++;

	// Set row properties
	$guru_pengajar->resetAttributes();
	$guru_pengajar->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$guru_pengajar_delete->loadRowValues($guru_pengajar_delete->Recordset);

	// Render row
	$guru_pengajar_delete->renderRow();
?>
	<tr <?php echo $guru_pengajar->rowAttributes() ?>>
<?php if ($guru_pengajar_delete->ID_GURU->Visible) { // ID_GURU ?>
		<td <?php echo $guru_pengajar_delete->ID_GURU->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_ID_GURU" class="guru_pengajar_ID_GURU">
<span<?php echo $guru_pengajar_delete->ID_GURU->viewAttributes() ?>><?php echo $guru_pengajar_delete->ID_GURU->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->NAMA_GURU->Visible) { // NAMA_GURU ?>
		<td <?php echo $guru_pengajar_delete->NAMA_GURU->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_NAMA_GURU" class="guru_pengajar_NAMA_GURU">
<span<?php echo $guru_pengajar_delete->NAMA_GURU->viewAttributes() ?>><?php echo $guru_pengajar_delete->NAMA_GURU->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->GELAR_DEPAN->Visible) { // GELAR_DEPAN ?>
		<td <?php echo $guru_pengajar_delete->GELAR_DEPAN->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_GELAR_DEPAN" class="guru_pengajar_GELAR_DEPAN">
<span<?php echo $guru_pengajar_delete->GELAR_DEPAN->viewAttributes() ?>><?php echo $guru_pengajar_delete->GELAR_DEPAN->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->GELAR_BELAKANG->Visible) { // GELAR_BELAKANG ?>
		<td <?php echo $guru_pengajar_delete->GELAR_BELAKANG->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_GELAR_BELAKANG" class="guru_pengajar_GELAR_BELAKANG">
<span<?php echo $guru_pengajar_delete->GELAR_BELAKANG->viewAttributes() ?>><?php echo $guru_pengajar_delete->GELAR_BELAKANG->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->JENIS_KELAMIN->Visible) { // JENIS_KELAMIN ?>
		<td <?php echo $guru_pengajar_delete->JENIS_KELAMIN->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_JENIS_KELAMIN" class="guru_pengajar_JENIS_KELAMIN">
<span<?php echo $guru_pengajar_delete->JENIS_KELAMIN->viewAttributes() ?>><?php echo $guru_pengajar_delete->JENIS_KELAMIN->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->AGAMA->Visible) { // AGAMA ?>
		<td <?php echo $guru_pengajar_delete->AGAMA->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_AGAMA" class="guru_pengajar_AGAMA">
<span<?php echo $guru_pengajar_delete->AGAMA->viewAttributes() ?>><?php echo $guru_pengajar_delete->AGAMA->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->ALAMAT_TINGGAL->Visible) { // ALAMAT_TINGGAL ?>
		<td <?php echo $guru_pengajar_delete->ALAMAT_TINGGAL->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_ALAMAT_TINGGAL" class="guru_pengajar_ALAMAT_TINGGAL">
<span<?php echo $guru_pengajar_delete->ALAMAT_TINGGAL->viewAttributes() ?>><?php echo $guru_pengajar_delete->ALAMAT_TINGGAL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->NO_HP->Visible) { // NO_HP ?>
		<td <?php echo $guru_pengajar_delete->NO_HP->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_NO_HP" class="guru_pengajar_NO_HP">
<span<?php echo $guru_pengajar_delete->NO_HP->viewAttributes() ?>><?php echo $guru_pengajar_delete->NO_HP->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->NO_WA->Visible) { // NO_WA ?>
		<td <?php echo $guru_pengajar_delete->NO_WA->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_NO_WA" class="guru_pengajar_NO_WA">
<span<?php echo $guru_pengajar_delete->NO_WA->viewAttributes() ?>><?php echo $guru_pengajar_delete->NO_WA->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->ID_TELEGRAM->Visible) { // ID_TELEGRAM ?>
		<td <?php echo $guru_pengajar_delete->ID_TELEGRAM->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_ID_TELEGRAM" class="guru_pengajar_ID_TELEGRAM">
<span<?php echo $guru_pengajar_delete->ID_TELEGRAM->viewAttributes() ?>><?php echo $guru_pengajar_delete->ID_TELEGRAM->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->ID_LINE->Visible) { // ID_LINE ?>
		<td <?php echo $guru_pengajar_delete->ID_LINE->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_ID_LINE" class="guru_pengajar_ID_LINE">
<span<?php echo $guru_pengajar_delete->ID_LINE->viewAttributes() ?>><?php echo $guru_pengajar_delete->ID_LINE->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->ID_FACEBOOK->Visible) { // ID_FACEBOOK ?>
		<td <?php echo $guru_pengajar_delete->ID_FACEBOOK->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_ID_FACEBOOK" class="guru_pengajar_ID_FACEBOOK">
<span<?php echo $guru_pengajar_delete->ID_FACEBOOK->viewAttributes() ?>><?php echo $guru_pengajar_delete->ID_FACEBOOK->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->ID_INSTAGRAM->Visible) { // ID_INSTAGRAM ?>
		<td <?php echo $guru_pengajar_delete->ID_INSTAGRAM->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_ID_INSTAGRAM" class="guru_pengajar_ID_INSTAGRAM">
<span<?php echo $guru_pengajar_delete->ID_INSTAGRAM->viewAttributes() ?>><?php echo $guru_pengajar_delete->ID_INSTAGRAM->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->ID_TWITTER->Visible) { // ID_TWITTER ?>
		<td <?php echo $guru_pengajar_delete->ID_TWITTER->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_ID_TWITTER" class="guru_pengajar_ID_TWITTER">
<span<?php echo $guru_pengajar_delete->ID_TWITTER->viewAttributes() ?>><?php echo $guru_pengajar_delete->ID_TWITTER->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->ID_YOUTUBE->Visible) { // ID_YOUTUBE ?>
		<td <?php echo $guru_pengajar_delete->ID_YOUTUBE->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_ID_YOUTUBE" class="guru_pengajar_ID_YOUTUBE">
<span<?php echo $guru_pengajar_delete->ID_YOUTUBE->viewAttributes() ?>><?php echo $guru_pengajar_delete->ID_YOUTUBE->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->EMAIL_GURU->Visible) { // EMAIL_GURU ?>
		<td <?php echo $guru_pengajar_delete->EMAIL_GURU->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_EMAIL_GURU" class="guru_pengajar_EMAIL_GURU">
<span<?php echo $guru_pengajar_delete->EMAIL_GURU->viewAttributes() ?>><?php echo $guru_pengajar_delete->EMAIL_GURU->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->TEMPAT_LAHIR->Visible) { // TEMPAT_LAHIR ?>
		<td <?php echo $guru_pengajar_delete->TEMPAT_LAHIR->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_TEMPAT_LAHIR" class="guru_pengajar_TEMPAT_LAHIR">
<span<?php echo $guru_pengajar_delete->TEMPAT_LAHIR->viewAttributes() ?>><?php echo $guru_pengajar_delete->TEMPAT_LAHIR->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($guru_pengajar_delete->TANGGAL_LAHIR->Visible) { // TANGGAL_LAHIR ?>
		<td <?php echo $guru_pengajar_delete->TANGGAL_LAHIR->cellAttributes() ?>>
<span id="el<?php echo $guru_pengajar_delete->RowCount ?>_guru_pengajar_TANGGAL_LAHIR" class="guru_pengajar_TANGGAL_LAHIR">
<span<?php echo $guru_pengajar_delete->TANGGAL_LAHIR->viewAttributes() ?>><?php echo $guru_pengajar_delete->TANGGAL_LAHIR->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$guru_pengajar_delete->Recordset->moveNext();
}
$guru_pengajar_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $guru_pengajar_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$guru_pengajar_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$guru_pengajar_delete->terminate();
?>