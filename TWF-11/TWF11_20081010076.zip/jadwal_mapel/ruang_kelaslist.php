<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$ruang_kelas_list = new ruang_kelas_list();

// Run the page
$ruang_kelas_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$ruang_kelas_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$ruang_kelas_list->isExport()) { ?>
<script>
var fruang_kelaslist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fruang_kelaslist = currentForm = new ew.Form("fruang_kelaslist", "list");
	fruang_kelaslist.formKeyCountName = '<?php echo $ruang_kelas_list->FormKeyCountName ?>';
	loadjs.done("fruang_kelaslist");
});
var fruang_kelaslistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fruang_kelaslistsrch = currentSearchForm = new ew.Form("fruang_kelaslistsrch");

	// Dynamic selection lists
	// Filters

	fruang_kelaslistsrch.filterList = <?php echo $ruang_kelas_list->getFilterList() ?>;
	loadjs.done("fruang_kelaslistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$ruang_kelas_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($ruang_kelas_list->TotalRecords > 0 && $ruang_kelas_list->ExportOptions->visible()) { ?>
<?php $ruang_kelas_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($ruang_kelas_list->ImportOptions->visible()) { ?>
<?php $ruang_kelas_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($ruang_kelas_list->SearchOptions->visible()) { ?>
<?php $ruang_kelas_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($ruang_kelas_list->FilterOptions->visible()) { ?>
<?php $ruang_kelas_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$ruang_kelas_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$ruang_kelas_list->isExport() && !$ruang_kelas->CurrentAction) { ?>
<form name="fruang_kelaslistsrch" id="fruang_kelaslistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fruang_kelaslistsrch-search-panel" class="<?php echo $ruang_kelas_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="ruang_kelas">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $ruang_kelas_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($ruang_kelas_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($ruang_kelas_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $ruang_kelas_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($ruang_kelas_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($ruang_kelas_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($ruang_kelas_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($ruang_kelas_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $ruang_kelas_list->showPageHeader(); ?>
<?php
$ruang_kelas_list->showMessage();
?>
<?php if ($ruang_kelas_list->TotalRecords > 0 || $ruang_kelas->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($ruang_kelas_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> ruang_kelas">
<form name="fruang_kelaslist" id="fruang_kelaslist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="ruang_kelas">
<div id="gmp_ruang_kelas" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($ruang_kelas_list->TotalRecords > 0 || $ruang_kelas_list->isGridEdit()) { ?>
<table id="tbl_ruang_kelaslist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$ruang_kelas->RowType = ROWTYPE_HEADER;

// Render list options
$ruang_kelas_list->renderListOptions();

// Render list options (header, left)
$ruang_kelas_list->ListOptions->render("header", "left");
?>
<?php if ($ruang_kelas_list->IDRUANG->Visible) { // IDRUANG ?>
	<?php if ($ruang_kelas_list->SortUrl($ruang_kelas_list->IDRUANG) == "") { ?>
		<th data-name="IDRUANG" class="<?php echo $ruang_kelas_list->IDRUANG->headerCellClass() ?>"><div id="elh_ruang_kelas_IDRUANG" class="ruang_kelas_IDRUANG"><div class="ew-table-header-caption"><?php echo $ruang_kelas_list->IDRUANG->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="IDRUANG" class="<?php echo $ruang_kelas_list->IDRUANG->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $ruang_kelas_list->SortUrl($ruang_kelas_list->IDRUANG) ?>', 1);"><div id="elh_ruang_kelas_IDRUANG" class="ruang_kelas_IDRUANG">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $ruang_kelas_list->IDRUANG->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($ruang_kelas_list->IDRUANG->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($ruang_kelas_list->IDRUANG->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($ruang_kelas_list->NAMA_RUANG->Visible) { // NAMA_RUANG ?>
	<?php if ($ruang_kelas_list->SortUrl($ruang_kelas_list->NAMA_RUANG) == "") { ?>
		<th data-name="NAMA_RUANG" class="<?php echo $ruang_kelas_list->NAMA_RUANG->headerCellClass() ?>"><div id="elh_ruang_kelas_NAMA_RUANG" class="ruang_kelas_NAMA_RUANG"><div class="ew-table-header-caption"><?php echo $ruang_kelas_list->NAMA_RUANG->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="NAMA_RUANG" class="<?php echo $ruang_kelas_list->NAMA_RUANG->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $ruang_kelas_list->SortUrl($ruang_kelas_list->NAMA_RUANG) ?>', 1);"><div id="elh_ruang_kelas_NAMA_RUANG" class="ruang_kelas_NAMA_RUANG">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $ruang_kelas_list->NAMA_RUANG->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($ruang_kelas_list->NAMA_RUANG->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($ruang_kelas_list->NAMA_RUANG->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($ruang_kelas_list->TIPE_RUANG->Visible) { // TIPE_RUANG ?>
	<?php if ($ruang_kelas_list->SortUrl($ruang_kelas_list->TIPE_RUANG) == "") { ?>
		<th data-name="TIPE_RUANG" class="<?php echo $ruang_kelas_list->TIPE_RUANG->headerCellClass() ?>"><div id="elh_ruang_kelas_TIPE_RUANG" class="ruang_kelas_TIPE_RUANG"><div class="ew-table-header-caption"><?php echo $ruang_kelas_list->TIPE_RUANG->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TIPE_RUANG" class="<?php echo $ruang_kelas_list->TIPE_RUANG->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $ruang_kelas_list->SortUrl($ruang_kelas_list->TIPE_RUANG) ?>', 1);"><div id="elh_ruang_kelas_TIPE_RUANG" class="ruang_kelas_TIPE_RUANG">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $ruang_kelas_list->TIPE_RUANG->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($ruang_kelas_list->TIPE_RUANG->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($ruang_kelas_list->TIPE_RUANG->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($ruang_kelas_list->UKURAN_RUANG->Visible) { // UKURAN_RUANG ?>
	<?php if ($ruang_kelas_list->SortUrl($ruang_kelas_list->UKURAN_RUANG) == "") { ?>
		<th data-name="UKURAN_RUANG" class="<?php echo $ruang_kelas_list->UKURAN_RUANG->headerCellClass() ?>"><div id="elh_ruang_kelas_UKURAN_RUANG" class="ruang_kelas_UKURAN_RUANG"><div class="ew-table-header-caption"><?php echo $ruang_kelas_list->UKURAN_RUANG->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="UKURAN_RUANG" class="<?php echo $ruang_kelas_list->UKURAN_RUANG->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $ruang_kelas_list->SortUrl($ruang_kelas_list->UKURAN_RUANG) ?>', 1);"><div id="elh_ruang_kelas_UKURAN_RUANG" class="ruang_kelas_UKURAN_RUANG">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $ruang_kelas_list->UKURAN_RUANG->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($ruang_kelas_list->UKURAN_RUANG->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($ruang_kelas_list->UKURAN_RUANG->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($ruang_kelas_list->KAPASITAS_RUANG->Visible) { // KAPASITAS_RUANG ?>
	<?php if ($ruang_kelas_list->SortUrl($ruang_kelas_list->KAPASITAS_RUANG) == "") { ?>
		<th data-name="KAPASITAS_RUANG" class="<?php echo $ruang_kelas_list->KAPASITAS_RUANG->headerCellClass() ?>"><div id="elh_ruang_kelas_KAPASITAS_RUANG" class="ruang_kelas_KAPASITAS_RUANG"><div class="ew-table-header-caption"><?php echo $ruang_kelas_list->KAPASITAS_RUANG->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="KAPASITAS_RUANG" class="<?php echo $ruang_kelas_list->KAPASITAS_RUANG->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $ruang_kelas_list->SortUrl($ruang_kelas_list->KAPASITAS_RUANG) ?>', 1);"><div id="elh_ruang_kelas_KAPASITAS_RUANG" class="ruang_kelas_KAPASITAS_RUANG">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $ruang_kelas_list->KAPASITAS_RUANG->caption() ?></span><span class="ew-table-header-sort"><?php if ($ruang_kelas_list->KAPASITAS_RUANG->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($ruang_kelas_list->KAPASITAS_RUANG->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($ruang_kelas_list->JUMLAH_MEJA->Visible) { // JUMLAH_MEJA ?>
	<?php if ($ruang_kelas_list->SortUrl($ruang_kelas_list->JUMLAH_MEJA) == "") { ?>
		<th data-name="JUMLAH_MEJA" class="<?php echo $ruang_kelas_list->JUMLAH_MEJA->headerCellClass() ?>"><div id="elh_ruang_kelas_JUMLAH_MEJA" class="ruang_kelas_JUMLAH_MEJA"><div class="ew-table-header-caption"><?php echo $ruang_kelas_list->JUMLAH_MEJA->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="JUMLAH_MEJA" class="<?php echo $ruang_kelas_list->JUMLAH_MEJA->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $ruang_kelas_list->SortUrl($ruang_kelas_list->JUMLAH_MEJA) ?>', 1);"><div id="elh_ruang_kelas_JUMLAH_MEJA" class="ruang_kelas_JUMLAH_MEJA">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $ruang_kelas_list->JUMLAH_MEJA->caption() ?></span><span class="ew-table-header-sort"><?php if ($ruang_kelas_list->JUMLAH_MEJA->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($ruang_kelas_list->JUMLAH_MEJA->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($ruang_kelas_list->JUMLAH_KURSI->Visible) { // JUMLAH_KURSI ?>
	<?php if ($ruang_kelas_list->SortUrl($ruang_kelas_list->JUMLAH_KURSI) == "") { ?>
		<th data-name="JUMLAH_KURSI" class="<?php echo $ruang_kelas_list->JUMLAH_KURSI->headerCellClass() ?>"><div id="elh_ruang_kelas_JUMLAH_KURSI" class="ruang_kelas_JUMLAH_KURSI"><div class="ew-table-header-caption"><?php echo $ruang_kelas_list->JUMLAH_KURSI->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="JUMLAH_KURSI" class="<?php echo $ruang_kelas_list->JUMLAH_KURSI->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $ruang_kelas_list->SortUrl($ruang_kelas_list->JUMLAH_KURSI) ?>', 1);"><div id="elh_ruang_kelas_JUMLAH_KURSI" class="ruang_kelas_JUMLAH_KURSI">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $ruang_kelas_list->JUMLAH_KURSI->caption() ?></span><span class="ew-table-header-sort"><?php if ($ruang_kelas_list->JUMLAH_KURSI->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($ruang_kelas_list->JUMLAH_KURSI->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($ruang_kelas_list->KETERANGAN_RUANG->Visible) { // KETERANGAN_RUANG ?>
	<?php if ($ruang_kelas_list->SortUrl($ruang_kelas_list->KETERANGAN_RUANG) == "") { ?>
		<th data-name="KETERANGAN_RUANG" class="<?php echo $ruang_kelas_list->KETERANGAN_RUANG->headerCellClass() ?>"><div id="elh_ruang_kelas_KETERANGAN_RUANG" class="ruang_kelas_KETERANGAN_RUANG"><div class="ew-table-header-caption"><?php echo $ruang_kelas_list->KETERANGAN_RUANG->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="KETERANGAN_RUANG" class="<?php echo $ruang_kelas_list->KETERANGAN_RUANG->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $ruang_kelas_list->SortUrl($ruang_kelas_list->KETERANGAN_RUANG) ?>', 1);"><div id="elh_ruang_kelas_KETERANGAN_RUANG" class="ruang_kelas_KETERANGAN_RUANG">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $ruang_kelas_list->KETERANGAN_RUANG->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($ruang_kelas_list->KETERANGAN_RUANG->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($ruang_kelas_list->KETERANGAN_RUANG->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($ruang_kelas_list->KELENGKAPAN_ALAT->Visible) { // KELENGKAPAN_ALAT ?>
	<?php if ($ruang_kelas_list->SortUrl($ruang_kelas_list->KELENGKAPAN_ALAT) == "") { ?>
		<th data-name="KELENGKAPAN_ALAT" class="<?php echo $ruang_kelas_list->KELENGKAPAN_ALAT->headerCellClass() ?>"><div id="elh_ruang_kelas_KELENGKAPAN_ALAT" class="ruang_kelas_KELENGKAPAN_ALAT"><div class="ew-table-header-caption"><?php echo $ruang_kelas_list->KELENGKAPAN_ALAT->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="KELENGKAPAN_ALAT" class="<?php echo $ruang_kelas_list->KELENGKAPAN_ALAT->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $ruang_kelas_list->SortUrl($ruang_kelas_list->KELENGKAPAN_ALAT) ?>', 1);"><div id="elh_ruang_kelas_KELENGKAPAN_ALAT" class="ruang_kelas_KELENGKAPAN_ALAT">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $ruang_kelas_list->KELENGKAPAN_ALAT->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($ruang_kelas_list->KELENGKAPAN_ALAT->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($ruang_kelas_list->KELENGKAPAN_ALAT->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($ruang_kelas_list->RENOVASI_TERAKHIR->Visible) { // RENOVASI_TERAKHIR ?>
	<?php if ($ruang_kelas_list->SortUrl($ruang_kelas_list->RENOVASI_TERAKHIR) == "") { ?>
		<th data-name="RENOVASI_TERAKHIR" class="<?php echo $ruang_kelas_list->RENOVASI_TERAKHIR->headerCellClass() ?>"><div id="elh_ruang_kelas_RENOVASI_TERAKHIR" class="ruang_kelas_RENOVASI_TERAKHIR"><div class="ew-table-header-caption"><?php echo $ruang_kelas_list->RENOVASI_TERAKHIR->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="RENOVASI_TERAKHIR" class="<?php echo $ruang_kelas_list->RENOVASI_TERAKHIR->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $ruang_kelas_list->SortUrl($ruang_kelas_list->RENOVASI_TERAKHIR) ?>', 1);"><div id="elh_ruang_kelas_RENOVASI_TERAKHIR" class="ruang_kelas_RENOVASI_TERAKHIR">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $ruang_kelas_list->RENOVASI_TERAKHIR->caption() ?></span><span class="ew-table-header-sort"><?php if ($ruang_kelas_list->RENOVASI_TERAKHIR->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($ruang_kelas_list->RENOVASI_TERAKHIR->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$ruang_kelas_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($ruang_kelas_list->ExportAll && $ruang_kelas_list->isExport()) {
	$ruang_kelas_list->StopRecord = $ruang_kelas_list->TotalRecords;
} else {

	// Set the last record to display
	if ($ruang_kelas_list->TotalRecords > $ruang_kelas_list->StartRecord + $ruang_kelas_list->DisplayRecords - 1)
		$ruang_kelas_list->StopRecord = $ruang_kelas_list->StartRecord + $ruang_kelas_list->DisplayRecords - 1;
	else
		$ruang_kelas_list->StopRecord = $ruang_kelas_list->TotalRecords;
}
$ruang_kelas_list->RecordCount = $ruang_kelas_list->StartRecord - 1;
if ($ruang_kelas_list->Recordset && !$ruang_kelas_list->Recordset->EOF) {
	$ruang_kelas_list->Recordset->moveFirst();
	$selectLimit = $ruang_kelas_list->UseSelectLimit;
	if (!$selectLimit && $ruang_kelas_list->StartRecord > 1)
		$ruang_kelas_list->Recordset->move($ruang_kelas_list->StartRecord - 1);
} elseif (!$ruang_kelas->AllowAddDeleteRow && $ruang_kelas_list->StopRecord == 0) {
	$ruang_kelas_list->StopRecord = $ruang_kelas->GridAddRowCount;
}

// Initialize aggregate
$ruang_kelas->RowType = ROWTYPE_AGGREGATEINIT;
$ruang_kelas->resetAttributes();
$ruang_kelas_list->renderRow();
while ($ruang_kelas_list->RecordCount < $ruang_kelas_list->StopRecord) {
	$ruang_kelas_list->RecordCount++;
	if ($ruang_kelas_list->RecordCount >= $ruang_kelas_list->StartRecord) {
		$ruang_kelas_list->RowCount++;

		// Set up key count
		$ruang_kelas_list->KeyCount = $ruang_kelas_list->RowIndex;

		// Init row class and style
		$ruang_kelas->resetAttributes();
		$ruang_kelas->CssClass = "";
		if ($ruang_kelas_list->isGridAdd()) {
		} else {
			$ruang_kelas_list->loadRowValues($ruang_kelas_list->Recordset); // Load row values
		}
		$ruang_kelas->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$ruang_kelas->RowAttrs->merge(["data-rowindex" => $ruang_kelas_list->RowCount, "id" => "r" . $ruang_kelas_list->RowCount . "_ruang_kelas", "data-rowtype" => $ruang_kelas->RowType]);

		// Render row
		$ruang_kelas_list->renderRow();

		// Render list options
		$ruang_kelas_list->renderListOptions();
?>
	<tr <?php echo $ruang_kelas->rowAttributes() ?>>
<?php

// Render list options (body, left)
$ruang_kelas_list->ListOptions->render("body", "left", $ruang_kelas_list->RowCount);
?>
	<?php if ($ruang_kelas_list->IDRUANG->Visible) { // IDRUANG ?>
		<td data-name="IDRUANG" <?php echo $ruang_kelas_list->IDRUANG->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_list->RowCount ?>_ruang_kelas_IDRUANG">
<span<?php echo $ruang_kelas_list->IDRUANG->viewAttributes() ?>><?php echo $ruang_kelas_list->IDRUANG->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($ruang_kelas_list->NAMA_RUANG->Visible) { // NAMA_RUANG ?>
		<td data-name="NAMA_RUANG" <?php echo $ruang_kelas_list->NAMA_RUANG->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_list->RowCount ?>_ruang_kelas_NAMA_RUANG">
<span<?php echo $ruang_kelas_list->NAMA_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_list->NAMA_RUANG->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($ruang_kelas_list->TIPE_RUANG->Visible) { // TIPE_RUANG ?>
		<td data-name="TIPE_RUANG" <?php echo $ruang_kelas_list->TIPE_RUANG->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_list->RowCount ?>_ruang_kelas_TIPE_RUANG">
<span<?php echo $ruang_kelas_list->TIPE_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_list->TIPE_RUANG->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($ruang_kelas_list->UKURAN_RUANG->Visible) { // UKURAN_RUANG ?>
		<td data-name="UKURAN_RUANG" <?php echo $ruang_kelas_list->UKURAN_RUANG->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_list->RowCount ?>_ruang_kelas_UKURAN_RUANG">
<span<?php echo $ruang_kelas_list->UKURAN_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_list->UKURAN_RUANG->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($ruang_kelas_list->KAPASITAS_RUANG->Visible) { // KAPASITAS_RUANG ?>
		<td data-name="KAPASITAS_RUANG" <?php echo $ruang_kelas_list->KAPASITAS_RUANG->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_list->RowCount ?>_ruang_kelas_KAPASITAS_RUANG">
<span<?php echo $ruang_kelas_list->KAPASITAS_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_list->KAPASITAS_RUANG->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($ruang_kelas_list->JUMLAH_MEJA->Visible) { // JUMLAH_MEJA ?>
		<td data-name="JUMLAH_MEJA" <?php echo $ruang_kelas_list->JUMLAH_MEJA->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_list->RowCount ?>_ruang_kelas_JUMLAH_MEJA">
<span<?php echo $ruang_kelas_list->JUMLAH_MEJA->viewAttributes() ?>><?php echo $ruang_kelas_list->JUMLAH_MEJA->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($ruang_kelas_list->JUMLAH_KURSI->Visible) { // JUMLAH_KURSI ?>
		<td data-name="JUMLAH_KURSI" <?php echo $ruang_kelas_list->JUMLAH_KURSI->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_list->RowCount ?>_ruang_kelas_JUMLAH_KURSI">
<span<?php echo $ruang_kelas_list->JUMLAH_KURSI->viewAttributes() ?>><?php echo $ruang_kelas_list->JUMLAH_KURSI->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($ruang_kelas_list->KETERANGAN_RUANG->Visible) { // KETERANGAN_RUANG ?>
		<td data-name="KETERANGAN_RUANG" <?php echo $ruang_kelas_list->KETERANGAN_RUANG->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_list->RowCount ?>_ruang_kelas_KETERANGAN_RUANG">
<span<?php echo $ruang_kelas_list->KETERANGAN_RUANG->viewAttributes() ?>><?php echo $ruang_kelas_list->KETERANGAN_RUANG->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($ruang_kelas_list->KELENGKAPAN_ALAT->Visible) { // KELENGKAPAN_ALAT ?>
		<td data-name="KELENGKAPAN_ALAT" <?php echo $ruang_kelas_list->KELENGKAPAN_ALAT->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_list->RowCount ?>_ruang_kelas_KELENGKAPAN_ALAT">
<span<?php echo $ruang_kelas_list->KELENGKAPAN_ALAT->viewAttributes() ?>><?php echo $ruang_kelas_list->KELENGKAPAN_ALAT->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($ruang_kelas_list->RENOVASI_TERAKHIR->Visible) { // RENOVASI_TERAKHIR ?>
		<td data-name="RENOVASI_TERAKHIR" <?php echo $ruang_kelas_list->RENOVASI_TERAKHIR->cellAttributes() ?>>
<span id="el<?php echo $ruang_kelas_list->RowCount ?>_ruang_kelas_RENOVASI_TERAKHIR">
<span<?php echo $ruang_kelas_list->RENOVASI_TERAKHIR->viewAttributes() ?>><?php echo $ruang_kelas_list->RENOVASI_TERAKHIR->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$ruang_kelas_list->ListOptions->render("body", "right", $ruang_kelas_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$ruang_kelas_list->isGridAdd())
		$ruang_kelas_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$ruang_kelas->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($ruang_kelas_list->Recordset)
	$ruang_kelas_list->Recordset->Close();
?>
<?php if (!$ruang_kelas_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$ruang_kelas_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $ruang_kelas_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $ruang_kelas_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($ruang_kelas_list->TotalRecords == 0 && !$ruang_kelas->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $ruang_kelas_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$ruang_kelas_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$ruang_kelas_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$ruang_kelas_list->terminate();
?>