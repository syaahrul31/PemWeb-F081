<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$murid_delete = new murid_delete();

// Run the page
$murid_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$murid_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmuriddelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fmuriddelete = currentForm = new ew.Form("fmuriddelete", "delete");
	loadjs.done("fmuriddelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $murid_delete->showPageHeader(); ?>
<?php
$murid_delete->showMessage();
?>
<form name="fmuriddelete" id="fmuriddelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="murid">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($murid_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($murid_delete->NO_INDUK->Visible) { // NO_INDUK ?>
		<th class="<?php echo $murid_delete->NO_INDUK->headerCellClass() ?>"><span id="elh_murid_NO_INDUK" class="murid_NO_INDUK"><?php echo $murid_delete->NO_INDUK->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->NAMA_MURID->Visible) { // NAMA_MURID ?>
		<th class="<?php echo $murid_delete->NAMA_MURID->headerCellClass() ?>"><span id="elh_murid_NAMA_MURID" class="murid_NAMA_MURID"><?php echo $murid_delete->NAMA_MURID->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->JEN_KEL->Visible) { // JEN_KEL ?>
		<th class="<?php echo $murid_delete->JEN_KEL->headerCellClass() ?>"><span id="elh_murid_JEN_KEL" class="murid_JEN_KEL"><?php echo $murid_delete->JEN_KEL->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->AGAMA_MURID->Visible) { // AGAMA_MURID ?>
		<th class="<?php echo $murid_delete->AGAMA_MURID->headerCellClass() ?>"><span id="elh_murid_AGAMA_MURID" class="murid_AGAMA_MURID"><?php echo $murid_delete->AGAMA_MURID->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->ALAMAT_RUMAH->Visible) { // ALAMAT_RUMAH ?>
		<th class="<?php echo $murid_delete->ALAMAT_RUMAH->headerCellClass() ?>"><span id="elh_murid_ALAMAT_RUMAH" class="murid_ALAMAT_RUMAH"><?php echo $murid_delete->ALAMAT_RUMAH->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->TEMPATLAHIR->Visible) { // TEMPATLAHIR ?>
		<th class="<?php echo $murid_delete->TEMPATLAHIR->headerCellClass() ?>"><span id="elh_murid_TEMPATLAHIR" class="murid_TEMPATLAHIR"><?php echo $murid_delete->TEMPATLAHIR->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->TGL_LAHIR->Visible) { // TGL_LAHIR ?>
		<th class="<?php echo $murid_delete->TGL_LAHIR->headerCellClass() ?>"><span id="elh_murid_TGL_LAHIR" class="murid_TGL_LAHIR"><?php echo $murid_delete->TGL_LAHIR->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->NOHP->Visible) { // NOHP ?>
		<th class="<?php echo $murid_delete->NOHP->headerCellClass() ?>"><span id="elh_murid_NOHP" class="murid_NOHP"><?php echo $murid_delete->NOHP->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->NOWA->Visible) { // NOWA ?>
		<th class="<?php echo $murid_delete->NOWA->headerCellClass() ?>"><span id="elh_murid_NOWA" class="murid_NOWA"><?php echo $murid_delete->NOWA->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->IDTELEGRAM->Visible) { // IDTELEGRAM ?>
		<th class="<?php echo $murid_delete->IDTELEGRAM->headerCellClass() ?>"><span id="elh_murid_IDTELEGRAM" class="murid_IDTELEGRAM"><?php echo $murid_delete->IDTELEGRAM->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->IDLINE->Visible) { // IDLINE ?>
		<th class="<?php echo $murid_delete->IDLINE->headerCellClass() ?>"><span id="elh_murid_IDLINE" class="murid_IDLINE"><?php echo $murid_delete->IDLINE->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->IDFACEBOOK->Visible) { // IDFACEBOOK ?>
		<th class="<?php echo $murid_delete->IDFACEBOOK->headerCellClass() ?>"><span id="elh_murid_IDFACEBOOK" class="murid_IDFACEBOOK"><?php echo $murid_delete->IDFACEBOOK->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->IDINSTAGRAM->Visible) { // IDINSTAGRAM ?>
		<th class="<?php echo $murid_delete->IDINSTAGRAM->headerCellClass() ?>"><span id="elh_murid_IDINSTAGRAM" class="murid_IDINSTAGRAM"><?php echo $murid_delete->IDINSTAGRAM->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->IDTWITTER->Visible) { // IDTWITTER ?>
		<th class="<?php echo $murid_delete->IDTWITTER->headerCellClass() ?>"><span id="elh_murid_IDTWITTER" class="murid_IDTWITTER"><?php echo $murid_delete->IDTWITTER->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->IDYOUTUBE->Visible) { // IDYOUTUBE ?>
		<th class="<?php echo $murid_delete->IDYOUTUBE->headerCellClass() ?>"><span id="elh_murid_IDYOUTUBE" class="murid_IDYOUTUBE"><?php echo $murid_delete->IDYOUTUBE->caption() ?></span></th>
<?php } ?>
<?php if ($murid_delete->_EMAIL->Visible) { // EMAIL ?>
		<th class="<?php echo $murid_delete->_EMAIL->headerCellClass() ?>"><span id="elh_murid__EMAIL" class="murid__EMAIL"><?php echo $murid_delete->_EMAIL->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$murid_delete->RecordCount = 0;
$i = 0;
while (!$murid_delete->Recordset->EOF) {
	$murid_delete->RecordCount++;
	$murid_delete->RowCount++;

	// Set row properties
	$murid->resetAttributes();
	$murid->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$murid_delete->loadRowValues($murid_delete->Recordset);

	// Render row
	$murid_delete->renderRow();
?>
	<tr <?php echo $murid->rowAttributes() ?>>
<?php if ($murid_delete->NO_INDUK->Visible) { // NO_INDUK ?>
		<td <?php echo $murid_delete->NO_INDUK->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_NO_INDUK" class="murid_NO_INDUK">
<span<?php echo $murid_delete->NO_INDUK->viewAttributes() ?>><?php echo $murid_delete->NO_INDUK->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->NAMA_MURID->Visible) { // NAMA_MURID ?>
		<td <?php echo $murid_delete->NAMA_MURID->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_NAMA_MURID" class="murid_NAMA_MURID">
<span<?php echo $murid_delete->NAMA_MURID->viewAttributes() ?>><?php echo $murid_delete->NAMA_MURID->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->JEN_KEL->Visible) { // JEN_KEL ?>
		<td <?php echo $murid_delete->JEN_KEL->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_JEN_KEL" class="murid_JEN_KEL">
<span<?php echo $murid_delete->JEN_KEL->viewAttributes() ?>><?php echo $murid_delete->JEN_KEL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->AGAMA_MURID->Visible) { // AGAMA_MURID ?>
		<td <?php echo $murid_delete->AGAMA_MURID->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_AGAMA_MURID" class="murid_AGAMA_MURID">
<span<?php echo $murid_delete->AGAMA_MURID->viewAttributes() ?>><?php echo $murid_delete->AGAMA_MURID->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->ALAMAT_RUMAH->Visible) { // ALAMAT_RUMAH ?>
		<td <?php echo $murid_delete->ALAMAT_RUMAH->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_ALAMAT_RUMAH" class="murid_ALAMAT_RUMAH">
<span<?php echo $murid_delete->ALAMAT_RUMAH->viewAttributes() ?>><?php echo $murid_delete->ALAMAT_RUMAH->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->TEMPATLAHIR->Visible) { // TEMPATLAHIR ?>
		<td <?php echo $murid_delete->TEMPATLAHIR->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_TEMPATLAHIR" class="murid_TEMPATLAHIR">
<span<?php echo $murid_delete->TEMPATLAHIR->viewAttributes() ?>><?php echo $murid_delete->TEMPATLAHIR->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->TGL_LAHIR->Visible) { // TGL_LAHIR ?>
		<td <?php echo $murid_delete->TGL_LAHIR->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_TGL_LAHIR" class="murid_TGL_LAHIR">
<span<?php echo $murid_delete->TGL_LAHIR->viewAttributes() ?>><?php echo $murid_delete->TGL_LAHIR->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->NOHP->Visible) { // NOHP ?>
		<td <?php echo $murid_delete->NOHP->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_NOHP" class="murid_NOHP">
<span<?php echo $murid_delete->NOHP->viewAttributes() ?>><?php echo $murid_delete->NOHP->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->NOWA->Visible) { // NOWA ?>
		<td <?php echo $murid_delete->NOWA->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_NOWA" class="murid_NOWA">
<span<?php echo $murid_delete->NOWA->viewAttributes() ?>><?php echo $murid_delete->NOWA->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->IDTELEGRAM->Visible) { // IDTELEGRAM ?>
		<td <?php echo $murid_delete->IDTELEGRAM->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_IDTELEGRAM" class="murid_IDTELEGRAM">
<span<?php echo $murid_delete->IDTELEGRAM->viewAttributes() ?>><?php echo $murid_delete->IDTELEGRAM->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->IDLINE->Visible) { // IDLINE ?>
		<td <?php echo $murid_delete->IDLINE->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_IDLINE" class="murid_IDLINE">
<span<?php echo $murid_delete->IDLINE->viewAttributes() ?>><?php echo $murid_delete->IDLINE->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->IDFACEBOOK->Visible) { // IDFACEBOOK ?>
		<td <?php echo $murid_delete->IDFACEBOOK->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_IDFACEBOOK" class="murid_IDFACEBOOK">
<span<?php echo $murid_delete->IDFACEBOOK->viewAttributes() ?>><?php echo $murid_delete->IDFACEBOOK->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->IDINSTAGRAM->Visible) { // IDINSTAGRAM ?>
		<td <?php echo $murid_delete->IDINSTAGRAM->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_IDINSTAGRAM" class="murid_IDINSTAGRAM">
<span<?php echo $murid_delete->IDINSTAGRAM->viewAttributes() ?>><?php echo $murid_delete->IDINSTAGRAM->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->IDTWITTER->Visible) { // IDTWITTER ?>
		<td <?php echo $murid_delete->IDTWITTER->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_IDTWITTER" class="murid_IDTWITTER">
<span<?php echo $murid_delete->IDTWITTER->viewAttributes() ?>><?php echo $murid_delete->IDTWITTER->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->IDYOUTUBE->Visible) { // IDYOUTUBE ?>
		<td <?php echo $murid_delete->IDYOUTUBE->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid_IDYOUTUBE" class="murid_IDYOUTUBE">
<span<?php echo $murid_delete->IDYOUTUBE->viewAttributes() ?>><?php echo $murid_delete->IDYOUTUBE->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($murid_delete->_EMAIL->Visible) { // EMAIL ?>
		<td <?php echo $murid_delete->_EMAIL->cellAttributes() ?>>
<span id="el<?php echo $murid_delete->RowCount ?>_murid__EMAIL" class="murid__EMAIL">
<span<?php echo $murid_delete->_EMAIL->viewAttributes() ?>><?php echo $murid_delete->_EMAIL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$murid_delete->Recordset->moveNext();
}
$murid_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $murid_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$murid_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$murid_delete->terminate();
?>