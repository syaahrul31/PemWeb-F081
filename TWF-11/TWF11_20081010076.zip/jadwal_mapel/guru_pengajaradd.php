<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$guru_pengajar_add = new guru_pengajar_add();

// Run the page
$guru_pengajar_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$guru_pengajar_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fguru_pengajaradd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	fguru_pengajaradd = currentForm = new ew.Form("fguru_pengajaradd", "add");

	// Validate form
	fguru_pengajaradd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "F")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($guru_pengajar_add->ID_GURU->Required) { ?>
				elm = this.getElements("x" + infix + "_ID_GURU");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->ID_GURU->caption(), $guru_pengajar_add->ID_GURU->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->NAMA_GURU->Required) { ?>
				elm = this.getElements("x" + infix + "_NAMA_GURU");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->NAMA_GURU->caption(), $guru_pengajar_add->NAMA_GURU->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->GELAR_DEPAN->Required) { ?>
				elm = this.getElements("x" + infix + "_GELAR_DEPAN");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->GELAR_DEPAN->caption(), $guru_pengajar_add->GELAR_DEPAN->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->GELAR_BELAKANG->Required) { ?>
				elm = this.getElements("x" + infix + "_GELAR_BELAKANG");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->GELAR_BELAKANG->caption(), $guru_pengajar_add->GELAR_BELAKANG->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->JENIS_KELAMIN->Required) { ?>
				elm = this.getElements("x" + infix + "_JENIS_KELAMIN");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->JENIS_KELAMIN->caption(), $guru_pengajar_add->JENIS_KELAMIN->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->AGAMA->Required) { ?>
				elm = this.getElements("x" + infix + "_AGAMA");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->AGAMA->caption(), $guru_pengajar_add->AGAMA->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->ALAMAT_TINGGAL->Required) { ?>
				elm = this.getElements("x" + infix + "_ALAMAT_TINGGAL");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->ALAMAT_TINGGAL->caption(), $guru_pengajar_add->ALAMAT_TINGGAL->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->NO_HP->Required) { ?>
				elm = this.getElements("x" + infix + "_NO_HP");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->NO_HP->caption(), $guru_pengajar_add->NO_HP->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->NO_WA->Required) { ?>
				elm = this.getElements("x" + infix + "_NO_WA");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->NO_WA->caption(), $guru_pengajar_add->NO_WA->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->ID_TELEGRAM->Required) { ?>
				elm = this.getElements("x" + infix + "_ID_TELEGRAM");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->ID_TELEGRAM->caption(), $guru_pengajar_add->ID_TELEGRAM->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->ID_LINE->Required) { ?>
				elm = this.getElements("x" + infix + "_ID_LINE");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->ID_LINE->caption(), $guru_pengajar_add->ID_LINE->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->ID_FACEBOOK->Required) { ?>
				elm = this.getElements("x" + infix + "_ID_FACEBOOK");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->ID_FACEBOOK->caption(), $guru_pengajar_add->ID_FACEBOOK->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->ID_INSTAGRAM->Required) { ?>
				elm = this.getElements("x" + infix + "_ID_INSTAGRAM");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->ID_INSTAGRAM->caption(), $guru_pengajar_add->ID_INSTAGRAM->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->ID_TWITTER->Required) { ?>
				elm = this.getElements("x" + infix + "_ID_TWITTER");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->ID_TWITTER->caption(), $guru_pengajar_add->ID_TWITTER->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->ID_YOUTUBE->Required) { ?>
				elm = this.getElements("x" + infix + "_ID_YOUTUBE");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->ID_YOUTUBE->caption(), $guru_pengajar_add->ID_YOUTUBE->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->EMAIL_GURU->Required) { ?>
				elm = this.getElements("x" + infix + "_EMAIL_GURU");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->EMAIL_GURU->caption(), $guru_pengajar_add->EMAIL_GURU->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->TEMPAT_LAHIR->Required) { ?>
				elm = this.getElements("x" + infix + "_TEMPAT_LAHIR");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->TEMPAT_LAHIR->caption(), $guru_pengajar_add->TEMPAT_LAHIR->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($guru_pengajar_add->TANGGAL_LAHIR->Required) { ?>
				elm = this.getElements("x" + infix + "_TANGGAL_LAHIR");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $guru_pengajar_add->TANGGAL_LAHIR->caption(), $guru_pengajar_add->TANGGAL_LAHIR->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_TANGGAL_LAHIR");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($guru_pengajar_add->TANGGAL_LAHIR->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fguru_pengajaradd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fguru_pengajaradd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fguru_pengajaradd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $guru_pengajar_add->showPageHeader(); ?>
<?php
$guru_pengajar_add->showMessage();
?>
<form name="fguru_pengajaradd" id="fguru_pengajaradd" class="<?php echo $guru_pengajar_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="guru_pengajar">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$guru_pengajar_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($guru_pengajar_add->ID_GURU->Visible) { // ID_GURU ?>
	<div id="r_ID_GURU" class="form-group row">
		<label id="elh_guru_pengajar_ID_GURU" for="x_ID_GURU" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->ID_GURU->caption() ?><?php echo $guru_pengajar_add->ID_GURU->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->ID_GURU->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_GURU">
<input type="text" data-table="guru_pengajar" data-field="x_ID_GURU" name="x_ID_GURU" id="x_ID_GURU" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($guru_pengajar_add->ID_GURU->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->ID_GURU->EditValue ?>"<?php echo $guru_pengajar_add->ID_GURU->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->ID_GURU->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->NAMA_GURU->Visible) { // NAMA_GURU ?>
	<div id="r_NAMA_GURU" class="form-group row">
		<label id="elh_guru_pengajar_NAMA_GURU" for="x_NAMA_GURU" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->NAMA_GURU->caption() ?><?php echo $guru_pengajar_add->NAMA_GURU->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->NAMA_GURU->cellAttributes() ?>>
<span id="el_guru_pengajar_NAMA_GURU">
<input type="text" data-table="guru_pengajar" data-field="x_NAMA_GURU" name="x_NAMA_GURU" id="x_NAMA_GURU" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($guru_pengajar_add->NAMA_GURU->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->NAMA_GURU->EditValue ?>"<?php echo $guru_pengajar_add->NAMA_GURU->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->NAMA_GURU->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->GELAR_DEPAN->Visible) { // GELAR_DEPAN ?>
	<div id="r_GELAR_DEPAN" class="form-group row">
		<label id="elh_guru_pengajar_GELAR_DEPAN" for="x_GELAR_DEPAN" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->GELAR_DEPAN->caption() ?><?php echo $guru_pengajar_add->GELAR_DEPAN->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->GELAR_DEPAN->cellAttributes() ?>>
<span id="el_guru_pengajar_GELAR_DEPAN">
<input type="text" data-table="guru_pengajar" data-field="x_GELAR_DEPAN" name="x_GELAR_DEPAN" id="x_GELAR_DEPAN" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($guru_pengajar_add->GELAR_DEPAN->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->GELAR_DEPAN->EditValue ?>"<?php echo $guru_pengajar_add->GELAR_DEPAN->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->GELAR_DEPAN->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->GELAR_BELAKANG->Visible) { // GELAR_BELAKANG ?>
	<div id="r_GELAR_BELAKANG" class="form-group row">
		<label id="elh_guru_pengajar_GELAR_BELAKANG" for="x_GELAR_BELAKANG" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->GELAR_BELAKANG->caption() ?><?php echo $guru_pengajar_add->GELAR_BELAKANG->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->GELAR_BELAKANG->cellAttributes() ?>>
<span id="el_guru_pengajar_GELAR_BELAKANG">
<input type="text" data-table="guru_pengajar" data-field="x_GELAR_BELAKANG" name="x_GELAR_BELAKANG" id="x_GELAR_BELAKANG" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($guru_pengajar_add->GELAR_BELAKANG->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->GELAR_BELAKANG->EditValue ?>"<?php echo $guru_pengajar_add->GELAR_BELAKANG->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->GELAR_BELAKANG->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->JENIS_KELAMIN->Visible) { // JENIS_KELAMIN ?>
	<div id="r_JENIS_KELAMIN" class="form-group row">
		<label id="elh_guru_pengajar_JENIS_KELAMIN" for="x_JENIS_KELAMIN" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->JENIS_KELAMIN->caption() ?><?php echo $guru_pengajar_add->JENIS_KELAMIN->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->JENIS_KELAMIN->cellAttributes() ?>>
<span id="el_guru_pengajar_JENIS_KELAMIN">
<input type="text" data-table="guru_pengajar" data-field="x_JENIS_KELAMIN" name="x_JENIS_KELAMIN" id="x_JENIS_KELAMIN" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($guru_pengajar_add->JENIS_KELAMIN->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->JENIS_KELAMIN->EditValue ?>"<?php echo $guru_pengajar_add->JENIS_KELAMIN->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->JENIS_KELAMIN->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->AGAMA->Visible) { // AGAMA ?>
	<div id="r_AGAMA" class="form-group row">
		<label id="elh_guru_pengajar_AGAMA" for="x_AGAMA" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->AGAMA->caption() ?><?php echo $guru_pengajar_add->AGAMA->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->AGAMA->cellAttributes() ?>>
<span id="el_guru_pengajar_AGAMA">
<input type="text" data-table="guru_pengajar" data-field="x_AGAMA" name="x_AGAMA" id="x_AGAMA" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($guru_pengajar_add->AGAMA->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->AGAMA->EditValue ?>"<?php echo $guru_pengajar_add->AGAMA->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->AGAMA->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->ALAMAT_TINGGAL->Visible) { // ALAMAT_TINGGAL ?>
	<div id="r_ALAMAT_TINGGAL" class="form-group row">
		<label id="elh_guru_pengajar_ALAMAT_TINGGAL" for="x_ALAMAT_TINGGAL" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->ALAMAT_TINGGAL->caption() ?><?php echo $guru_pengajar_add->ALAMAT_TINGGAL->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->ALAMAT_TINGGAL->cellAttributes() ?>>
<span id="el_guru_pengajar_ALAMAT_TINGGAL">
<input type="text" data-table="guru_pengajar" data-field="x_ALAMAT_TINGGAL" name="x_ALAMAT_TINGGAL" id="x_ALAMAT_TINGGAL" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($guru_pengajar_add->ALAMAT_TINGGAL->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->ALAMAT_TINGGAL->EditValue ?>"<?php echo $guru_pengajar_add->ALAMAT_TINGGAL->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->ALAMAT_TINGGAL->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->NO_HP->Visible) { // NO_HP ?>
	<div id="r_NO_HP" class="form-group row">
		<label id="elh_guru_pengajar_NO_HP" for="x_NO_HP" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->NO_HP->caption() ?><?php echo $guru_pengajar_add->NO_HP->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->NO_HP->cellAttributes() ?>>
<span id="el_guru_pengajar_NO_HP">
<input type="text" data-table="guru_pengajar" data-field="x_NO_HP" name="x_NO_HP" id="x_NO_HP" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($guru_pengajar_add->NO_HP->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->NO_HP->EditValue ?>"<?php echo $guru_pengajar_add->NO_HP->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->NO_HP->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->NO_WA->Visible) { // NO_WA ?>
	<div id="r_NO_WA" class="form-group row">
		<label id="elh_guru_pengajar_NO_WA" for="x_NO_WA" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->NO_WA->caption() ?><?php echo $guru_pengajar_add->NO_WA->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->NO_WA->cellAttributes() ?>>
<span id="el_guru_pengajar_NO_WA">
<input type="text" data-table="guru_pengajar" data-field="x_NO_WA" name="x_NO_WA" id="x_NO_WA" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($guru_pengajar_add->NO_WA->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->NO_WA->EditValue ?>"<?php echo $guru_pengajar_add->NO_WA->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->NO_WA->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->ID_TELEGRAM->Visible) { // ID_TELEGRAM ?>
	<div id="r_ID_TELEGRAM" class="form-group row">
		<label id="elh_guru_pengajar_ID_TELEGRAM" for="x_ID_TELEGRAM" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->ID_TELEGRAM->caption() ?><?php echo $guru_pengajar_add->ID_TELEGRAM->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->ID_TELEGRAM->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_TELEGRAM">
<input type="text" data-table="guru_pengajar" data-field="x_ID_TELEGRAM" name="x_ID_TELEGRAM" id="x_ID_TELEGRAM" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($guru_pengajar_add->ID_TELEGRAM->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->ID_TELEGRAM->EditValue ?>"<?php echo $guru_pengajar_add->ID_TELEGRAM->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->ID_TELEGRAM->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->ID_LINE->Visible) { // ID_LINE ?>
	<div id="r_ID_LINE" class="form-group row">
		<label id="elh_guru_pengajar_ID_LINE" for="x_ID_LINE" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->ID_LINE->caption() ?><?php echo $guru_pengajar_add->ID_LINE->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->ID_LINE->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_LINE">
<input type="text" data-table="guru_pengajar" data-field="x_ID_LINE" name="x_ID_LINE" id="x_ID_LINE" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($guru_pengajar_add->ID_LINE->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->ID_LINE->EditValue ?>"<?php echo $guru_pengajar_add->ID_LINE->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->ID_LINE->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->ID_FACEBOOK->Visible) { // ID_FACEBOOK ?>
	<div id="r_ID_FACEBOOK" class="form-group row">
		<label id="elh_guru_pengajar_ID_FACEBOOK" for="x_ID_FACEBOOK" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->ID_FACEBOOK->caption() ?><?php echo $guru_pengajar_add->ID_FACEBOOK->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->ID_FACEBOOK->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_FACEBOOK">
<input type="text" data-table="guru_pengajar" data-field="x_ID_FACEBOOK" name="x_ID_FACEBOOK" id="x_ID_FACEBOOK" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($guru_pengajar_add->ID_FACEBOOK->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->ID_FACEBOOK->EditValue ?>"<?php echo $guru_pengajar_add->ID_FACEBOOK->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->ID_FACEBOOK->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->ID_INSTAGRAM->Visible) { // ID_INSTAGRAM ?>
	<div id="r_ID_INSTAGRAM" class="form-group row">
		<label id="elh_guru_pengajar_ID_INSTAGRAM" for="x_ID_INSTAGRAM" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->ID_INSTAGRAM->caption() ?><?php echo $guru_pengajar_add->ID_INSTAGRAM->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->ID_INSTAGRAM->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_INSTAGRAM">
<input type="text" data-table="guru_pengajar" data-field="x_ID_INSTAGRAM" name="x_ID_INSTAGRAM" id="x_ID_INSTAGRAM" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($guru_pengajar_add->ID_INSTAGRAM->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->ID_INSTAGRAM->EditValue ?>"<?php echo $guru_pengajar_add->ID_INSTAGRAM->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->ID_INSTAGRAM->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->ID_TWITTER->Visible) { // ID_TWITTER ?>
	<div id="r_ID_TWITTER" class="form-group row">
		<label id="elh_guru_pengajar_ID_TWITTER" for="x_ID_TWITTER" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->ID_TWITTER->caption() ?><?php echo $guru_pengajar_add->ID_TWITTER->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->ID_TWITTER->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_TWITTER">
<input type="text" data-table="guru_pengajar" data-field="x_ID_TWITTER" name="x_ID_TWITTER" id="x_ID_TWITTER" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($guru_pengajar_add->ID_TWITTER->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->ID_TWITTER->EditValue ?>"<?php echo $guru_pengajar_add->ID_TWITTER->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->ID_TWITTER->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->ID_YOUTUBE->Visible) { // ID_YOUTUBE ?>
	<div id="r_ID_YOUTUBE" class="form-group row">
		<label id="elh_guru_pengajar_ID_YOUTUBE" for="x_ID_YOUTUBE" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->ID_YOUTUBE->caption() ?><?php echo $guru_pengajar_add->ID_YOUTUBE->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->ID_YOUTUBE->cellAttributes() ?>>
<span id="el_guru_pengajar_ID_YOUTUBE">
<input type="text" data-table="guru_pengajar" data-field="x_ID_YOUTUBE" name="x_ID_YOUTUBE" id="x_ID_YOUTUBE" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($guru_pengajar_add->ID_YOUTUBE->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->ID_YOUTUBE->EditValue ?>"<?php echo $guru_pengajar_add->ID_YOUTUBE->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->ID_YOUTUBE->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->EMAIL_GURU->Visible) { // EMAIL_GURU ?>
	<div id="r_EMAIL_GURU" class="form-group row">
		<label id="elh_guru_pengajar_EMAIL_GURU" for="x_EMAIL_GURU" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->EMAIL_GURU->caption() ?><?php echo $guru_pengajar_add->EMAIL_GURU->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->EMAIL_GURU->cellAttributes() ?>>
<span id="el_guru_pengajar_EMAIL_GURU">
<input type="text" data-table="guru_pengajar" data-field="x_EMAIL_GURU" name="x_EMAIL_GURU" id="x_EMAIL_GURU" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($guru_pengajar_add->EMAIL_GURU->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->EMAIL_GURU->EditValue ?>"<?php echo $guru_pengajar_add->EMAIL_GURU->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->EMAIL_GURU->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->TEMPAT_LAHIR->Visible) { // TEMPAT_LAHIR ?>
	<div id="r_TEMPAT_LAHIR" class="form-group row">
		<label id="elh_guru_pengajar_TEMPAT_LAHIR" for="x_TEMPAT_LAHIR" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->TEMPAT_LAHIR->caption() ?><?php echo $guru_pengajar_add->TEMPAT_LAHIR->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->TEMPAT_LAHIR->cellAttributes() ?>>
<span id="el_guru_pengajar_TEMPAT_LAHIR">
<input type="text" data-table="guru_pengajar" data-field="x_TEMPAT_LAHIR" name="x_TEMPAT_LAHIR" id="x_TEMPAT_LAHIR" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($guru_pengajar_add->TEMPAT_LAHIR->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->TEMPAT_LAHIR->EditValue ?>"<?php echo $guru_pengajar_add->TEMPAT_LAHIR->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->TEMPAT_LAHIR->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($guru_pengajar_add->TANGGAL_LAHIR->Visible) { // TANGGAL_LAHIR ?>
	<div id="r_TANGGAL_LAHIR" class="form-group row">
		<label id="elh_guru_pengajar_TANGGAL_LAHIR" for="x_TANGGAL_LAHIR" class="<?php echo $guru_pengajar_add->LeftColumnClass ?>"><?php echo $guru_pengajar_add->TANGGAL_LAHIR->caption() ?><?php echo $guru_pengajar_add->TANGGAL_LAHIR->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $guru_pengajar_add->RightColumnClass ?>"><div <?php echo $guru_pengajar_add->TANGGAL_LAHIR->cellAttributes() ?>>
<span id="el_guru_pengajar_TANGGAL_LAHIR">
<input type="text" data-table="guru_pengajar" data-field="x_TANGGAL_LAHIR" name="x_TANGGAL_LAHIR" id="x_TANGGAL_LAHIR" maxlength="10" placeholder="<?php echo HtmlEncode($guru_pengajar_add->TANGGAL_LAHIR->getPlaceHolder()) ?>" value="<?php echo $guru_pengajar_add->TANGGAL_LAHIR->EditValue ?>"<?php echo $guru_pengajar_add->TANGGAL_LAHIR->editAttributes() ?>>
</span>
<?php echo $guru_pengajar_add->TANGGAL_LAHIR->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$guru_pengajar_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $guru_pengajar_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $guru_pengajar_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$guru_pengajar_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$guru_pengajar_add->terminate();
?>