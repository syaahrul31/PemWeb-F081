<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$mata_pelajaran_edit = new mata_pelajaran_edit();

// Run the page
$mata_pelajaran_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$mata_pelajaran_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmata_pelajaranedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fmata_pelajaranedit = currentForm = new ew.Form("fmata_pelajaranedit", "edit");

	// Validate form
	fmata_pelajaranedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "F")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($mata_pelajaran_edit->KODE_MAPEL->Required) { ?>
				elm = this.getElements("x" + infix + "_KODE_MAPEL");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mata_pelajaran_edit->KODE_MAPEL->caption(), $mata_pelajaran_edit->KODE_MAPEL->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($mata_pelajaran_edit->NAMA_MAPEL->Required) { ?>
				elm = this.getElements("x" + infix + "_NAMA_MAPEL");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mata_pelajaran_edit->NAMA_MAPEL->caption(), $mata_pelajaran_edit->NAMA_MAPEL->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($mata_pelajaran_edit->BIDANG_MAPEL->Required) { ?>
				elm = this.getElements("x" + infix + "_BIDANG_MAPEL");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mata_pelajaran_edit->BIDANG_MAPEL->caption(), $mata_pelajaran_edit->BIDANG_MAPEL->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($mata_pelajaran_edit->JENIS_MAPEL->Required) { ?>
				elm = this.getElements("x" + infix + "_JENIS_MAPEL");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mata_pelajaran_edit->JENIS_MAPEL->caption(), $mata_pelajaran_edit->JENIS_MAPEL->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($mata_pelajaran_edit->TIPE_MAPEL->Required) { ?>
				elm = this.getElements("x" + infix + "_TIPE_MAPEL");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mata_pelajaran_edit->TIPE_MAPEL->caption(), $mata_pelajaran_edit->TIPE_MAPEL->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($mata_pelajaran_edit->JUMLAH_PERTEMUAN->Required) { ?>
				elm = this.getElements("x" + infix + "_JUMLAH_PERTEMUAN");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mata_pelajaran_edit->JUMLAH_PERTEMUAN->caption(), $mata_pelajaran_edit->JUMLAH_PERTEMUAN->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_JUMLAH_PERTEMUAN");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($mata_pelajaran_edit->JUMLAH_PERTEMUAN->errorMessage()) ?>");
			<?php if ($mata_pelajaran_edit->DURASI_MAPEL->Required) { ?>
				elm = this.getElements("x" + infix + "_DURASI_MAPEL");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mata_pelajaran_edit->DURASI_MAPEL->caption(), $mata_pelajaran_edit->DURASI_MAPEL->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_DURASI_MAPEL");
				if (elm && !ew.checkTime(elm.value))
					return this.onError(elm, "<?php echo JsEncode($mata_pelajaran_edit->DURASI_MAPEL->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fmata_pelajaranedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmata_pelajaranedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fmata_pelajaranedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $mata_pelajaran_edit->showPageHeader(); ?>
<?php
$mata_pelajaran_edit->showMessage();
?>
<form name="fmata_pelajaranedit" id="fmata_pelajaranedit" class="<?php echo $mata_pelajaran_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="mata_pelajaran">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$mata_pelajaran_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($mata_pelajaran_edit->KODE_MAPEL->Visible) { // KODE_MAPEL ?>
	<div id="r_KODE_MAPEL" class="form-group row">
		<label id="elh_mata_pelajaran_KODE_MAPEL" for="x_KODE_MAPEL" class="<?php echo $mata_pelajaran_edit->LeftColumnClass ?>"><?php echo $mata_pelajaran_edit->KODE_MAPEL->caption() ?><?php echo $mata_pelajaran_edit->KODE_MAPEL->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $mata_pelajaran_edit->RightColumnClass ?>"><div <?php echo $mata_pelajaran_edit->KODE_MAPEL->cellAttributes() ?>>
<input type="text" data-table="mata_pelajaran" data-field="x_KODE_MAPEL" name="x_KODE_MAPEL" id="x_KODE_MAPEL" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($mata_pelajaran_edit->KODE_MAPEL->getPlaceHolder()) ?>" value="<?php echo $mata_pelajaran_edit->KODE_MAPEL->EditValue ?>"<?php echo $mata_pelajaran_edit->KODE_MAPEL->editAttributes() ?>>
<input type="hidden" data-table="mata_pelajaran" data-field="x_KODE_MAPEL" name="o_KODE_MAPEL" id="o_KODE_MAPEL" value="<?php echo HtmlEncode($mata_pelajaran_edit->KODE_MAPEL->OldValue != null ? $mata_pelajaran_edit->KODE_MAPEL->OldValue : $mata_pelajaran_edit->KODE_MAPEL->CurrentValue) ?>">
<?php echo $mata_pelajaran_edit->KODE_MAPEL->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($mata_pelajaran_edit->NAMA_MAPEL->Visible) { // NAMA_MAPEL ?>
	<div id="r_NAMA_MAPEL" class="form-group row">
		<label id="elh_mata_pelajaran_NAMA_MAPEL" for="x_NAMA_MAPEL" class="<?php echo $mata_pelajaran_edit->LeftColumnClass ?>"><?php echo $mata_pelajaran_edit->NAMA_MAPEL->caption() ?><?php echo $mata_pelajaran_edit->NAMA_MAPEL->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $mata_pelajaran_edit->RightColumnClass ?>"><div <?php echo $mata_pelajaran_edit->NAMA_MAPEL->cellAttributes() ?>>
<span id="el_mata_pelajaran_NAMA_MAPEL">
<input type="text" data-table="mata_pelajaran" data-field="x_NAMA_MAPEL" name="x_NAMA_MAPEL" id="x_NAMA_MAPEL" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($mata_pelajaran_edit->NAMA_MAPEL->getPlaceHolder()) ?>" value="<?php echo $mata_pelajaran_edit->NAMA_MAPEL->EditValue ?>"<?php echo $mata_pelajaran_edit->NAMA_MAPEL->editAttributes() ?>>
</span>
<?php echo $mata_pelajaran_edit->NAMA_MAPEL->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($mata_pelajaran_edit->BIDANG_MAPEL->Visible) { // BIDANG_MAPEL ?>
	<div id="r_BIDANG_MAPEL" class="form-group row">
		<label id="elh_mata_pelajaran_BIDANG_MAPEL" for="x_BIDANG_MAPEL" class="<?php echo $mata_pelajaran_edit->LeftColumnClass ?>"><?php echo $mata_pelajaran_edit->BIDANG_MAPEL->caption() ?><?php echo $mata_pelajaran_edit->BIDANG_MAPEL->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $mata_pelajaran_edit->RightColumnClass ?>"><div <?php echo $mata_pelajaran_edit->BIDANG_MAPEL->cellAttributes() ?>>
<span id="el_mata_pelajaran_BIDANG_MAPEL">
<input type="text" data-table="mata_pelajaran" data-field="x_BIDANG_MAPEL" name="x_BIDANG_MAPEL" id="x_BIDANG_MAPEL" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($mata_pelajaran_edit->BIDANG_MAPEL->getPlaceHolder()) ?>" value="<?php echo $mata_pelajaran_edit->BIDANG_MAPEL->EditValue ?>"<?php echo $mata_pelajaran_edit->BIDANG_MAPEL->editAttributes() ?>>
</span>
<?php echo $mata_pelajaran_edit->BIDANG_MAPEL->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($mata_pelajaran_edit->JENIS_MAPEL->Visible) { // JENIS_MAPEL ?>
	<div id="r_JENIS_MAPEL" class="form-group row">
		<label id="elh_mata_pelajaran_JENIS_MAPEL" for="x_JENIS_MAPEL" class="<?php echo $mata_pelajaran_edit->LeftColumnClass ?>"><?php echo $mata_pelajaran_edit->JENIS_MAPEL->caption() ?><?php echo $mata_pelajaran_edit->JENIS_MAPEL->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $mata_pelajaran_edit->RightColumnClass ?>"><div <?php echo $mata_pelajaran_edit->JENIS_MAPEL->cellAttributes() ?>>
<span id="el_mata_pelajaran_JENIS_MAPEL">
<input type="text" data-table="mata_pelajaran" data-field="x_JENIS_MAPEL" name="x_JENIS_MAPEL" id="x_JENIS_MAPEL" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($mata_pelajaran_edit->JENIS_MAPEL->getPlaceHolder()) ?>" value="<?php echo $mata_pelajaran_edit->JENIS_MAPEL->EditValue ?>"<?php echo $mata_pelajaran_edit->JENIS_MAPEL->editAttributes() ?>>
</span>
<?php echo $mata_pelajaran_edit->JENIS_MAPEL->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($mata_pelajaran_edit->TIPE_MAPEL->Visible) { // TIPE_MAPEL ?>
	<div id="r_TIPE_MAPEL" class="form-group row">
		<label id="elh_mata_pelajaran_TIPE_MAPEL" for="x_TIPE_MAPEL" class="<?php echo $mata_pelajaran_edit->LeftColumnClass ?>"><?php echo $mata_pelajaran_edit->TIPE_MAPEL->caption() ?><?php echo $mata_pelajaran_edit->TIPE_MAPEL->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $mata_pelajaran_edit->RightColumnClass ?>"><div <?php echo $mata_pelajaran_edit->TIPE_MAPEL->cellAttributes() ?>>
<span id="el_mata_pelajaran_TIPE_MAPEL">
<input type="text" data-table="mata_pelajaran" data-field="x_TIPE_MAPEL" name="x_TIPE_MAPEL" id="x_TIPE_MAPEL" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($mata_pelajaran_edit->TIPE_MAPEL->getPlaceHolder()) ?>" value="<?php echo $mata_pelajaran_edit->TIPE_MAPEL->EditValue ?>"<?php echo $mata_pelajaran_edit->TIPE_MAPEL->editAttributes() ?>>
</span>
<?php echo $mata_pelajaran_edit->TIPE_MAPEL->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($mata_pelajaran_edit->JUMLAH_PERTEMUAN->Visible) { // JUMLAH_PERTEMUAN ?>
	<div id="r_JUMLAH_PERTEMUAN" class="form-group row">
		<label id="elh_mata_pelajaran_JUMLAH_PERTEMUAN" for="x_JUMLAH_PERTEMUAN" class="<?php echo $mata_pelajaran_edit->LeftColumnClass ?>"><?php echo $mata_pelajaran_edit->JUMLAH_PERTEMUAN->caption() ?><?php echo $mata_pelajaran_edit->JUMLAH_PERTEMUAN->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $mata_pelajaran_edit->RightColumnClass ?>"><div <?php echo $mata_pelajaran_edit->JUMLAH_PERTEMUAN->cellAttributes() ?>>
<span id="el_mata_pelajaran_JUMLAH_PERTEMUAN">
<input type="text" data-table="mata_pelajaran" data-field="x_JUMLAH_PERTEMUAN" name="x_JUMLAH_PERTEMUAN" id="x_JUMLAH_PERTEMUAN" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($mata_pelajaran_edit->JUMLAH_PERTEMUAN->getPlaceHolder()) ?>" value="<?php echo $mata_pelajaran_edit->JUMLAH_PERTEMUAN->EditValue ?>"<?php echo $mata_pelajaran_edit->JUMLAH_PERTEMUAN->editAttributes() ?>>
</span>
<?php echo $mata_pelajaran_edit->JUMLAH_PERTEMUAN->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($mata_pelajaran_edit->DURASI_MAPEL->Visible) { // DURASI_MAPEL ?>
	<div id="r_DURASI_MAPEL" class="form-group row">
		<label id="elh_mata_pelajaran_DURASI_MAPEL" for="x_DURASI_MAPEL" class="<?php echo $mata_pelajaran_edit->LeftColumnClass ?>"><?php echo $mata_pelajaran_edit->DURASI_MAPEL->caption() ?><?php echo $mata_pelajaran_edit->DURASI_MAPEL->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $mata_pelajaran_edit->RightColumnClass ?>"><div <?php echo $mata_pelajaran_edit->DURASI_MAPEL->cellAttributes() ?>>
<span id="el_mata_pelajaran_DURASI_MAPEL">
<input type="text" data-table="mata_pelajaran" data-field="x_DURASI_MAPEL" name="x_DURASI_MAPEL" id="x_DURASI_MAPEL" maxlength="10" placeholder="<?php echo HtmlEncode($mata_pelajaran_edit->DURASI_MAPEL->getPlaceHolder()) ?>" value="<?php echo $mata_pelajaran_edit->DURASI_MAPEL->EditValue ?>"<?php echo $mata_pelajaran_edit->DURASI_MAPEL->editAttributes() ?>>
</span>
<?php echo $mata_pelajaran_edit->DURASI_MAPEL->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$mata_pelajaran_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $mata_pelajaran_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $mata_pelajaran_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$mata_pelajaran_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$mata_pelajaran_edit->terminate();
?>