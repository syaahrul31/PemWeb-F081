<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$murid_list = new murid_list();

// Run the page
$murid_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$murid_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$murid_list->isExport()) { ?>
<script>
var fmuridlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fmuridlist = currentForm = new ew.Form("fmuridlist", "list");
	fmuridlist.formKeyCountName = '<?php echo $murid_list->FormKeyCountName ?>';
	loadjs.done("fmuridlist");
});
var fmuridlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fmuridlistsrch = currentSearchForm = new ew.Form("fmuridlistsrch");

	// Dynamic selection lists
	// Filters

	fmuridlistsrch.filterList = <?php echo $murid_list->getFilterList() ?>;
	loadjs.done("fmuridlistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$murid_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($murid_list->TotalRecords > 0 && $murid_list->ExportOptions->visible()) { ?>
<?php $murid_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($murid_list->ImportOptions->visible()) { ?>
<?php $murid_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($murid_list->SearchOptions->visible()) { ?>
<?php $murid_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($murid_list->FilterOptions->visible()) { ?>
<?php $murid_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$murid_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$murid_list->isExport() && !$murid->CurrentAction) { ?>
<form name="fmuridlistsrch" id="fmuridlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fmuridlistsrch-search-panel" class="<?php echo $murid_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="murid">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $murid_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($murid_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($murid_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $murid_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($murid_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($murid_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($murid_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($murid_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $murid_list->showPageHeader(); ?>
<?php
$murid_list->showMessage();
?>
<?php if ($murid_list->TotalRecords > 0 || $murid->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($murid_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> murid">
<form name="fmuridlist" id="fmuridlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="murid">
<div id="gmp_murid" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($murid_list->TotalRecords > 0 || $murid_list->isGridEdit()) { ?>
<table id="tbl_muridlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$murid->RowType = ROWTYPE_HEADER;

// Render list options
$murid_list->renderListOptions();

// Render list options (header, left)
$murid_list->ListOptions->render("header", "left");
?>
<?php if ($murid_list->NO_INDUK->Visible) { // NO_INDUK ?>
	<?php if ($murid_list->SortUrl($murid_list->NO_INDUK) == "") { ?>
		<th data-name="NO_INDUK" class="<?php echo $murid_list->NO_INDUK->headerCellClass() ?>"><div id="elh_murid_NO_INDUK" class="murid_NO_INDUK"><div class="ew-table-header-caption"><?php echo $murid_list->NO_INDUK->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="NO_INDUK" class="<?php echo $murid_list->NO_INDUK->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->NO_INDUK) ?>', 1);"><div id="elh_murid_NO_INDUK" class="murid_NO_INDUK">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->NO_INDUK->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->NO_INDUK->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->NO_INDUK->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->NAMA_MURID->Visible) { // NAMA_MURID ?>
	<?php if ($murid_list->SortUrl($murid_list->NAMA_MURID) == "") { ?>
		<th data-name="NAMA_MURID" class="<?php echo $murid_list->NAMA_MURID->headerCellClass() ?>"><div id="elh_murid_NAMA_MURID" class="murid_NAMA_MURID"><div class="ew-table-header-caption"><?php echo $murid_list->NAMA_MURID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="NAMA_MURID" class="<?php echo $murid_list->NAMA_MURID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->NAMA_MURID) ?>', 1);"><div id="elh_murid_NAMA_MURID" class="murid_NAMA_MURID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->NAMA_MURID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->NAMA_MURID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->NAMA_MURID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->JEN_KEL->Visible) { // JEN_KEL ?>
	<?php if ($murid_list->SortUrl($murid_list->JEN_KEL) == "") { ?>
		<th data-name="JEN_KEL" class="<?php echo $murid_list->JEN_KEL->headerCellClass() ?>"><div id="elh_murid_JEN_KEL" class="murid_JEN_KEL"><div class="ew-table-header-caption"><?php echo $murid_list->JEN_KEL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="JEN_KEL" class="<?php echo $murid_list->JEN_KEL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->JEN_KEL) ?>', 1);"><div id="elh_murid_JEN_KEL" class="murid_JEN_KEL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->JEN_KEL->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->JEN_KEL->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->JEN_KEL->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->AGAMA_MURID->Visible) { // AGAMA_MURID ?>
	<?php if ($murid_list->SortUrl($murid_list->AGAMA_MURID) == "") { ?>
		<th data-name="AGAMA_MURID" class="<?php echo $murid_list->AGAMA_MURID->headerCellClass() ?>"><div id="elh_murid_AGAMA_MURID" class="murid_AGAMA_MURID"><div class="ew-table-header-caption"><?php echo $murid_list->AGAMA_MURID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="AGAMA_MURID" class="<?php echo $murid_list->AGAMA_MURID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->AGAMA_MURID) ?>', 1);"><div id="elh_murid_AGAMA_MURID" class="murid_AGAMA_MURID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->AGAMA_MURID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->AGAMA_MURID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->AGAMA_MURID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->ALAMAT_RUMAH->Visible) { // ALAMAT_RUMAH ?>
	<?php if ($murid_list->SortUrl($murid_list->ALAMAT_RUMAH) == "") { ?>
		<th data-name="ALAMAT_RUMAH" class="<?php echo $murid_list->ALAMAT_RUMAH->headerCellClass() ?>"><div id="elh_murid_ALAMAT_RUMAH" class="murid_ALAMAT_RUMAH"><div class="ew-table-header-caption"><?php echo $murid_list->ALAMAT_RUMAH->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ALAMAT_RUMAH" class="<?php echo $murid_list->ALAMAT_RUMAH->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->ALAMAT_RUMAH) ?>', 1);"><div id="elh_murid_ALAMAT_RUMAH" class="murid_ALAMAT_RUMAH">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->ALAMAT_RUMAH->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->ALAMAT_RUMAH->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->ALAMAT_RUMAH->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->TEMPATLAHIR->Visible) { // TEMPATLAHIR ?>
	<?php if ($murid_list->SortUrl($murid_list->TEMPATLAHIR) == "") { ?>
		<th data-name="TEMPATLAHIR" class="<?php echo $murid_list->TEMPATLAHIR->headerCellClass() ?>"><div id="elh_murid_TEMPATLAHIR" class="murid_TEMPATLAHIR"><div class="ew-table-header-caption"><?php echo $murid_list->TEMPATLAHIR->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TEMPATLAHIR" class="<?php echo $murid_list->TEMPATLAHIR->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->TEMPATLAHIR) ?>', 1);"><div id="elh_murid_TEMPATLAHIR" class="murid_TEMPATLAHIR">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->TEMPATLAHIR->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->TEMPATLAHIR->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->TEMPATLAHIR->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->TGL_LAHIR->Visible) { // TGL_LAHIR ?>
	<?php if ($murid_list->SortUrl($murid_list->TGL_LAHIR) == "") { ?>
		<th data-name="TGL_LAHIR" class="<?php echo $murid_list->TGL_LAHIR->headerCellClass() ?>"><div id="elh_murid_TGL_LAHIR" class="murid_TGL_LAHIR"><div class="ew-table-header-caption"><?php echo $murid_list->TGL_LAHIR->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TGL_LAHIR" class="<?php echo $murid_list->TGL_LAHIR->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->TGL_LAHIR) ?>', 1);"><div id="elh_murid_TGL_LAHIR" class="murid_TGL_LAHIR">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->TGL_LAHIR->caption() ?></span><span class="ew-table-header-sort"><?php if ($murid_list->TGL_LAHIR->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->TGL_LAHIR->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->NOHP->Visible) { // NOHP ?>
	<?php if ($murid_list->SortUrl($murid_list->NOHP) == "") { ?>
		<th data-name="NOHP" class="<?php echo $murid_list->NOHP->headerCellClass() ?>"><div id="elh_murid_NOHP" class="murid_NOHP"><div class="ew-table-header-caption"><?php echo $murid_list->NOHP->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="NOHP" class="<?php echo $murid_list->NOHP->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->NOHP) ?>', 1);"><div id="elh_murid_NOHP" class="murid_NOHP">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->NOHP->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->NOHP->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->NOHP->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->NOWA->Visible) { // NOWA ?>
	<?php if ($murid_list->SortUrl($murid_list->NOWA) == "") { ?>
		<th data-name="NOWA" class="<?php echo $murid_list->NOWA->headerCellClass() ?>"><div id="elh_murid_NOWA" class="murid_NOWA"><div class="ew-table-header-caption"><?php echo $murid_list->NOWA->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="NOWA" class="<?php echo $murid_list->NOWA->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->NOWA) ?>', 1);"><div id="elh_murid_NOWA" class="murid_NOWA">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->NOWA->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->NOWA->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->NOWA->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->IDTELEGRAM->Visible) { // IDTELEGRAM ?>
	<?php if ($murid_list->SortUrl($murid_list->IDTELEGRAM) == "") { ?>
		<th data-name="IDTELEGRAM" class="<?php echo $murid_list->IDTELEGRAM->headerCellClass() ?>"><div id="elh_murid_IDTELEGRAM" class="murid_IDTELEGRAM"><div class="ew-table-header-caption"><?php echo $murid_list->IDTELEGRAM->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="IDTELEGRAM" class="<?php echo $murid_list->IDTELEGRAM->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->IDTELEGRAM) ?>', 1);"><div id="elh_murid_IDTELEGRAM" class="murid_IDTELEGRAM">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->IDTELEGRAM->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->IDTELEGRAM->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->IDTELEGRAM->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->IDLINE->Visible) { // IDLINE ?>
	<?php if ($murid_list->SortUrl($murid_list->IDLINE) == "") { ?>
		<th data-name="IDLINE" class="<?php echo $murid_list->IDLINE->headerCellClass() ?>"><div id="elh_murid_IDLINE" class="murid_IDLINE"><div class="ew-table-header-caption"><?php echo $murid_list->IDLINE->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="IDLINE" class="<?php echo $murid_list->IDLINE->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->IDLINE) ?>', 1);"><div id="elh_murid_IDLINE" class="murid_IDLINE">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->IDLINE->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->IDLINE->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->IDLINE->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->IDFACEBOOK->Visible) { // IDFACEBOOK ?>
	<?php if ($murid_list->SortUrl($murid_list->IDFACEBOOK) == "") { ?>
		<th data-name="IDFACEBOOK" class="<?php echo $murid_list->IDFACEBOOK->headerCellClass() ?>"><div id="elh_murid_IDFACEBOOK" class="murid_IDFACEBOOK"><div class="ew-table-header-caption"><?php echo $murid_list->IDFACEBOOK->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="IDFACEBOOK" class="<?php echo $murid_list->IDFACEBOOK->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->IDFACEBOOK) ?>', 1);"><div id="elh_murid_IDFACEBOOK" class="murid_IDFACEBOOK">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->IDFACEBOOK->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->IDFACEBOOK->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->IDFACEBOOK->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->IDINSTAGRAM->Visible) { // IDINSTAGRAM ?>
	<?php if ($murid_list->SortUrl($murid_list->IDINSTAGRAM) == "") { ?>
		<th data-name="IDINSTAGRAM" class="<?php echo $murid_list->IDINSTAGRAM->headerCellClass() ?>"><div id="elh_murid_IDINSTAGRAM" class="murid_IDINSTAGRAM"><div class="ew-table-header-caption"><?php echo $murid_list->IDINSTAGRAM->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="IDINSTAGRAM" class="<?php echo $murid_list->IDINSTAGRAM->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->IDINSTAGRAM) ?>', 1);"><div id="elh_murid_IDINSTAGRAM" class="murid_IDINSTAGRAM">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->IDINSTAGRAM->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->IDINSTAGRAM->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->IDINSTAGRAM->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->IDTWITTER->Visible) { // IDTWITTER ?>
	<?php if ($murid_list->SortUrl($murid_list->IDTWITTER) == "") { ?>
		<th data-name="IDTWITTER" class="<?php echo $murid_list->IDTWITTER->headerCellClass() ?>"><div id="elh_murid_IDTWITTER" class="murid_IDTWITTER"><div class="ew-table-header-caption"><?php echo $murid_list->IDTWITTER->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="IDTWITTER" class="<?php echo $murid_list->IDTWITTER->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->IDTWITTER) ?>', 1);"><div id="elh_murid_IDTWITTER" class="murid_IDTWITTER">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->IDTWITTER->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->IDTWITTER->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->IDTWITTER->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->IDYOUTUBE->Visible) { // IDYOUTUBE ?>
	<?php if ($murid_list->SortUrl($murid_list->IDYOUTUBE) == "") { ?>
		<th data-name="IDYOUTUBE" class="<?php echo $murid_list->IDYOUTUBE->headerCellClass() ?>"><div id="elh_murid_IDYOUTUBE" class="murid_IDYOUTUBE"><div class="ew-table-header-caption"><?php echo $murid_list->IDYOUTUBE->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="IDYOUTUBE" class="<?php echo $murid_list->IDYOUTUBE->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->IDYOUTUBE) ?>', 1);"><div id="elh_murid_IDYOUTUBE" class="murid_IDYOUTUBE">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->IDYOUTUBE->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->IDYOUTUBE->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->IDYOUTUBE->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($murid_list->_EMAIL->Visible) { // EMAIL ?>
	<?php if ($murid_list->SortUrl($murid_list->_EMAIL) == "") { ?>
		<th data-name="_EMAIL" class="<?php echo $murid_list->_EMAIL->headerCellClass() ?>"><div id="elh_murid__EMAIL" class="murid__EMAIL"><div class="ew-table-header-caption"><?php echo $murid_list->_EMAIL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_EMAIL" class="<?php echo $murid_list->_EMAIL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $murid_list->SortUrl($murid_list->_EMAIL) ?>', 1);"><div id="elh_murid__EMAIL" class="murid__EMAIL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $murid_list->_EMAIL->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($murid_list->_EMAIL->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($murid_list->_EMAIL->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$murid_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($murid_list->ExportAll && $murid_list->isExport()) {
	$murid_list->StopRecord = $murid_list->TotalRecords;
} else {

	// Set the last record to display
	if ($murid_list->TotalRecords > $murid_list->StartRecord + $murid_list->DisplayRecords - 1)
		$murid_list->StopRecord = $murid_list->StartRecord + $murid_list->DisplayRecords - 1;
	else
		$murid_list->StopRecord = $murid_list->TotalRecords;
}
$murid_list->RecordCount = $murid_list->StartRecord - 1;
if ($murid_list->Recordset && !$murid_list->Recordset->EOF) {
	$murid_list->Recordset->moveFirst();
	$selectLimit = $murid_list->UseSelectLimit;
	if (!$selectLimit && $murid_list->StartRecord > 1)
		$murid_list->Recordset->move($murid_list->StartRecord - 1);
} elseif (!$murid->AllowAddDeleteRow && $murid_list->StopRecord == 0) {
	$murid_list->StopRecord = $murid->GridAddRowCount;
}

// Initialize aggregate
$murid->RowType = ROWTYPE_AGGREGATEINIT;
$murid->resetAttributes();
$murid_list->renderRow();
while ($murid_list->RecordCount < $murid_list->StopRecord) {
	$murid_list->RecordCount++;
	if ($murid_list->RecordCount >= $murid_list->StartRecord) {
		$murid_list->RowCount++;

		// Set up key count
		$murid_list->KeyCount = $murid_list->RowIndex;

		// Init row class and style
		$murid->resetAttributes();
		$murid->CssClass = "";
		if ($murid_list->isGridAdd()) {
		} else {
			$murid_list->loadRowValues($murid_list->Recordset); // Load row values
		}
		$murid->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$murid->RowAttrs->merge(["data-rowindex" => $murid_list->RowCount, "id" => "r" . $murid_list->RowCount . "_murid", "data-rowtype" => $murid->RowType]);

		// Render row
		$murid_list->renderRow();

		// Render list options
		$murid_list->renderListOptions();
?>
	<tr <?php echo $murid->rowAttributes() ?>>
<?php

// Render list options (body, left)
$murid_list->ListOptions->render("body", "left", $murid_list->RowCount);
?>
	<?php if ($murid_list->NO_INDUK->Visible) { // NO_INDUK ?>
		<td data-name="NO_INDUK" <?php echo $murid_list->NO_INDUK->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_NO_INDUK">
<span<?php echo $murid_list->NO_INDUK->viewAttributes() ?>><?php echo $murid_list->NO_INDUK->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->NAMA_MURID->Visible) { // NAMA_MURID ?>
		<td data-name="NAMA_MURID" <?php echo $murid_list->NAMA_MURID->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_NAMA_MURID">
<span<?php echo $murid_list->NAMA_MURID->viewAttributes() ?>><?php echo $murid_list->NAMA_MURID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->JEN_KEL->Visible) { // JEN_KEL ?>
		<td data-name="JEN_KEL" <?php echo $murid_list->JEN_KEL->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_JEN_KEL">
<span<?php echo $murid_list->JEN_KEL->viewAttributes() ?>><?php echo $murid_list->JEN_KEL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->AGAMA_MURID->Visible) { // AGAMA_MURID ?>
		<td data-name="AGAMA_MURID" <?php echo $murid_list->AGAMA_MURID->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_AGAMA_MURID">
<span<?php echo $murid_list->AGAMA_MURID->viewAttributes() ?>><?php echo $murid_list->AGAMA_MURID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->ALAMAT_RUMAH->Visible) { // ALAMAT_RUMAH ?>
		<td data-name="ALAMAT_RUMAH" <?php echo $murid_list->ALAMAT_RUMAH->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_ALAMAT_RUMAH">
<span<?php echo $murid_list->ALAMAT_RUMAH->viewAttributes() ?>><?php echo $murid_list->ALAMAT_RUMAH->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->TEMPATLAHIR->Visible) { // TEMPATLAHIR ?>
		<td data-name="TEMPATLAHIR" <?php echo $murid_list->TEMPATLAHIR->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_TEMPATLAHIR">
<span<?php echo $murid_list->TEMPATLAHIR->viewAttributes() ?>><?php echo $murid_list->TEMPATLAHIR->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->TGL_LAHIR->Visible) { // TGL_LAHIR ?>
		<td data-name="TGL_LAHIR" <?php echo $murid_list->TGL_LAHIR->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_TGL_LAHIR">
<span<?php echo $murid_list->TGL_LAHIR->viewAttributes() ?>><?php echo $murid_list->TGL_LAHIR->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->NOHP->Visible) { // NOHP ?>
		<td data-name="NOHP" <?php echo $murid_list->NOHP->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_NOHP">
<span<?php echo $murid_list->NOHP->viewAttributes() ?>><?php echo $murid_list->NOHP->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->NOWA->Visible) { // NOWA ?>
		<td data-name="NOWA" <?php echo $murid_list->NOWA->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_NOWA">
<span<?php echo $murid_list->NOWA->viewAttributes() ?>><?php echo $murid_list->NOWA->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->IDTELEGRAM->Visible) { // IDTELEGRAM ?>
		<td data-name="IDTELEGRAM" <?php echo $murid_list->IDTELEGRAM->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_IDTELEGRAM">
<span<?php echo $murid_list->IDTELEGRAM->viewAttributes() ?>><?php echo $murid_list->IDTELEGRAM->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->IDLINE->Visible) { // IDLINE ?>
		<td data-name="IDLINE" <?php echo $murid_list->IDLINE->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_IDLINE">
<span<?php echo $murid_list->IDLINE->viewAttributes() ?>><?php echo $murid_list->IDLINE->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->IDFACEBOOK->Visible) { // IDFACEBOOK ?>
		<td data-name="IDFACEBOOK" <?php echo $murid_list->IDFACEBOOK->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_IDFACEBOOK">
<span<?php echo $murid_list->IDFACEBOOK->viewAttributes() ?>><?php echo $murid_list->IDFACEBOOK->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->IDINSTAGRAM->Visible) { // IDINSTAGRAM ?>
		<td data-name="IDINSTAGRAM" <?php echo $murid_list->IDINSTAGRAM->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_IDINSTAGRAM">
<span<?php echo $murid_list->IDINSTAGRAM->viewAttributes() ?>><?php echo $murid_list->IDINSTAGRAM->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->IDTWITTER->Visible) { // IDTWITTER ?>
		<td data-name="IDTWITTER" <?php echo $murid_list->IDTWITTER->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_IDTWITTER">
<span<?php echo $murid_list->IDTWITTER->viewAttributes() ?>><?php echo $murid_list->IDTWITTER->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->IDYOUTUBE->Visible) { // IDYOUTUBE ?>
		<td data-name="IDYOUTUBE" <?php echo $murid_list->IDYOUTUBE->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid_IDYOUTUBE">
<span<?php echo $murid_list->IDYOUTUBE->viewAttributes() ?>><?php echo $murid_list->IDYOUTUBE->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($murid_list->_EMAIL->Visible) { // EMAIL ?>
		<td data-name="_EMAIL" <?php echo $murid_list->_EMAIL->cellAttributes() ?>>
<span id="el<?php echo $murid_list->RowCount ?>_murid__EMAIL">
<span<?php echo $murid_list->_EMAIL->viewAttributes() ?>><?php echo $murid_list->_EMAIL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$murid_list->ListOptions->render("body", "right", $murid_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$murid_list->isGridAdd())
		$murid_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$murid->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($murid_list->Recordset)
	$murid_list->Recordset->Close();
?>
<?php if (!$murid_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$murid_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $murid_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $murid_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($murid_list->TotalRecords == 0 && !$murid->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $murid_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$murid_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$murid_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$murid_list->terminate();
?>