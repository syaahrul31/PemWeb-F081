<?php
namespace PHPMaker2020\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$jadwal_pelajaran_edit = new jadwal_pelajaran_edit();

// Run the page
$jadwal_pelajaran_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$jadwal_pelajaran_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fjadwal_pelajaranedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fjadwal_pelajaranedit = currentForm = new ew.Form("fjadwal_pelajaranedit", "edit");

	// Validate form
	fjadwal_pelajaranedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "F")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($jadwal_pelajaran_edit->IDJADWAL->Required) { ?>
				elm = this.getElements("x" + infix + "_IDJADWAL");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $jadwal_pelajaran_edit->IDJADWAL->caption(), $jadwal_pelajaran_edit->IDJADWAL->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($jadwal_pelajaran_edit->ID_GURU->Required) { ?>
				elm = this.getElements("x" + infix + "_ID_GURU");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $jadwal_pelajaran_edit->ID_GURU->caption(), $jadwal_pelajaran_edit->ID_GURU->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($jadwal_pelajaran_edit->KODE_MAPEL->Required) { ?>
				elm = this.getElements("x" + infix + "_KODE_MAPEL");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $jadwal_pelajaran_edit->KODE_MAPEL->caption(), $jadwal_pelajaran_edit->KODE_MAPEL->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($jadwal_pelajaran_edit->IDRUANG->Required) { ?>
				elm = this.getElements("x" + infix + "_IDRUANG");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $jadwal_pelajaran_edit->IDRUANG->caption(), $jadwal_pelajaran_edit->IDRUANG->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($jadwal_pelajaran_edit->NO_INDUK->Required) { ?>
				elm = this.getElements("x" + infix + "_NO_INDUK");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $jadwal_pelajaran_edit->NO_INDUK->caption(), $jadwal_pelajaran_edit->NO_INDUK->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($jadwal_pelajaran_edit->HARIJADWAL->Required) { ?>
				elm = this.getElements("x" + infix + "_HARIJADWAL");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $jadwal_pelajaran_edit->HARIJADWAL->caption(), $jadwal_pelajaran_edit->HARIJADWAL->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($jadwal_pelajaran_edit->SESIJADWAL->Required) { ?>
				elm = this.getElements("x" + infix + "_SESIJADWAL");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $jadwal_pelajaran_edit->SESIJADWAL->caption(), $jadwal_pelajaran_edit->SESIJADWAL->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($jadwal_pelajaran_edit->WAKTU_MULAI->Required) { ?>
				elm = this.getElements("x" + infix + "_WAKTU_MULAI");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $jadwal_pelajaran_edit->WAKTU_MULAI->caption(), $jadwal_pelajaran_edit->WAKTU_MULAI->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_WAKTU_MULAI");
				if (elm && !ew.checkTime(elm.value))
					return this.onError(elm, "<?php echo JsEncode($jadwal_pelajaran_edit->WAKTU_MULAI->errorMessage()) ?>");
			<?php if ($jadwal_pelajaran_edit->WAKTU_SELESAI->Required) { ?>
				elm = this.getElements("x" + infix + "_WAKTU_SELESAI");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $jadwal_pelajaran_edit->WAKTU_SELESAI->caption(), $jadwal_pelajaran_edit->WAKTU_SELESAI->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_WAKTU_SELESAI");
				if (elm && !ew.checkTime(elm.value))
					return this.onError(elm, "<?php echo JsEncode($jadwal_pelajaran_edit->WAKTU_SELESAI->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fjadwal_pelajaranedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fjadwal_pelajaranedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fjadwal_pelajaranedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $jadwal_pelajaran_edit->showPageHeader(); ?>
<?php
$jadwal_pelajaran_edit->showMessage();
?>
<form name="fjadwal_pelajaranedit" id="fjadwal_pelajaranedit" class="<?php echo $jadwal_pelajaran_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="jadwal_pelajaran">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$jadwal_pelajaran_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($jadwal_pelajaran_edit->IDJADWAL->Visible) { // IDJADWAL ?>
	<div id="r_IDJADWAL" class="form-group row">
		<label id="elh_jadwal_pelajaran_IDJADWAL" for="x_IDJADWAL" class="<?php echo $jadwal_pelajaran_edit->LeftColumnClass ?>"><?php echo $jadwal_pelajaran_edit->IDJADWAL->caption() ?><?php echo $jadwal_pelajaran_edit->IDJADWAL->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $jadwal_pelajaran_edit->RightColumnClass ?>"><div <?php echo $jadwal_pelajaran_edit->IDJADWAL->cellAttributes() ?>>
<input type="text" data-table="jadwal_pelajaran" data-field="x_IDJADWAL" name="x_IDJADWAL" id="x_IDJADWAL" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($jadwal_pelajaran_edit->IDJADWAL->getPlaceHolder()) ?>" value="<?php echo $jadwal_pelajaran_edit->IDJADWAL->EditValue ?>"<?php echo $jadwal_pelajaran_edit->IDJADWAL->editAttributes() ?>>
<input type="hidden" data-table="jadwal_pelajaran" data-field="x_IDJADWAL" name="o_IDJADWAL" id="o_IDJADWAL" value="<?php echo HtmlEncode($jadwal_pelajaran_edit->IDJADWAL->OldValue != null ? $jadwal_pelajaran_edit->IDJADWAL->OldValue : $jadwal_pelajaran_edit->IDJADWAL->CurrentValue) ?>">
<?php echo $jadwal_pelajaran_edit->IDJADWAL->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($jadwal_pelajaran_edit->ID_GURU->Visible) { // ID_GURU ?>
	<div id="r_ID_GURU" class="form-group row">
		<label id="elh_jadwal_pelajaran_ID_GURU" for="x_ID_GURU" class="<?php echo $jadwal_pelajaran_edit->LeftColumnClass ?>"><?php echo $jadwal_pelajaran_edit->ID_GURU->caption() ?><?php echo $jadwal_pelajaran_edit->ID_GURU->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $jadwal_pelajaran_edit->RightColumnClass ?>"><div <?php echo $jadwal_pelajaran_edit->ID_GURU->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_ID_GURU">
<input type="text" data-table="jadwal_pelajaran" data-field="x_ID_GURU" name="x_ID_GURU" id="x_ID_GURU" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($jadwal_pelajaran_edit->ID_GURU->getPlaceHolder()) ?>" value="<?php echo $jadwal_pelajaran_edit->ID_GURU->EditValue ?>"<?php echo $jadwal_pelajaran_edit->ID_GURU->editAttributes() ?>>
</span>
<?php echo $jadwal_pelajaran_edit->ID_GURU->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($jadwal_pelajaran_edit->KODE_MAPEL->Visible) { // KODE_MAPEL ?>
	<div id="r_KODE_MAPEL" class="form-group row">
		<label id="elh_jadwal_pelajaran_KODE_MAPEL" for="x_KODE_MAPEL" class="<?php echo $jadwal_pelajaran_edit->LeftColumnClass ?>"><?php echo $jadwal_pelajaran_edit->KODE_MAPEL->caption() ?><?php echo $jadwal_pelajaran_edit->KODE_MAPEL->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $jadwal_pelajaran_edit->RightColumnClass ?>"><div <?php echo $jadwal_pelajaran_edit->KODE_MAPEL->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_KODE_MAPEL">
<input type="text" data-table="jadwal_pelajaran" data-field="x_KODE_MAPEL" name="x_KODE_MAPEL" id="x_KODE_MAPEL" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($jadwal_pelajaran_edit->KODE_MAPEL->getPlaceHolder()) ?>" value="<?php echo $jadwal_pelajaran_edit->KODE_MAPEL->EditValue ?>"<?php echo $jadwal_pelajaran_edit->KODE_MAPEL->editAttributes() ?>>
</span>
<?php echo $jadwal_pelajaran_edit->KODE_MAPEL->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($jadwal_pelajaran_edit->IDRUANG->Visible) { // IDRUANG ?>
	<div id="r_IDRUANG" class="form-group row">
		<label id="elh_jadwal_pelajaran_IDRUANG" for="x_IDRUANG" class="<?php echo $jadwal_pelajaran_edit->LeftColumnClass ?>"><?php echo $jadwal_pelajaran_edit->IDRUANG->caption() ?><?php echo $jadwal_pelajaran_edit->IDRUANG->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $jadwal_pelajaran_edit->RightColumnClass ?>"><div <?php echo $jadwal_pelajaran_edit->IDRUANG->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_IDRUANG">
<input type="text" data-table="jadwal_pelajaran" data-field="x_IDRUANG" name="x_IDRUANG" id="x_IDRUANG" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($jadwal_pelajaran_edit->IDRUANG->getPlaceHolder()) ?>" value="<?php echo $jadwal_pelajaran_edit->IDRUANG->EditValue ?>"<?php echo $jadwal_pelajaran_edit->IDRUANG->editAttributes() ?>>
</span>
<?php echo $jadwal_pelajaran_edit->IDRUANG->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($jadwal_pelajaran_edit->NO_INDUK->Visible) { // NO_INDUK ?>
	<div id="r_NO_INDUK" class="form-group row">
		<label id="elh_jadwal_pelajaran_NO_INDUK" for="x_NO_INDUK" class="<?php echo $jadwal_pelajaran_edit->LeftColumnClass ?>"><?php echo $jadwal_pelajaran_edit->NO_INDUK->caption() ?><?php echo $jadwal_pelajaran_edit->NO_INDUK->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $jadwal_pelajaran_edit->RightColumnClass ?>"><div <?php echo $jadwal_pelajaran_edit->NO_INDUK->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_NO_INDUK">
<input type="text" data-table="jadwal_pelajaran" data-field="x_NO_INDUK" name="x_NO_INDUK" id="x_NO_INDUK" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($jadwal_pelajaran_edit->NO_INDUK->getPlaceHolder()) ?>" value="<?php echo $jadwal_pelajaran_edit->NO_INDUK->EditValue ?>"<?php echo $jadwal_pelajaran_edit->NO_INDUK->editAttributes() ?>>
</span>
<?php echo $jadwal_pelajaran_edit->NO_INDUK->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($jadwal_pelajaran_edit->HARIJADWAL->Visible) { // HARIJADWAL ?>
	<div id="r_HARIJADWAL" class="form-group row">
		<label id="elh_jadwal_pelajaran_HARIJADWAL" for="x_HARIJADWAL" class="<?php echo $jadwal_pelajaran_edit->LeftColumnClass ?>"><?php echo $jadwal_pelajaran_edit->HARIJADWAL->caption() ?><?php echo $jadwal_pelajaran_edit->HARIJADWAL->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $jadwal_pelajaran_edit->RightColumnClass ?>"><div <?php echo $jadwal_pelajaran_edit->HARIJADWAL->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_HARIJADWAL">
<input type="text" data-table="jadwal_pelajaran" data-field="x_HARIJADWAL" name="x_HARIJADWAL" id="x_HARIJADWAL" size="30" maxlength="6" placeholder="<?php echo HtmlEncode($jadwal_pelajaran_edit->HARIJADWAL->getPlaceHolder()) ?>" value="<?php echo $jadwal_pelajaran_edit->HARIJADWAL->EditValue ?>"<?php echo $jadwal_pelajaran_edit->HARIJADWAL->editAttributes() ?>>
</span>
<?php echo $jadwal_pelajaran_edit->HARIJADWAL->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($jadwal_pelajaran_edit->SESIJADWAL->Visible) { // SESIJADWAL ?>
	<div id="r_SESIJADWAL" class="form-group row">
		<label id="elh_jadwal_pelajaran_SESIJADWAL" for="x_SESIJADWAL" class="<?php echo $jadwal_pelajaran_edit->LeftColumnClass ?>"><?php echo $jadwal_pelajaran_edit->SESIJADWAL->caption() ?><?php echo $jadwal_pelajaran_edit->SESIJADWAL->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $jadwal_pelajaran_edit->RightColumnClass ?>"><div <?php echo $jadwal_pelajaran_edit->SESIJADWAL->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_SESIJADWAL">
<input type="text" data-table="jadwal_pelajaran" data-field="x_SESIJADWAL" name="x_SESIJADWAL" id="x_SESIJADWAL" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($jadwal_pelajaran_edit->SESIJADWAL->getPlaceHolder()) ?>" value="<?php echo $jadwal_pelajaran_edit->SESIJADWAL->EditValue ?>"<?php echo $jadwal_pelajaran_edit->SESIJADWAL->editAttributes() ?>>
</span>
<?php echo $jadwal_pelajaran_edit->SESIJADWAL->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($jadwal_pelajaran_edit->WAKTU_MULAI->Visible) { // WAKTU_MULAI ?>
	<div id="r_WAKTU_MULAI" class="form-group row">
		<label id="elh_jadwal_pelajaran_WAKTU_MULAI" for="x_WAKTU_MULAI" class="<?php echo $jadwal_pelajaran_edit->LeftColumnClass ?>"><?php echo $jadwal_pelajaran_edit->WAKTU_MULAI->caption() ?><?php echo $jadwal_pelajaran_edit->WAKTU_MULAI->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $jadwal_pelajaran_edit->RightColumnClass ?>"><div <?php echo $jadwal_pelajaran_edit->WAKTU_MULAI->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_WAKTU_MULAI">
<input type="text" data-table="jadwal_pelajaran" data-field="x_WAKTU_MULAI" name="x_WAKTU_MULAI" id="x_WAKTU_MULAI" maxlength="10" placeholder="<?php echo HtmlEncode($jadwal_pelajaran_edit->WAKTU_MULAI->getPlaceHolder()) ?>" value="<?php echo $jadwal_pelajaran_edit->WAKTU_MULAI->EditValue ?>"<?php echo $jadwal_pelajaran_edit->WAKTU_MULAI->editAttributes() ?>>
</span>
<?php echo $jadwal_pelajaran_edit->WAKTU_MULAI->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($jadwal_pelajaran_edit->WAKTU_SELESAI->Visible) { // WAKTU_SELESAI ?>
	<div id="r_WAKTU_SELESAI" class="form-group row">
		<label id="elh_jadwal_pelajaran_WAKTU_SELESAI" for="x_WAKTU_SELESAI" class="<?php echo $jadwal_pelajaran_edit->LeftColumnClass ?>"><?php echo $jadwal_pelajaran_edit->WAKTU_SELESAI->caption() ?><?php echo $jadwal_pelajaran_edit->WAKTU_SELESAI->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $jadwal_pelajaran_edit->RightColumnClass ?>"><div <?php echo $jadwal_pelajaran_edit->WAKTU_SELESAI->cellAttributes() ?>>
<span id="el_jadwal_pelajaran_WAKTU_SELESAI">
<input type="text" data-table="jadwal_pelajaran" data-field="x_WAKTU_SELESAI" name="x_WAKTU_SELESAI" id="x_WAKTU_SELESAI" maxlength="10" placeholder="<?php echo HtmlEncode($jadwal_pelajaran_edit->WAKTU_SELESAI->getPlaceHolder()) ?>" value="<?php echo $jadwal_pelajaran_edit->WAKTU_SELESAI->EditValue ?>"<?php echo $jadwal_pelajaran_edit->WAKTU_SELESAI->editAttributes() ?>>
</span>
<?php echo $jadwal_pelajaran_edit->WAKTU_SELESAI->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$jadwal_pelajaran_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $jadwal_pelajaran_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $jadwal_pelajaran_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$jadwal_pelajaran_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$jadwal_pelajaran_edit->terminate();
?>